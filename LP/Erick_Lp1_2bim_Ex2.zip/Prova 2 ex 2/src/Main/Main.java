/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;


/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        
        while(true){
            System.out.println("1 - Soma dos pares");
            System.out.println("2 - Menor e maior alturas");
            System.out.println("3 - Médias, positivos, negativos e percentuais");
            System.out.println("4 - Tabuada ");
            System.out.println("5 - Fibonacci");
            System.out.println("6 - Sair do programa");
            int valor = entrada.lerOpções("Digite uma opção:");
            
            if(valor==1){
                LetraA letraA = new LetraA();
            }
            
            if(valor==2){
                LetraB letraB = new LetraB();
            }
            
            if(valor==3){
                LetraC letraC = new LetraC();
            }
            
            if(valor==4){
                LetraD letraD = new LetraD();
            }
            
            if(valor==5){
                LetraE letraE = new LetraE();
            }
            
            if(valor==6){
                System.out.println("Obrigado até a próxima");
                break;
            }    
        }
    }   
}
