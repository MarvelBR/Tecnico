/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class EntradaE {
    Scanner teclado = new Scanner(System.in);
    
    public int lerNumeroInt(String mensagem){
        double y = 0;
        while (true) {
         try {
             System.out.print(mensagem);
             y = teclado.nextDouble();
             while (y<=0) {
                 System.out.print("Erro, digite um valor positivo e diferente de 0:");
                 y = teclado.nextDouble();
             }
             break;
         } catch (Exception e) {
             System.out.println("Erro, digite novamente");
             teclado = new Scanner(System.in);
         }
        }
        return (int) y;
     }
 }

class LetraE {
    int x = 1;
    int y = 0;
            
    public LetraE(){
        //entrada
        EntradaE entradaE = new EntradaE();
        int num = entradaE.lerNumeroInt("Digite o número da sequência que você deseja saber:");
        
        //processamento
        for (int i = 2; i<num; i++){
            x = x+y;
            y = x-y;    
        }
        //saida
        if(num==1){
            System.out.println("O 1º número da sequência de Fibonacci é o 0");
        }
        else{
            System.out.println("O "+num+"º número da sequência de Fibonacci é o "+x);
        }
    }
}

