/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author erick
 */
class EntradaB {
    Scanner teclado = new Scanner(System.in);
    
    public double lerNumeroDouble(String mensagem){
       double x = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            x = teclado.nextDouble();
            break; //sair do laço(while)
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
        return x;
    }
}    

class LetraB {
    double maior = 0;
    double menor = 100000;
    
    public LetraB(){
        //entrada
        EntradaB entradaB = new EntradaB();
        for(int i = 0; i<10; i++){
            double altura = entradaB.lerNumeroDouble("Digite a "+(i+1)+"º altura em metros (caso queira sair do programa digite um número negativo ou 0):");
            
            //processamento
            if(altura<=0){
                break;
            }   
            
            if(maior<altura){
                maior = altura;
            }
            
            if(menor>altura){
                menor = altura; 
            }
        }
        //saida
        System.out.println("A maior altura foi igual a:"+maior);
        System.out.println("A menor altura foi igual a:"+menor);
        
    }
}
