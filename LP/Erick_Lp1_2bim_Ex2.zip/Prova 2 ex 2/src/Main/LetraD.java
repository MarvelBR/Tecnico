/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */

class EntradaD {
    Scanner teclado = new Scanner(System.in);
    
    public int lerTabuada(String mensagem){
       double y = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            y = teclado.nextDouble();
            while (y<0 || y>10) {
                System.out.print("Erro, digite um número inteiro de 1 e 10:");
                y = teclado.nextDouble();
            }
            break;
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
       return (int) y;
    }
    
}

class LetraD {
    public LetraD(){
        //entrada
        EntradaD entradaD = new EntradaD();
        int a = entradaD.lerTabuada("Digite o número de 1 a 10 que você quer saber a tabuada:");
       
        //processamento
        for (int i = 0; i<11; i++){
            //saida
            System.out.println(i+"x"+a+"="+i*a);
        }
        }
    }

