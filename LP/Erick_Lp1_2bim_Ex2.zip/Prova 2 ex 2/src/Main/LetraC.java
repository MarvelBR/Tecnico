/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class EntradaC {
    Scanner teclado = new Scanner(System.in);
    
    public double lerNumeroDouble(String mensagem){
       double z = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            z = teclado.nextDouble();
            break; //sair do laço(while)
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
        return z;
    }
    public int lerNumeroInt(String mensagem){
       double y = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            y = teclado.nextDouble();
            while (y<0) {
                System.out.print("Erro, digite um valor positivo:");
                y = teclado.nextDouble();
            }
            break;
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
       return (int) y;
    }
}

class LetraC {
    int quant_positivo = 0;
    int quant_negativo = 0;
    double soma = 0;
    
    public LetraC(){
        //entrada
        EntradaC entradaC = new EntradaC();
        int a = entradaC.lerNumeroInt("Digite a quantidade de números a ser lida:");
        
        //processamento
        for (int i = 0; i<a; i++){
            double num = entradaC.lerNumeroDouble("Digite o "+(i+1)+"º número:");
            soma = soma+num;
            
            if (num<0){
                quant_negativo++;
            }
            if (num>=0){
                quant_positivo++;
            }
        }
        //saida
        System.out.println("A média entre os números digitados é igual a:"+soma/a);
        System.out.println("A quantidade de número positivos digitados foi de:"+quant_positivo);
        System.out.println("O percentual de números positivos foi de:"+(quant_positivo*100)/a+"%");
        System.out.println("A quantidade de número negativos digitados foi de:"+quant_negativo);
        System.out.println("O percentual de números negativos foi de:"+(quant_negativo*100)/a+"%");
    }
}
