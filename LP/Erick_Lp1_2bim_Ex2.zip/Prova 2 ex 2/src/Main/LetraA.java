/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class EntradaA {
    Scanner teclado = new Scanner(System.in);
    
    public double lerNumeroDouble(String mensagem){
       double z = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            z = teclado.nextDouble();
            break; //sair do laço(while)
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
        return z;
    }
    public int lerNumeroInt(String mensagem){
       double y = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            y = teclado.nextDouble();
            while (y<0) {
                System.out.print("Erro, digite um valor positivo:");
                y = teclado.nextDouble();
            }
            break;
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
       return (int) y;
    }
}
class LetraA {
    double soma_par = 0;
    
    public LetraA(){
        //entrada
        EntradaA entradaA = new EntradaA();
        int a = entradaA.lerNumeroInt("Digite a quantidade de números a ser lida:");
        
        for(int i = 0; i<a; i++) {;
            double numeros = entradaA.lerNumeroDouble("Digite o "+(i+1)+"º número:");
            
            //processamento
            if(numeros%2==0){
                soma_par = soma_par+numeros;
            }
            
        }
        //saida
        System.out.println("A soma dos números pares é igual a:"+soma_par);
    }
}
