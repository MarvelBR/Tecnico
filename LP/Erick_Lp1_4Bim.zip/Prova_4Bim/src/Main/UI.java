/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.ArrayList;
import java.util.List;
import tools.CaixaDeFerramentas;
import tools.ManipulaArquivo;

/**
 *
 * @author erick
 */
class UI {

    String reset = "\u001B[0m";
    String verde = "\u001B[32m";
    String azul = "\u001B[34m";
    String amarelo = "\u001B[33m";
    String magenta = "\u001B[35m";
    String ciano = "\u001B[36m";
    String vermelho = "\u001B[31m";

    CaixaDeFerramentas caixaDeFerramentas = new CaixaDeFerramentas();
    Controle_De_Lista controle_De_Lista = new Controle_De_Lista();
    Saida saida = new Saida();
    int opcao = 0;

    public void adicionar() {
        Entrada entrada = new Entrada();
        //chave primária
        String nome = entrada.lerString("Digite o nome do seu personagem");
        Personagem personagem = controle_De_Lista.buscar(nome);

        if (personagem == null) { //não achou na lista, então pode incluir
            personagem = new Personagem();
            personagem.setNome(nome);
            entrada = new Entrada();
            personagem.setRaca(entrada.lerString("Digite sua raça"));
            personagem.setClasse(entrada.lerString("Digite sua classe"));
            personagem.setTendencia(entrada.lerString("Digite sua tendência"));
            personagem.setNivel(entrada.lerInt("Digite seu nível:"));
            personagem.setData_de_nascimento(entrada.lerData("Digite sua data de nascimento:"));
            personagem.setAltura(entrada.lerDouble("Digite sua altura:"));
            controle_De_Lista.adicionar(personagem);

        } else {
            System.out.println(amarelo + "Já está registrado!" + reset + "\n");
        }
    }

    public void buscar() {
        Entrada entrada = new Entrada();
        //chave primária
        String nome = entrada.lerString("Digite o nome do seu personagem");
        Personagem personagem = controle_De_Lista.buscar(nome);

        if (personagem == null) { //não achou na lista, então pode incluir
            System.out.println(amarelo + "Não está registrado!" + reset + "\n");

        } else {
            System.out.println("\n" + ciano + "Encontrou " + reset);
            Saida saida = new Saida();
            saida.imprimir("Nome", personagem.getNome());
            saida.imprimir("Raça", personagem.getRaca());
            saida.imprimir("Classe", personagem.getClasse());
            saida.imprimir("Tendência", personagem.getTendencia());
            saida.imprimir("Nível", String.valueOf(personagem.getNivel()));
            saida.imprimirdata("Data de Nascimento", personagem.getData_de_nascimento());
            saida.imprimir("Altura", String.valueOf(personagem.getAltura()));
        }
    }

    public void alterar() {
        Entrada entrada = new Entrada();
        //chave primária
        String nome = entrada.lerString("Digite o nome do seu personagem");
        Personagem personagem = controle_De_Lista.buscar(nome);

        if (personagem == null) { //não achou na lista, então pode incluir
            System.out.println(amarelo + "Não está registrado!" + reset);

        } else { // se achou
            System.out.println("\n" + magenta + "Encontrou - pode alterar" + reset);
            Saida saida = new Saida();
            saida.imprimir2("Nome", personagem.getNome());
            saida.imprimir2("Raça", personagem.getRaca());
            saida.imprimir2("Classe", personagem.getClasse());
            saida.imprimir2("Tendência", personagem.getTendencia());
            saida.imprimir2("Nível", String.valueOf(personagem.getNivel()));
            saida.imprimirdata2("Data de Nascimento", personagem.getData_de_nascimento());
            saida.imprimir2("Altura", String.valueOf(personagem.getAltura()));
            System.out.println("\n");

            Personagem atual = personagem;
            entrada = new Entrada();
            saida.imprimir2("Nome do personagem", nome);
            personagem.setRaca(entrada.lerString("Nova raça"));
            personagem.setClasse(entrada.lerString("Nova classe"));
            personagem.setTendencia(entrada.lerString("Nova tendência"));
            personagem.setNivel(entrada.lerInt("Novo nível:"));
            personagem.setData_de_nascimento(entrada.lerData("Nova data de nascimento:"));
            personagem.setAltura(entrada.lerDouble("Nova altura:"));
            controle_De_Lista.atualizar(atual, personagem);


        }
    }

    public void excluir() {
        Entrada entrada = new Entrada();
        //chave primária
        String nome = entrada.lerString("Digite o nome do seu personagem");
        Personagem personagem = controle_De_Lista.buscar(nome);

        if (personagem == null) { //não achou na lista, então pode incluir
            System.out.println(amarelo + "Não está registrado!" + reset);
        } else {
            System.out.println("\n" + vermelho + "Encontrou - pode excluir " + reset);
            Saida saida = new Saida();
            saida.imprimir3("Nome", personagem.getNome());
            saida.imprimir3("Raça", personagem.getRaca());
            saida.imprimir3("Classe", personagem.getClasse());
            saida.imprimir3("Tendência", personagem.getTendencia());
            saida.imprimir3("Nível", String.valueOf(personagem.getNivel()));
            saida.imprimirdata3("Data de nascimento", personagem.getData_de_nascimento());
            saida.imprimir3("Altura", String.valueOf(personagem.getAltura()));
            System.out.println("\n");

            if (entrada.lerConfirmacao("Excluir o personagem?")) {
                controle_De_Lista.excluir(personagem);
            }
        }
    }

    public void listar() {
        List<Personagem> lp = controle_De_Lista.listar();
        for (int i = 0; i < lp.size(); i++) {
            System.out.println(azul + lp.get(i).toString() + "\n" + reset);
        }
    }

    public UI() {
        Entrada entrada = new Entrada();
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        List<String> ls = manipulaArquivo.abrirArquivo("Personagem.csv");
        for (String pp : ls) {
            String[] aux = pp.split(";");//1;Iracema;José de Alencar
            Personagem personagem = new Personagem();
            personagem.setNome(aux[0]);
            personagem.setRaca(aux[1]);
            personagem.setClasse(aux[2]);
            personagem.setTendencia(aux[3]);
            personagem.setNivel(Integer.valueOf(aux[4]));
            personagem.setData_de_nascimento(caixaDeFerramentas.converteDeStringParaDate(aux[5]));
            personagem.setAltura(Double.valueOf(aux[6]));

            controle_De_Lista.adicionar(personagem);
        }

        while (opcao != 6) {
            System.out.println("=====================================");
            System.out.println("Criar Personagem de RPG");
            System.out.println("1 - Adicionar");
            System.out.println("2 - Buscar");
            System.out.println("3 - Alterar");
            System.out.println("4 - Excluir");
            System.out.println("5 - Listar");
            System.out.println("6 - Sair");
            System.out.println("=====================================");

            opcao = entrada.lerOpções("Escolha uma opção:");

            switch (opcao) {
                case 1:
                    adicionar();
                    break;

                case 2:
                    buscar();
                    break;

                case 3:
                    alterar();
                    break;

                case 4:
                    excluir();
                    break;

                case 5:
                    listar();
                    break;

                case 6:
                    ls = new ArrayList<>();
                    List<Personagem> lp = controle_De_Lista.listar();
                    for (int i = 0; i < lp.size(); i++) {
                        ls.add(lp.get(i).toString());
                    }
                    manipulaArquivo = new ManipulaArquivo();
                    manipulaArquivo.salvarArquivo("Personagem.csv", ls);
                    System.out.println(verde + "Fim! :)" +"\n");
                    break;

                default:
                    System.out.println(verde + "bye bye");
            }
        }
    }
}
