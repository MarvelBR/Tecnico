/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author erick
 */
class Saida {
    String reset = "\u001B[0m";
    String preto = "\u001B[30m";
    String vermelho = "\u001B[31m";
    String verde = "\u001B[32m";
    String amarelo = "\u001B[33m";
    String azul = "\u001B[34m";
    String magenta = "\u001B[35m";
    String ciano = "\u001B[36m";
    
    public void imprimir(String rotulo, String s){
        System.out.println(rotulo+ ": "+ ciano +s + reset);
    }
    
    public void imprimir2(String rotulo, String s){
        System.out.println(rotulo+ ": "+ magenta +s + reset);
    }
    
    public void imprimir3(String rotulo, String s){
        System.out.println(rotulo+ ": "+ vermelho +s + reset);
    }
    
    public void imprimirdata(String msg, Date data){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println(msg+ ": "+ ciano + sdf.format(data) + reset);
    }
    
    public void imprimirdata2(String msg, Date data){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println(msg+ ": "+ magenta + sdf.format(data) + reset);
    }
    
    public void imprimirdata3(String msg, Date data){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println(msg+ ": "+ vermelho + sdf.format(data) + reset);
    }
    
}
