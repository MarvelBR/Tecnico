/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author erick
 */
public class Personagem {
    private String nome;
    private String raca;
    private String classe;
    private String tendencia;
    private int nivel;
    private Date data_de_nascimento;
    private double altura;
    
    public Personagem() {
    }

    public Personagem(String nome, String raca, String classe, String tendencia, int nivel, Date data_de_nascimento, double altura) {
        this.nome = nome;
        this.raca = raca;
        this.classe = classe;
        this.tendencia = tendencia;
        this.nivel = nivel;
        this.data_de_nascimento = data_de_nascimento;
        this.altura = altura;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public String getTendencia() {
        return tendencia;
    }

    public void setTendencia(String tendencia) {
        this.tendencia = tendencia;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public Date getData_de_nascimento() {
        return data_de_nascimento;
    }

    public void setData_de_nascimento(Date data_de_nascimento) {
        this.data_de_nascimento = data_de_nascimento;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return nome + ";" + raca +";" + classe +";" + tendencia +";" + nivel +";" + sdf.format(data_de_nascimento) +";" + altura;
    }
    
}
