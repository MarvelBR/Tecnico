/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {
    Scanner teclado = new Scanner(System.in);
    
    public String lerString(String mensagem) {
        String s = "";

        while (true) {
            System.out.print(mensagem + ": ");
            s = teclado.nextLine();
            s = s.trim();//retira espaços em branco
            
            if (!s.equals("")) {
                break;
            } else {
                System.out.println("Digite uma string não vazia");
            }
        }
        return s;
    }
    
    public Date lerData(String mensagem){
        teclado = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        while(true){
            try{    
                System.out.print(mensagem);
                String sData = teclado.nextLine();
                Date d = sdf.parse(sData);
                return d;
            }catch(ParseException ex){
                System.out.println("Erro, digite uma data válida");
            }
        }   
    }
    
    public int lerInt(String mensagem) {
        int z = 0;
        while (true) {
            try {
                System.out.print(mensagem);
                z = teclado.nextInt();
                while (z < 0) {
                    System.out.print("Erro, digite um número maior ou igual a 0:");
                    z = teclado.nextInt();
                }
                break;
            } catch (Exception e) {
                System.out.println("Erro, digite novamente");
                teclado = new Scanner(System.in);
            }
        }
        return z;
    }
    
    public double lerDouble(String mensagem) {
        double x = 0;
        while (true) {
            try {
                System.out.print(mensagem);
                x = teclado.nextDouble();
                while (x < 0) {
                    System.out.print("Erro, digite um número maior que 0:");
                    x = teclado.nextDouble();
                }
                break;
            } catch (Exception e) {
                System.out.println("Erro, digite novamente");
                teclado = new Scanner(System.in);
            }
        }
        return x;
    }
    
    public int lerOpções(String mensagem){
       double y = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            y = teclado.nextDouble();
            while (y<0 || y>6) {
                System.out.print("Erro, digite um valor inteiro entre 1 e 6:");
                y = teclado.nextDouble();
            }
            break;
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
       return (int) y;
    }
    
    public boolean lerConfirmacao(String msg) {
        //ler uma resposta sim ou não do usuário
        teclado = new Scanner(System.in);
        while (true) {
            try {
                System.out.print(msg + " (S ou N): ");
                char x = teclado.next().charAt(0);
                if (x == 's' || x == 'S') {
                    return true;
                } else if (x == 'n' || x == 'N') {
                    return false;
                } else {
                    int a = 3 / 0;//provocar um erro propositalmente
                }
            } catch (Exception e) {
                System.out.println("Erro, são válidas as letras S ou N");
                teclado = new Scanner(System.in);
            }
        }
    }
}
