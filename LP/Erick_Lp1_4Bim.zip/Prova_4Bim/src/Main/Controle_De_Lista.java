/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author erick
 */
public class Controle_De_Lista {

    private List<Personagem> listaDePersonagens = new ArrayList<>();

    public void adicionar(Personagem personagem) {
        listaDePersonagens.add(personagem);
    }

    public Personagem buscar(String nome) {
        for (int i = 0; i < listaDePersonagens.size(); i++) {
            if (nome.equals(listaDePersonagens.get(i).getNome())) {
                return listaDePersonagens.get(i);
            }
        }
        return null;
    }

    public void atualizar(Personagem atual, Personagem modificado) {
        listaDePersonagens.set(listaDePersonagens.indexOf(atual), modificado);
    }

    public void excluir(Personagem personagem) {
        listaDePersonagens.remove(personagem);
    }

    public List<Personagem> listar() {
        return listaDePersonagens;
    }
}
