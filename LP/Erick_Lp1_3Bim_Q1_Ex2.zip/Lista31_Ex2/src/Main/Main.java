/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        String s1 = entrada.lerString("Escreva uma string");
        
        Processamento processamento = new Processamento();
        int contador = processamento.verEspacos(s1);
        
        Saida saida = new Saida();
        saida.imprimirString("Na string digitada existem:"+ s1.length());
        saida.imprimirString("O número de palavras na frase foi de:"+ contador);
    }
    
}
