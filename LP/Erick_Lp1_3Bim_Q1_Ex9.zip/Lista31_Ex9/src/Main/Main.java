/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        String s1 = entrada.lerString("Escreva uma string");
        char letra = entrada.lerChar("Digite uma letra para ver quantas vezes ela aparece na frase:");
        
        Processamento processamento = new Processamento();
        int cont = processamento.lerString(s1, letra);
        
        Saida saida = new Saida();
        saida.imprimirString("A letra apareceu:"+cont+" vezes");
    }
    
}
