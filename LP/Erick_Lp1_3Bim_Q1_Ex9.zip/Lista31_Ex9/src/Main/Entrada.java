/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {

    public String lerString(String mensagem) {
        Scanner teclado = new Scanner(System.in);
        String s = "";

        while (true) {
            System.out.print(mensagem + ": ");
            s = teclado.nextLine();
            s = s.trim();//retira espaços em branco

            if (!s.equals("")) {
                break;
            } else {
                System.out.println("Digite uma string não vazia");
            }
        }
        return s;
    }

    public char lerChar(String mensagem) {

        Scanner teclado = new Scanner(System.in);
        char s = 0;
        while (true) {

            try {
                System.out.print(mensagem);
                s = teclado.next().charAt(0);
                while (s == ' ') {
                    System.out.print("Erro, digite novamente");
                    s = teclado.next().charAt(0);
                }
                break;
            } catch (Exception e) {
                System.out.println("Erro, digite novamente uma letra");
                teclado = new Scanner(System.in);
            }
        }
        return s;
    }

}
