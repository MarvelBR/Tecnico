/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public int lerString(String s1, char letra){
        int cont = 0;
        char letra2 = Character.toUpperCase(letra);
        char letra3 = Character.toLowerCase(letra);
        
        for (int i = 0; i < s1.length(); i++){
            if (s1.charAt(i)== letra || s1.charAt(i) == letra2 || s1.charAt(i) == letra3){
                cont = cont+1;
            }
        }
        return cont;
    }
}
