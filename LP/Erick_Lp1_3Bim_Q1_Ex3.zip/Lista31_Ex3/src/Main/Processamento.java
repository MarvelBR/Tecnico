/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public void verNome(String s1){
        String [] s2 = s1.split(" ");
        
        for (int i = 1; i-1 > -s2.length; i--){
            System.out.print(" "+s2[i]+" ");

        }
    }
}    
