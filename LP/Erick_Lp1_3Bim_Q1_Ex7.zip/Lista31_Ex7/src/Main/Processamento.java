/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public void Vernumero(int num){
        String number = String.valueOf(num);
        String wNumber[] = {"Zero ", "Um ", "Dois ", "Três ", "Quatro ", "Cinco ", "Seis ", "Sete ", "Oito ", "Nove "};
        for (int i = 0; i < number.length(); i++) {
            System.out.print(wNumber[Character.getNumericValue(number.charAt(i))]);
        }
    }
}
