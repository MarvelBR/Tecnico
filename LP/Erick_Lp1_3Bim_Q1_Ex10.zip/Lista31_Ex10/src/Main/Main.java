/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        String frase = entrada.lerString("Escreva uma frase");
        String palavra = entrada.lerString("Digite a palavra que você quer saber a posição");
        
        Processamento processamento = new Processamento();
        int posicao = processamento.verFrase(frase, palavra);
        
        Saida saida = new Saida();
        saida.imprimirString("A posição da palavra na frase é a:"+posicao+" ");
        
    }
    
}
