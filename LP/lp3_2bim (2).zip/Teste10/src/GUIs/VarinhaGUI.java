package GUIs;

import Entidades.Varinha;
import DAOs.DAOVarinha;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Date;
import static javax.swing.SwingConstants.CENTER;
import static javax.swing.SwingConstants.TOP;

/**
 *
 * @author Erick 05/07/2023 - 12:45:48
 */
public class VarinhaGUI extends JDialog {

    Container cp;
    TestPanel pnNorte = new TestPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    JCheckBox cbQuebrada = new JCheckBox("Quebrada", false);
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    DLabel lbNomeVarinha = new DLabel("NomeVarinha");
    JTextField tfNomeVarinha = new JTextField(30);
    JLabel lbMadeira = new JLabel("Madeira");
    JTextField tfMadeira = new JTextField(30);
    JLabel lbNucleo = new JLabel("Nucleo");
    JTextField tfNucleo = new JTextField(30);
    JLabel lbTamanhoCm = new JLabel("TamanhoCm");
    JTextField tfTamanhoCm = new JTextField(30);
    JLabel lbVazio = new JLabel("");
    DAOVarinha daoVarinha = new DAOVarinha();
    Varinha varinha = new Varinha();
    String[] colunas = new String[]{"nomeVarinha", "madeira", "nucleo", "tamanhoCm", "quebrada"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    public VarinhaGUI() {
        Font gizmo = null;
        Font gizmo_lista = null;

        try {
            gizmo = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/gizmo.ttf"));
        } catch (Exception e) {
            System.out.println("Merda " + e);
        }

        gizmo = gizmo.deriveFont(Font.PLAIN, 36);
        gizmo_lista = gizmo.deriveFont(Font.PLAIN, 26);
        Font roboto = null;
        try {
            roboto = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Roboto-Medium.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }
        roboto = roboto.deriveFont(Font.PLAIN, 18);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Varinha");

        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(20);
        tabela.setFont(roboto);

        //cabeçalho
        tabela.getTableHeader().setBackground(new Color(128, 128, 128));
        tabela.getTableHeader().setForeground(new Color(0, 0, 0));
        tabela.getTableHeader().setFont(roboto);
        //cor da linha da tabela
        tabela.setGridColor(new Color(0, 0, 0));
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(new Color(128, 128, 128));
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        btListar.setFont(roboto);
        btBuscar.setFont(roboto);
        btAdicionar.setFont(roboto);
        btSalvar.setFont(roboto);
        btCancelar.setFont(roboto);
        btExcluir.setFont(roboto);
        btAlterar.setFont(roboto);
        lbNomeVarinha.setFont(roboto);
        tfNomeVarinha.setFont(roboto);
        pnNorte.add(lbNomeVarinha);
        pnNorte.add(tfNomeVarinha);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        tfMadeira.setEditable(false);
        tfNucleo.setEditable(false);
        tfTamanhoCm.setEditable(false);
        cbQuebrada.setEnabled(false);
        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));
        lbMadeira.setHorizontalAlignment(SwingConstants.CENTER);
        lbNucleo.setHorizontalAlignment(SwingConstants.CENTER);
        lbTamanhoCm.setHorizontalAlignment(SwingConstants.CENTER);
        cbQuebrada.setHorizontalAlignment(SwingConstants.CENTER);

        lbMadeira.setFont(roboto);
        tfMadeira.setFont(roboto);
        lbNucleo.setFont(roboto);
        tfNucleo.setFont(roboto);
        lbTamanhoCm.setFont(roboto);
        tfTamanhoCm.setFont(roboto);
        cbQuebrada.setFont(roboto);

        pnCentro.add(lbMadeira);
        pnCentro.add(tfMadeira);
        pnCentro.add(lbNucleo);
        pnCentro.add(tfNucleo);
        pnCentro.add(lbTamanhoCm);
        pnCentro.add(tfTamanhoCm);
        pnCentro.add(cbQuebrada);
        pnCentro.add(lbVazio);
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));

// listener Buscar
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    varinha = daoVarinha.obter(tfNomeVarinha.getText());
                    if (varinha != null) {//achou o varinha na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        cbQuebrada.setSelected(varinha.getQuebrada() == 1 ? true : false);
                        tfMadeira.setText(String.valueOf(varinha.getMadeira()));
                        tfMadeira.setEditable(false);
                        tfNucleo.setText(String.valueOf(varinha.getNucleo()));
                        tfNucleo.setEditable(false);
                        tfTamanhoCm.setText(String.valueOf(varinha.getTamanhoCm()));
                        tfTamanhoCm.setEditable(false);
                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        tfMadeira.setText("");
                        tfMadeira.setEditable(false);
                        tfNucleo.setText("");
                        tfNucleo.setEditable(false);
                        tfTamanhoCm.setText("");
                        tfTamanhoCm.setEditable(false);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfNomeVarinha.setEnabled(false);
                tfMadeira.requestFocus();
                tfMadeira.setEditable(true);
                tfNucleo.setEditable(true);
                tfTamanhoCm.setEditable(true);
                cbQuebrada.setEnabled(true);
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Short cb_BD;    //fazendo isso pq em no BD boolean é tiny_int que é = ao short
                if (cbQuebrada.isSelected()) {
                    cb_BD = 1;
                } else {
                    cb_BD = 0;
                }
                if (acao.equals("adicionar")) {
                    varinha = new Varinha();
                }
                try {
                    varinha.setNomeVarinha(tfNomeVarinha.getText());
                    varinha.setMadeira(tfMadeira.getText());
                    varinha.setNucleo(tfNucleo.getText());
                    varinha.setTamanhoCm(Double.valueOf(tfTamanhoCm.getText()));
                    varinha.setQuebrada(cb_BD);
                    if (acao.equals("adicionar")) {
                        daoVarinha.inserir(varinha);
                    } else {
                        daoVarinha.atualizar(varinha);
                    }
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    tfNomeVarinha.setEnabled(true);
                    tfNomeVarinha.setEditable(true);
                    tfNomeVarinha.setText("");
                    tfMadeira.setEnabled(true);
                    tfMadeira.setEditable(false);
                    tfMadeira.requestFocus();
                    tfMadeira.setText("");
                    tfNucleo.setEnabled(true);
                    tfNucleo.setEditable(false);
                    tfNucleo.requestFocus();
                    tfNucleo.setText("");
                    tfTamanhoCm.setEnabled(true);
                    tfTamanhoCm.setEditable(false);
                    tfTamanhoCm.requestFocus();
                    tfTamanhoCm.setText("");
                    cbQuebrada.setEnabled(false);
                    cbQuebrada.setSelected(false);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);

                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfNomeVarinha.setEditable(false);
                tfMadeira.setEditable(true);
                tfNucleo.setEditable(true);
                tfTamanhoCm.setEditable(true);
                cbQuebrada.setEnabled(true);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                tfNomeVarinha.setEnabled(true);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                tfNomeVarinha.setEnabled(true);
                tfNomeVarinha.setEditable(true);
                tfNomeVarinha.requestFocus();
                tfNomeVarinha.setText("");
                tfMadeira.setText("");
                tfMadeira.setEditable(false);
                tfNucleo.setText("");
                tfNucleo.setEditable(false);
                tfTamanhoCm.setText("");
                tfTamanhoCm.setEditable(false);
                cbQuebrada.setSelected(false);
                cbQuebrada.setEnabled(false);
                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoVarinha.remover(varinha);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Varinha> listaVarinha = daoVarinha.list();
                String[] colunas = new String[]{"NomeVarinha", "Madeira", "Nucleo", "TamanhoCm", "Quebrada"};
                String[][] dados = new String[listaVarinha.size()][colunas.length];
                String aux[];
                for (int i = 0; i < listaVarinha.size(); i++) {
                    aux = listaVarinha.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                tfMadeira.setEditable(false);
                tfNucleo.setEditable(false);
                tfTamanhoCm.setEditable(false);//cor do background e da letra de cada coluna
                coluna1.setBackground(new Color(220, 220, 220));
                coluna1.setForeground(Color.BLACK);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(2).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(3).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(4).setCellRenderer(coluna1);
            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfNomeVarinha.setText("");
                tfNomeVarinha.requestFocus();
                tfNomeVarinha.setEnabled(true);
                tfNomeVarinha.setEditable(true);
                tfMadeira.setText("");
                tfMadeira.setEditable(false);
                tfNucleo.setText("");
                tfNucleo.setEditable(false);
                tfTamanhoCm.setText("");
                tfTamanhoCm.setEditable(false);
                cbQuebrada.setEnabled(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai da classe
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI
    
    public class DLabel extends JLabel {

        public DLabel(String name) {
            this.setForeground(Color.WHITE);
            this.setText(name);
            this.setOpaque(true);
            this.setHorizontalAlignment(CENTER);
            this.setBorder(BorderFactory.createBevelBorder(TOP, Color.black, Color.black));
        }

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.WHITE;
            Color color2 = Color.BLACK;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }

    }//fim da classe

    public class TestPanel extends JPanel {

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.WHITE;
            Color color2 = Color.BLACK;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }
    }
    
} //fim da classe
