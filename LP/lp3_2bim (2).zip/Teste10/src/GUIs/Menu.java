/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUIs;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.UIManager;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 *
 * @author erick
 */
public class Menu extends JFrame {

    Container cp;
    JButton btPessoa = new JGradientButtonSimple("Pessoa", Color.BLUE, Color.GREEN);
    JButton btCliente = new JGradientButtonSimple("Cliente", Color.CYAN, Color.LIGHT_GRAY);
    JButton btFuncionario = new JGradientButtonSimple("Funcionario", Color.DARK_GRAY, Color.LIGHT_GRAY);
    JButton btCasa = new JGradientButtonSimple("Casas", Color.RED, Color.ORANGE);
    JButton btPatrono = new JGradientButtonSimple("Patronos", Color.MAGENTA, Color.PINK);
    JButton btVarinha = new JGradientButtonSimple("Varinhas", Color.BLACK, Color.WHITE);

    public Menu() {
        cp = getContentPane();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Menu - BD");

        Font fonteTamanhoNovo = new Font("Serif", Font.PLAIN, 24);
        btPessoa.setFont(fonteTamanhoNovo);
        btCliente.setFont(fonteTamanhoNovo);
        btFuncionario.setFont(fonteTamanhoNovo);
        btCasa.setFont(fonteTamanhoNovo);
        btPatrono.setFont(fonteTamanhoNovo);
        btVarinha.setFont(fonteTamanhoNovo);
        
        btPessoa.setForeground(Color.white);
        btCliente.setForeground(Color.white);
        btFuncionario.setForeground(Color.white);
        btCasa.setForeground(Color.white);
        btPatrono.setForeground(Color.white);
        btVarinha.setForeground(Color.white);

        cp.setLayout(new GridLayout(6, 1));
        
        cp.add(btPessoa);
        cp.add(btCliente);
        cp.add(btFuncionario);
        cp.add(btCasa);
        cp.add(btPatrono);
        cp.add(btVarinha);
        
        btPessoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PessoaGUI pessoaGUI = new PessoaGUI();
            }
        });
        
        btCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ClienteGUI clienteGUI = new ClienteGUI();
            }
        });
        
        btFuncionario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FuncionarioGUI funcionarioGUI = new FuncionarioGUI();
            }
        });

        btCasa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CasaGUI casaGUI = new CasaGUI();
            }
        });

        btPatrono.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PatronoGUI patronoGUI = new PatronoGUI();
            }
        });

        btVarinha.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VarinhaGUI varinhaGUI = new VarinhaGUI();
            }
        });

        setSize(350, 200);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private static class JGradientButtonSimple extends JButton {
//      Quando trabalhamos com herança a superclasse é a classe que herdamos e sub classe é a classe que herda da superclasse.
//
//      A subclasse pode sobrescrever métodos da superclasse e, claro, implementar seus próprios métodos. 
//      Cada classe possui duas referências: o this, que referencia a instância dela mesma e o super que referencia a superclasse.

        private static final long serialVersionUID = 1L;
        private Color stopTop;
        private Color stopBottom;
        private Paint colorGradient;
        private Point[] stopPoints = new Point[2]; 

        public JGradientButtonSimple(Color stopTop, Color stopBottom) {
            this("", stopTop, stopBottom);
        }

        public JGradientButtonSimple(String text, Color stopTop, Color stopBottom) {
            this(text, null, stopTop, stopBottom);
        }

        public JGradientButtonSimple(String text, Icon icon, Color stopTop, Color stopBottom) {
            super(text, icon);

            setContentAreaFilled(false);
            setFocusPainted(false);

            this.stopTop = stopTop;
            this.stopBottom = stopBottom;

            addChangeListener(new ChangeListener() {
                @Override
                public void stateChanged(ChangeEvent e) {
                    invalidate();
                }
            });
        }

        public void invalidate() {
            super.invalidate();

            stopPoints[0] = new Point(0, 0);
            stopPoints[1] = new Point(0, getHeight());

            if (getModel().isPressed()) {
                colorGradient = new GradientPaint(stopPoints[0], stopBottom, stopPoints[1], stopTop);
            } else {
                colorGradient = new GradientPaint(stopPoints[0], stopTop, stopPoints[1], stopBottom);
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();

            g2.setPaint(colorGradient);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();

            super.paintComponent(g);
        }

    }
}
