/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUIs;

import DAOs.DAOCasa;
import DAOs.DAOPatrono;
import Entidades.Pessoa;
import DAOs.DAOPessoa;
import DAOs.DAOVarinha;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.util.Arrays;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

import DAOs.DAOCasa;
import DAOs.DAOPatrono;
import DAOs.DAOPessoa;
import DAOs.DAOVarinha;
import Entidades.Pessoa;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import static javax.swing.SwingConstants.CENTER;
import static javax.swing.SwingConstants.TOP;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;

/**
 *
 * @author Erick 05/07/2023 - 15:04:27
 */
public class PessoaGUI extends JDialog {

    Container cp;
    TestPanel pnNorte = new TestPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    DLabel lbEmail = new DLabel("Email");
    JTextField tfEmail = new JTextField(45);
    JLabel lbNomePessoa = new JLabel("NomePessoa");
    JTextField tfNomePessoa = new JTextField(30);
    JLabel lbDataDeNascimento = new JLabel("DataDeNascimento");
    JTextField tfDataDeNascimento = new JTextField(30);
    JLabel lbSenha = new JLabel("Senha");
    JTextField tfSenha = new JTextField(30);

    JLabel lbVarinha = new JLabel("Varinha");
    DefaultComboBoxModel comboBoxModelVarinha = new DefaultComboBoxModel();
    JComboBox cbVarinha = new JComboBox(comboBoxModelVarinha);

    JLabel lbCasa = new JLabel("Casa");
    DefaultComboBoxModel comboBoxModelCasa = new DefaultComboBoxModel();
    JComboBox cbCasa = new JComboBox(comboBoxModelCasa);

    JLabel lbPatrono = new JLabel("Patrono");
    DefaultComboBoxModel comboBoxModelPatrono = new DefaultComboBoxModel();
    JComboBox cbPatrono = new JComboBox(comboBoxModelPatrono);

    JLabel lbVazio = new JLabel("");
    DAOPessoa daoPessoa = new DAOPessoa();
    Pessoa pessoa = new Pessoa();
    String[] colunas = new String[]{"email", "nomePessoa", "dataDeNascimento", "senha", "varinhaNomeVarinha", "casaNomeCasa", "patronoAnimal"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    public PessoaGUI() {
        Font gizmo = null;
        Font gizmo_lista = null;

        try {
            gizmo = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/gizmo.ttf"));
        } catch (Exception e) {
            System.out.println("Merda " + e);
        }

        gizmo = gizmo.deriveFont(Font.PLAIN, 36);
        gizmo_lista = gizmo.deriveFont(Font.PLAIN, 26);
        Font roboto = null;
        try {
            roboto = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Roboto-Medium.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }
        roboto = roboto.deriveFont(Font.PLAIN, 18);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Pessoa");

        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(20);
        tabela.setFont(roboto);

        //cabeçalho
        tabela.getTableHeader().setBackground(new Color(127,255,212));
        tabela.getTableHeader().setForeground(new Color(0, 0, 0));
        tabela.getTableHeader().setFont(roboto);
        //cor da linha da tabela
        tabela.setGridColor(new Color(0, 0, 0));
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(new Color(135, 206, 250));
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        btListar.setFont(roboto);
        btBuscar.setFont(roboto);
        btAdicionar.setFont(roboto);
        btSalvar.setFont(roboto);
        btCancelar.setFont(roboto);
        btExcluir.setFont(roboto);
        btAlterar.setFont(roboto);
        lbEmail.setFont(roboto);
        tfEmail.setFont(roboto);
        pnNorte.add(lbEmail);
        pnNorte.add(tfEmail);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        tfNomePessoa.setEditable(false);
        tfDataDeNascimento.setEditable(false);
        tfSenha.setEditable(false);

        cbVarinha.setEnabled(false);
        cbCasa.setEnabled(false);
        cbPatrono.setEnabled(false);

        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));
        lbNomePessoa.setHorizontalAlignment(SwingConstants.CENTER);
        lbDataDeNascimento.setHorizontalAlignment(SwingConstants.CENTER);
        lbSenha.setHorizontalAlignment(SwingConstants.CENTER);
        lbVarinha.setHorizontalAlignment(SwingConstants.CENTER);
        lbCasa.setHorizontalAlignment(SwingConstants.CENTER);
        lbPatrono.setHorizontalAlignment(SwingConstants.CENTER);

        lbNomePessoa.setFont(roboto);
        tfNomePessoa.setFont(roboto);
        lbDataDeNascimento.setFont(roboto);
        tfDataDeNascimento.setFont(roboto);
        lbSenha.setFont(roboto);
        tfSenha.setFont(roboto);
        lbVarinha.setFont(roboto);
        cbVarinha.setFont(roboto);
        lbCasa.setFont(roboto);
        cbCasa.setFont(roboto);
        lbPatrono.setFont(roboto);
        cbPatrono.setFont(roboto);

        pnCentro.add(lbNomePessoa);
        pnCentro.add(tfNomePessoa);
        pnCentro.add(lbDataDeNascimento);
        pnCentro.add(tfDataDeNascimento);
        pnCentro.add(lbSenha);
        pnCentro.add(tfSenha);
        pnCentro.add(lbVarinha);
        pnCentro.add(cbVarinha);
        pnCentro.add(lbCasa);
        pnCentro.add(cbCasa);
        pnCentro.add(lbPatrono);
        pnCentro.add(cbPatrono);
        
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));

        DAOVarinha daoVarinha = new DAOVarinha();
        String[] listaVarinha = daoVarinha.listInOrderNomeStringsArray();
        for (String s : listaVarinha) {
            String[] aux = s.split("-");
            comboBoxModelVarinha.addElement(aux[0]);
        }

        DAOCasa daoCasa = new DAOCasa();
        String[] listaCasa = daoCasa.listInOrderNomeStringsArray();
        for (String s : listaCasa) {
            String[] aux = s.split("-");
            comboBoxModelCasa.addElement(aux[0]);
        }

        DAOPatrono daoPatrono = new DAOPatrono();
        String[] listaPatrono = daoPatrono.listInOrderNomeStringsArray();
        for (String s : listaPatrono) {
            String[] aux = s.split("-");
            comboBoxModelPatrono.addElement(aux[0]);
        }

        cbVarinha.setSelectedIndex(0);
        cbCasa.setSelectedIndex(0);
        cbPatrono.setSelectedIndex(0);

// listener Buscar
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    pessoa = daoPessoa.obter(tfEmail.getText());
                    if (pessoa != null) {//achou o pessoa na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        tfNomePessoa.setText(String.valueOf(pessoa.getNomePessoa()));
                        tfNomePessoa.setEditable(false);
                        tfDataDeNascimento.setText(new SimpleDateFormat("dd/MM/yyyy").format(pessoa.getDataDeNascimento()));
                        tfSenha.setText(String.valueOf(pessoa.getSenha()));
                        tfSenha.setEditable(false);

                        cbVarinha.setEnabled(false);
                        cbCasa.setEnabled(false);
                        cbPatrono.setEnabled(false);

                        int i = 0;

                        //combobox da Casa
                        for (i = 0; i < listaCasa.length; i++) {
//                            System.out.println(listaCasa[i].split(";")[0]);
//                            System.out.println(pessoa.getCasaNomeCasa().toString().split(";")[0]);
                            String aux[] = listaCasa[i].split(";");
                            String aux2[] = aux[0].split("-");
                            
                            System.out.println(aux[0]);
                            System.out.println(aux2[0]);

                            if (aux2[0].toString().equals(pessoa.getCasaNomeCasa().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaCasa.length) {
                            cbCasa.setSelectedIndex(i);
                        }

                        //combobox da Patrono
                        for (i = 0; i < listaPatrono.length; i++) {
                            String aux[] = listaPatrono[i].split(";");
                            String aux2[] = aux[0].split("-");
                            
                            if (aux2[0].toString().equals(pessoa.getPatronoAnimal().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaPatrono.length) {
                            cbPatrono.setSelectedIndex(i);
                        }
                        
                        //combobox da Varinha
                        for (i = 0; i < listaVarinha.length; i++) {
                            String aux[] = listaVarinha[i].split(";");
                            String aux2[] = aux[0].split("-");
                            
                            if (aux2[0].toString().equals(pessoa.getVarinhaNomeVarinha().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaVarinha.length) {
                            cbVarinha.setSelectedIndex(i);
                        }

                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        tfNomePessoa.setText("");
                        tfNomePessoa.setEditable(false);
                        tfDataDeNascimento.setText("");
                        tfDataDeNascimento.setEditable(false);
                        tfSenha.setText("");
                        tfSenha.setEditable(false);
                        cbVarinha.setSelectedIndex(0);
                        cbCasa.setSelectedIndex(0);
                        cbPatrono.setSelectedIndex(0);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfEmail.setEnabled(false);
                tfNomePessoa.requestFocus();
                tfNomePessoa.setEditable(true);
                tfDataDeNascimento.setEditable(true);
                tfSenha.setEditable(true);
                cbVarinha.setEnabled(true);
                cbCasa.setEnabled(true);
                cbPatrono.setEnabled(true);
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Short cb_BD;    //fazendo isso pq em no BD boolean é tiny_int que é = ao short
                if (acao.equals("adicionar")) {
                    pessoa = new Pessoa();
                }
                try {
                    pessoa.setEmail(tfEmail.getText());
                    pessoa.setNomePessoa(tfNomePessoa.getText());
                    sdf.setLenient(false);
                    Date data = sdf.parse(tfDataDeNascimento.getText());
                    pessoa.setDataDeNascimento(data);
                    pessoa.setDataDeNascimento(cf.converteDeStringParaDate(tfDataDeNascimento.getText()));
                    pessoa.setSenha(tfSenha.getText());
                    
                    pessoa.setCasaNomeCasa(daoCasa.obter((String.valueOf(cbCasa.getSelectedItem().toString().split("-")[0])))); // não tá separando os ; ta ficando tipo: Sonserina;Verde
                    pessoa.setPatronoAnimal(daoPatrono.obter((String.valueOf(cbPatrono.getSelectedItem().toString().split("-")[0]))));
                    pessoa.setVarinhaNomeVarinha(daoVarinha.obter((String.valueOf(cbVarinha.getSelectedItem().toString().split("-")[0]))));
                    
                    System.out.println(daoCasa.obter(String.valueOf(cbCasa.getSelectedItem().toString().split("-")[0])).getNomeCasa()); //printa igual
                    
                    
                    if (acao.equals("adicionar")) {
                        System.out.println(pessoa);
                        daoPessoa.inserir(pessoa);
                    } else {
                        daoPessoa.atualizar(pessoa);
                    }
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    tfEmail.setEnabled(true);
                    tfEmail.setEditable(true);
                    tfEmail.setText("");
                    tfNomePessoa.setEnabled(true);
                    tfNomePessoa.setEditable(false);
                    tfNomePessoa.requestFocus();
                    tfNomePessoa.setText("");
                    tfDataDeNascimento.setEnabled(true);
                    tfDataDeNascimento.setEditable(false);
                    tfDataDeNascimento.requestFocus();
                    tfDataDeNascimento.setText("");
                    tfSenha.setEnabled(true);
                    tfSenha.setEditable(false);
                    tfSenha.requestFocus();
                    tfSenha.setText("");
                    cbVarinha.setEnabled(false);
                    cbCasa.setEnabled(false);
                    cbPatrono.setEnabled(false);
                    cbVarinha.setSelectedIndex(0);
                    cbCasa.setSelectedIndex(0);
                    cbPatrono.setSelectedIndex(0);

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);

                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfEmail.setEditable(false);
                tfNomePessoa.setEditable(true);
                tfDataDeNascimento.setEditable(true);
                tfSenha.setEditable(true);
                cbVarinha.setEnabled(true);
                cbCasa.setEnabled(true);
                cbPatrono.setEnabled(true);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                tfEmail.setEnabled(true);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                tfEmail.setEnabled(true);
                tfEmail.setEditable(true);
                tfEmail.requestFocus();
                tfEmail.setText("");
                tfNomePessoa.setText("");
                tfNomePessoa.setEditable(false);
                tfDataDeNascimento.setText("");
                tfDataDeNascimento.setEditable(false);
                tfSenha.setText("");
                tfSenha.setEditable(false);

                cbVarinha.setEnabled(false);
                cbCasa.setEnabled(false);
                cbPatrono.setEnabled(false);
                cbVarinha.setSelectedIndex(0);
                cbCasa.setSelectedIndex(0);
                cbPatrono.setSelectedIndex(0);

                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoPessoa.remover(pessoa);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Pessoa> listaPessoa = daoPessoa.list();
                System.out.println(daoPessoa.list());
                String[] colunas = new String[]{"Email", "Nome", "DataDeNascimento", "Senha", "Varinha", "Casa", "Patrono"};
                String[][] dados = new String[listaPessoa.size()][colunas.length];
                String aux[];
                
                for (int i = 0; i < listaPessoa.size(); i++) {
                    aux = listaPessoa.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                tfNomePessoa.setEditable(false);
                tfDataDeNascimento.setEditable(false);
                tfSenha.setEditable(false);
                cbVarinha.setEnabled(false);
                cbCasa.setEnabled(false);
                cbPatrono.setEnabled(false);
//cor do background e da letra de cada coluna
                coluna1.setBackground(new Color(220, 220, 220));
                coluna1.setForeground(Color.black);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(2).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(3).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(4).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(5).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(6).setCellRenderer(coluna1);
            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfEmail.setText("");
                tfEmail.requestFocus();
                tfEmail.setEnabled(true);
                tfEmail.setEditable(true);
                tfNomePessoa.setText("");
                tfNomePessoa.setEditable(false);
                tfDataDeNascimento.setText("");
                tfDataDeNascimento.setEditable(false);
                tfSenha.setText("");
                tfSenha.setEditable(false);
                cbVarinha.setEnabled(false);
                cbCasa.setEnabled(false);
                cbPatrono.setEnabled(false);
                cbVarinha.setSelectedIndex(0);
                cbCasa.setSelectedIndex(0);
                cbPatrono.setSelectedIndex(0);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai da classe
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI
    public class DLabel extends JLabel {

        public DLabel(String name) {
            this.setForeground(Color.WHITE);
            this.setText(name);
            this.setOpaque(true);
            this.setHorizontalAlignment(CENTER);
            this.setBorder(BorderFactory.createBevelBorder(TOP, Color.black, Color.black));
        }

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.GREEN;
            Color color2 = Color.BLUE;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }

    }//fim da classe
    
    public class TestPanel extends JPanel {

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.GREEN;
            Color color2 = Color.BLUE;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }
    }
} //fim da classe
