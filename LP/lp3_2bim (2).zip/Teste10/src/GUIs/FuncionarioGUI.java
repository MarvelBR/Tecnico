package GUIs;

import Entidades.Funcionario;
import DAOs.DAOFuncionario;
import DAOs.DAOPessoa;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Arrays;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import static javax.swing.SwingConstants.CENTER;
import static javax.swing.SwingConstants.TOP;

/**
 *
 * @author Erick 06/07/2023 - 19:03:37
 */
public class FuncionarioGUI extends JDialog {

    Container cp;
    TestPanel pnNorte = new TestPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    DLabel lbPessoaEmail = new DLabel("PessoaEmail");
    DefaultComboBoxModel comboBoxModelPessoa = new DefaultComboBoxModel();
    JComboBox cbPessoa = new JComboBox(comboBoxModelPessoa);
    JLabel lbCargo = new JLabel("Cargo");
    JTextField tfCargo = new JTextField(30);
    JLabel lbVazio = new JLabel("");
    DAOFuncionario daoFuncionario = new DAOFuncionario();
    Funcionario funcionario = new Funcionario();
    String[] colunas = new String[]{"pessoaEmail", "cargo"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    public FuncionarioGUI() {
        Font gizmo = null;
        Font gizmo_lista = null;

        try {
            gizmo = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/gizmo.ttf"));
        } catch (Exception e) {
            System.out.println("Merda " + e);
        }

        gizmo = gizmo.deriveFont(Font.PLAIN, 36);
        gizmo_lista = gizmo.deriveFont(Font.PLAIN, 26);
        Font roboto = null;
        try {
            roboto = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Roboto-Medium.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }
        roboto = roboto.deriveFont(Font.PLAIN, 18);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Funcionario");

        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(20);
        tabela.setFont(roboto);

        //cabeçalho
        tabela.getTableHeader().setBackground(Color.DARK_GRAY);
        tabela.getTableHeader().setForeground(new Color(0, 0, 0));
        tabela.getTableHeader().setFont(gizmo_lista);
        //cor da linha da tabela
        tabela.setGridColor(new Color(0, 0, 0));
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(new Color(135, 206, 250));
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        btListar.setFont(roboto);
        btBuscar.setFont(roboto);
        btAdicionar.setFont(roboto);
        btSalvar.setFont(roboto);
        btCancelar.setFont(roboto);
        btExcluir.setFont(roboto);
        btAlterar.setFont(roboto);
        lbPessoaEmail.setFont(roboto);
        cbPessoa.setFont(roboto);
        pnNorte.add(lbPessoaEmail);
        pnNorte.add(cbPessoa);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        tfCargo.setEditable(false);
        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));
        lbCargo.setHorizontalAlignment(SwingConstants.CENTER);

        lbCargo.setFont(roboto);
        tfCargo.setFont(roboto);

        pnCentro.add(lbCargo);
        pnCentro.add(tfCargo);
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));
        
        DAOPessoa daoPessoa = new DAOPessoa();
        String[] listaPessoa = daoPessoa.listInOrderNomeStringsArray();
        Arrays.sort(listaPessoa);
        for (String s : listaPessoa) {
            String[] aux = s.split("-");
            comboBoxModelPessoa.addElement(aux[0]);
        }
        
        cbPessoa.setSelectedIndex(0);

// listener Buscar
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    funcionario = daoFuncionario.obter((String.valueOf(cbPessoa.getSelectedItem().toString().split("-")[0])));
                    if (funcionario != null) {//achou o funcionario na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        tfCargo.setText(String.valueOf(funcionario.getCargo()));
                        tfCargo.setEditable(false);
                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        tfCargo.setText("");
                        tfCargo.setEditable(false);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cbPessoa.setEnabled(false);
                tfCargo.requestFocus();
                tfCargo.setEditable(true);
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Short cb_BD;    //fazendo isso pq em no BD boolean é tiny_int que é = ao short
                if (acao.equals("adicionar")) {
                    funcionario = new Funcionario();
                }
                try {
                    funcionario.setPessoaEmail((String.valueOf(cbPessoa.getSelectedItem().toString().split("-")[0])));
                    funcionario.setCargo(tfCargo.getText());
                    if (acao.equals("adicionar")) {
                        daoFuncionario.inserir(funcionario);
                    } else {
                        daoFuncionario.atualizar(funcionario);
                    }
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    cbPessoa.setEnabled(true);
                    cbPessoa.setSelectedIndex(0);
                    tfCargo.setEnabled(true);
                    tfCargo.setEditable(false);
                    tfCargo.requestFocus();
                    tfCargo.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);

                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                cbPessoa.setEnabled(false);
                tfCargo.setEditable(true);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                cbPessoa.setEnabled(true);
                cbPessoa.requestFocus();
                cbPessoa.setSelectedIndex(0);
                tfCargo.setText("");
                tfCargo.setEditable(false);
                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoFuncionario.remover(funcionario);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Funcionario> listaFuncionario = daoFuncionario.list();
                String[] colunas = new String[]{"PessoaEmail", "Cargo"};
                String[][] dados = new String[listaFuncionario.size()][colunas.length];
                String aux[];
                for (int i = 0; i < listaFuncionario.size(); i++) {
                    aux = listaFuncionario.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                tfCargo.setEditable(false);//cor do background e da letra de cada coluna
                coluna1.setBackground(new Color(220, 220, 220));
                coluna1.setForeground(Color.WHITE);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                cbPessoa.requestFocus();
                cbPessoa.setEnabled(true);
                cbPessoa.setSelectedIndex(0);
                tfCargo.setText("");
                tfCargo.setEditable(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai da classe
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI
    
    public class DLabel extends JLabel {

        public DLabel(String name) {
            this.setForeground(Color.WHITE);
            this.setText(name);
            this.setOpaque(true);
            this.setHorizontalAlignment(CENTER);
            this.setBorder(BorderFactory.createBevelBorder(TOP, Color.black, Color.black));
        }

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.DARK_GRAY;
            Color color2 = Color.LIGHT_GRAY;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }

    }//fim da classe

    public class TestPanel extends JPanel {

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.DARK_GRAY;
            Color color2 = Color.LIGHT_GRAY;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }
    }
} //fim da classe
