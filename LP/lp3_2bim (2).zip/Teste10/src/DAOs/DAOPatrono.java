package DAOs;

import Entidades.Patrono;
import java.util.ArrayList;
import java.util.List;

public class DAOPatrono extends DAOGenerico<Patrono> {

    private List<Patrono> lista = new ArrayList<>();

    public DAOPatrono() {
        super(Patrono.class);
    }

    public int autoPatrono() {
        Integer a = (Integer) em.createQuery("SELECT MAX (e.animal) FROM Patrono e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Patrono> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Patrono e WHERE e.animal) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Patrono> listById(int id) {
        return em.createQuery("SELECT e FROM Patrono + e WHERE e.animal= :id").setParameter("id", id).getResultList();
    }

    public List<Patrono> listInOrderNome() {
        return em.createQuery("SELECT e FROM Patrono e ORDER BY e.tamanho").getResultList();
    }

    public List<Patrono> listInOrderId() {
        return em.createQuery("SELECT e FROM Patrono e ORDER BY e.animal").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Patrono> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getAnimal() + "-" + lf.get(i).getTamanho());
        }
        return ls;
    }
    
    public String[] listInOrderNomeStringsArray() {
        List<Patrono> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getAnimal() + "-" + lf.get(i).getTamanho());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOPatrono daoPatrono = new DAOPatrono();
        List<Patrono> listaPatrono = daoPatrono.list();
        for (Patrono patrono : listaPatrono) {
            System.out.println(patrono.getAnimal() + "=" + patrono.getTamanho());
        }
    }
}
