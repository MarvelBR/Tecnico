package DAOs;

import Entidades.Casa;
import java.util.ArrayList;
import java.util.List;

public class DAOCasa extends DAOGenerico<Casa> {

    private List<Casa> lista = new ArrayList<>();

    public DAOCasa() {
        super(Casa.class);
    }

    public int autoCasa() {
        Integer a = (Integer) em.createQuery("SELECT MAX (e.nomeCasa) FROM Casa e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Casa> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Casa e WHERE e.nomeCasa) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Casa> listById(int id) {
        return em.createQuery("SELECT e FROM Casa + e WHERE e.nomeCasa= :id").setParameter("id", id).getResultList();
    }

    public List<Casa> listInOrderNome() {
        return em.createQuery("SELECT e FROM Casa e ORDER BY e.corCasa").getResultList();
    }

    public List<Casa> listInOrderId() {
        return em.createQuery("SELECT e FROM Casa e ORDER BY e.nomeCasa").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Casa> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getNomeCasa() + "-" + lf.get(i).getCorCasa());
        }
        return ls;
    }
    
    public String[] listInOrderNomeStringsArray() {
        List<Casa> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getNomeCasa() + "-" + lf.get(i).getCorCasa());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOCasa daoCasa = new DAOCasa();
        List<Casa> listaCasa = daoCasa.list();
        for (Casa casa : listaCasa) {
            System.out.println(casa.getNomeCasa() + "=" + casa.getCorCasa());
        }
    }
}
