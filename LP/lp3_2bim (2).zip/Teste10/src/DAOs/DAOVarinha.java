package DAOs;

import Entidades.Varinha;
import java.util.ArrayList;
import java.util.List;

public class DAOVarinha extends DAOGenerico<Varinha> {

    private List<Varinha> lista = new ArrayList<>();

    public DAOVarinha() {
        super(Varinha.class);
    }

    public int autoVarinha() {
        Integer a = (Integer) em.createQuery("SELECT MAX (e.nomeVarinha) FROM Varinha e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Varinha> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Varinha e WHERE e.nomeVarinha) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Varinha> listById(int id) {
        return em.createQuery("SELECT e FROM Varinha + e WHERE e.nomeVarinha= :id").setParameter("id", id).getResultList();
    }

    public List<Varinha> listInOrderNome() {
        return em.createQuery("SELECT e FROM Varinha e ORDER BY e.madeira").getResultList();
    }

    public List<Varinha> listInOrderId() {
        return em.createQuery("SELECT e FROM Varinha e ORDER BY e.nomeVarinha").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Varinha> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getNomeVarinha() + "-" + lf.get(i).getMadeira());
        }
        return ls;
    }
    
    public String[] listInOrderNomeStringsArray(){
        List<Varinha> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getNomeVarinha() + "-" + lf.get(i).getMadeira());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOVarinha daoVarinha = new DAOVarinha();
        List<Varinha> listaVarinha = daoVarinha.list();
        for (Varinha varinha : listaVarinha) {
            System.out.println(varinha.getNomeVarinha() + "=" + varinha.getMadeira());
        }
    }
}
