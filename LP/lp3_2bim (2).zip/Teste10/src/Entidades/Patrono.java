/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author erick
 */
@Entity
@Table(name = "patrono")
@NamedQueries({
    @NamedQuery(name = "Patrono.findAll", query = "SELECT p FROM Patrono p")})
public class Patrono implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "patronoAnimal")
    private List<Pessoa> pessoaList;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "animal")
    private String animal;
    @Basic(optional = false)
    @Column(name = "tamanho")
    private String tamanho;

    public Patrono() {
    }

    public Patrono(String animal) {
        this.animal = animal;
    }

    public Patrono(String animal, String tamanho) {
        this.animal = animal;
        this.tamanho = tamanho;
    }

    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (animal != null ? animal.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Patrono)) {
            return false;
        }
        Patrono other = (Patrono) object;
        if ((this.animal == null && other.animal != null) || (this.animal != null && !this.animal.equals(other.animal))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return animal + ";" + tamanho;
    }

    public List<Pessoa> getPessoaList() {
        return pessoaList;
    }

    public void setPessoaList(List<Pessoa> pessoaList) {
        this.pessoaList = pessoaList;
    }
    
}
