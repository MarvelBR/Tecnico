/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author erick
 */
@Entity
@Table(name = "varinha")
@NamedQueries({
    @NamedQuery(name = "Varinha.findAll", query = "SELECT v FROM Varinha v")})
public class Varinha implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "varinhaNomeVarinha")
    private List<Pessoa> pessoaList;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "nome_varinha")
    private String nomeVarinha;
    @Basic(optional = false)
    @Column(name = "madeira")
    private String madeira;
    @Basic(optional = false)
    @Column(name = "nucleo")
    private String nucleo;
    @Basic(optional = false)
    @Column(name = "tamanho_cm")
    private double tamanhoCm;
    @Basic(optional = false)
    @Column(name = "quebrada")
    private short quebrada;

    public Varinha() {
    }

    public Varinha(String nomeVarinha) {
        this.nomeVarinha = nomeVarinha;
    }

    public Varinha(String nomeVarinha, String madeira, String nucleo, double tamanhoCm, short quebrada) {
        this.nomeVarinha = nomeVarinha;
        this.madeira = madeira;
        this.nucleo = nucleo;
        this.tamanhoCm = tamanhoCm;
        this.quebrada = quebrada;
    }

    public String getNomeVarinha() {
        return nomeVarinha;
    }

    public void setNomeVarinha(String nomeVarinha) {
        this.nomeVarinha = nomeVarinha;
    }

    public String getMadeira() {
        return madeira;
    }

    public void setMadeira(String madeira) {
        this.madeira = madeira;
    }

    public String getNucleo() {
        return nucleo;
    }

    public void setNucleo(String nucleo) {
        this.nucleo = nucleo;
    }

    public double getTamanhoCm() {
        return tamanhoCm;
    }

    public void setTamanhoCm(double tamanhoCm) {
        this.tamanhoCm = tamanhoCm;
    }

    public short getQuebrada() {
        return quebrada;
    }

    public void setQuebrada(short quebrada) {
        this.quebrada = quebrada;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nomeVarinha != null ? nomeVarinha.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Varinha)) {
            return false;
        }
        Varinha other = (Varinha) object;
        if ((this.nomeVarinha == null && other.nomeVarinha != null) || (this.nomeVarinha != null && !this.nomeVarinha.equals(other.nomeVarinha))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return nomeVarinha + ";" + madeira + ";" + nucleo + ";" + tamanhoCm + ";" + (quebrada == 1 ? "Sim" : "Não");
    }

    public List<Pessoa> getPessoaList() {
        return pessoaList;
    }

    public void setPessoaList(List<Pessoa> pessoaList) {
        this.pessoaList = pessoaList;
    }
    
}
