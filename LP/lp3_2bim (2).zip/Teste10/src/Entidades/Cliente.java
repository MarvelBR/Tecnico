/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author erick
 */
@Entity
@Table(name = "cliente")
@NamedQueries({
    @NamedQuery(name = "Cliente.findAll", query = "SELECT c FROM Cliente c")})
public class Cliente implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "pessoa_email")
    private String pessoaEmail;
    @Basic(optional = false)
    @Column(name = "pais")
    private String pais;
    @Basic(optional = false)
    @Column(name = "estado")
    private String estado;
    @Basic(optional = false)
    @Column(name = "rua_avenida")
    private String ruaAvenida;
    @Basic(optional = false)
    @Column(name = "numero_casa")
    private int numeroCasa;
    @JoinColumn(name = "pessoa_email", referencedColumnName = "email", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Pessoa pessoa;

    public Cliente() {
    }

    public Cliente(String pessoaEmail) {
        this.pessoaEmail = pessoaEmail;
    }

    public Cliente(String pessoaEmail, String pais, String estado, String ruaAvenida, int numeroCasa) {
        this.pessoaEmail = pessoaEmail;
        this.pais = pais;
        this.estado = estado;
        this.ruaAvenida = ruaAvenida;
        this.numeroCasa = numeroCasa;
    }

    public String getPessoaEmail() {
        return pessoaEmail;
    }

    public void setPessoaEmail(String pessoaEmail) {
        this.pessoaEmail = pessoaEmail;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getRuaAvenida() {
        return ruaAvenida;
    }

    public void setRuaAvenida(String ruaAvenida) {
        this.ruaAvenida = ruaAvenida;
    }

    public int getNumeroCasa() {
        return numeroCasa;
    }

    public void setNumeroCasa(int numeroCasa) {
        this.numeroCasa = numeroCasa;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pessoaEmail != null ? pessoaEmail.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cliente)) {
            return false;
        }
        Cliente other = (Cliente) object;
        if ((this.pessoaEmail == null && other.pessoaEmail != null) || (this.pessoaEmail != null && !this.pessoaEmail.equals(other.pessoaEmail))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return pessoaEmail + ";" + pais + ";" + estado + ";" + ruaAvenida + ";" + numeroCasa;
    }
    
}
