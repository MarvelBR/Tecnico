/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import tools.CaixaDeFerramentas;

/**
 *
 * @author erick
 */
@Entity
@Table(name = "pessoa")
@NamedQueries({
    @NamedQuery(name = "Pessoa.findAll", query = "SELECT p FROM Pessoa p")})
public class Pessoa implements Serializable {

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "pessoa")
    private Funcionario funcionario;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "pessoa")
    private Cliente cliente;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @Column(name = "nome_pessoa")
    private String nomePessoa;
    @Basic(optional = false)
    @Column(name = "data_de_nascimento")
    @Temporal(TemporalType.DATE)
    private Date dataDeNascimento;
    @Basic(optional = false)
    @Column(name = "senha")
    private String senha;
    @JoinColumn(name = "casa_nome_casa", referencedColumnName = "nome_casa")
    @ManyToOne(optional = false)
    private Casa casaNomeCasa;
    @JoinColumn(name = "patrono_animal", referencedColumnName = "animal")
    @ManyToOne(optional = false)
    private Patrono patronoAnimal;
    @JoinColumn(name = "varinha_nome_varinha", referencedColumnName = "nome_varinha")
    @ManyToOne(optional = false)
    private Varinha varinhaNomeVarinha;

    public Pessoa() {
    }

    public Pessoa(String email) {
        this.email = email;
    }

    public Pessoa(String email, String nomePessoa, Date dataDeNascimento, String senha) {
        this.email = email;
        this.nomePessoa = nomePessoa;
        this.dataDeNascimento = dataDeNascimento;
        this.senha = senha;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNomePessoa() {
        return nomePessoa;
    }

    public void setNomePessoa(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }

    public Date getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(Date dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Casa getCasaNomeCasa() {
        return casaNomeCasa;
    }

    public void setCasaNomeCasa(Casa casaNomeCasa) {
        this.casaNomeCasa = casaNomeCasa;
    }

    public Patrono getPatronoAnimal() {
        return patronoAnimal;
    }

    public void setPatronoAnimal(Patrono patronoAnimal) {
        this.patronoAnimal = patronoAnimal;
    }

    public Varinha getVarinhaNomeVarinha() {
        return varinhaNomeVarinha;
    }

    public void setVarinhaNomeVarinha(Varinha varinhaNomeVarinha) {
        this.varinhaNomeVarinha = varinhaNomeVarinha;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (email != null ? email.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pessoa)) {
            return false;
        }
        Pessoa other = (Pessoa) object;
        if ((this.email == null && other.email != null) || (this.email != null && !this.email.equals(other.email))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        return  email + ";" + nomePessoa + ";" + cf.converteDeDateParaString(dataDeNascimento) + ";" + senha + ";" + varinhaNomeVarinha.getNomeVarinha() + ";" + casaNomeCasa.getNomeCasa() + ";" + patronoAnimal.getAnimal();
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }
    
}
