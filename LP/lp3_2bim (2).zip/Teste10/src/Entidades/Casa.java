/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author erick
 */
@Entity
@Table(name = "casa")
@NamedQueries({
    @NamedQuery(name = "Casa.findAll", query = "SELECT c FROM Casa c")})
public class Casa implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "casaNomeCasa")
    private List<Pessoa> pessoaList;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "nome_casa")
    private String nomeCasa;
    @Basic(optional = false)
    @Column(name = "cor_casa")
    private String corCasa;

    public Casa() {
    }

    public Casa(String nomeCasa) {
        this.nomeCasa = nomeCasa;
    }

    public Casa(String nomeCasa, String corCasa) {
        this.nomeCasa = nomeCasa;
        this.corCasa = corCasa;
    }

    public String getNomeCasa() {
        return nomeCasa;
    }

    public void setNomeCasa(String nomeCasa) {
        this.nomeCasa = nomeCasa;
    }

    public String getCorCasa() {
        return corCasa;
    }

    public void setCorCasa(String corCasa) {
        this.corCasa = corCasa;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nomeCasa != null ? nomeCasa.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Casa)) {
            return false;
        }
        Casa other = (Casa) object;
        if ((this.nomeCasa == null && other.nomeCasa != null) || (this.nomeCasa != null && !this.nomeCasa.equals(other.nomeCasa))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return nomeCasa + ";" + corCasa;
    }

    public List<Pessoa> getPessoaList() {
        return pessoaList;
    }

    public void setPessoaList(List<Pessoa> pessoaList) {
        this.pessoaList = pessoaList;
    }
    
}
