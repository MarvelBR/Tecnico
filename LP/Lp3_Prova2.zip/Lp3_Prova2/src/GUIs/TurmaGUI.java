package GUIs;

import DAOs.DAOAluno;
import DAOs.DAOCurso;
import DAOs.DAONivel;
import DAOs.DAOProfessor;
import DAOs.DAOSalaAula;
import Entidades.Turma;
import DAOs.DAOTurma;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.util.Arrays;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;

/**
 *
 * @author helo 01/04/2024 - 21:48:18
 */
public class TurmaGUI extends JDialog {

    Container cp;
    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    JLabel lbIdTurma = new JLabel("IdTurma");
    JTextField tfIdTurma = new JTextField(30);
    
    JLabel lbAlunoId = new JLabel("Aluno (ID)");
    DefaultComboBoxModel comboBoxModelAluno = new DefaultComboBoxModel();
    JComboBox cbAluno = new JComboBox(comboBoxModelAluno);
    
    JLabel lbCursoId = new JLabel("Curso (ID)");
    DefaultComboBoxModel comboBoxModelCurso = new DefaultComboBoxModel();
    JComboBox cbCurso = new JComboBox(comboBoxModelCurso);
    
    
    JLabel lbNivelId = new JLabel("NivelId");
    DefaultComboBoxModel comboBoxModelNivel = new DefaultComboBoxModel();
    JComboBox cbNivel = new JComboBox(comboBoxModelNivel);
    
    
    JLabel lbSalaAulaId = new JLabel("SalaAulaId");
    DefaultComboBoxModel comboBoxModelSala = new DefaultComboBoxModel();
    JComboBox cbSala = new JComboBox(comboBoxModelSala);
    
    JLabel lbProfessorIdProfessor = new JLabel("ProfessorIdProfessor");
    DefaultComboBoxModel comboBoxModelProfessor = new DefaultComboBoxModel();
    JComboBox cbProfessor = new JComboBox(comboBoxModelProfessor);

    JLabel lbVazio = new JLabel("");
    DAOTurma daoTurma = new DAOTurma();
    Turma turma = new Turma();
    String[] colunas = new String[]{"idTurma", "alunoId", "cursoId", "nivelId", "salaAulaId", "professorIdProfessor"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    public TurmaGUI() {
        Font roboto = null;
        try {
            roboto = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Roboto-Medium.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }
        roboto = roboto.deriveFont(Font.PLAIN, 18);
        Font roboto_lista = roboto.deriveFont(Font.PLAIN, 16);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Turma");

        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(20);
        tabela.setFont(roboto_lista);

        //cabeçalho
        tabela.getTableHeader().setBackground(new Color(135, 206, 250));
        tabela.getTableHeader().setForeground(new Color(0, 0, 0));
        tabela.getTableHeader().setFont(roboto_lista);
        //cor da linha da tabela
        tabela.setGridColor(new Color(0, 0, 0));
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(new Color(135, 206, 250));
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        btListar.setFont(roboto);
        btBuscar.setFont(roboto);
        btAdicionar.setFont(roboto);
        btSalvar.setFont(roboto);
        btCancelar.setFont(roboto);
        btExcluir.setFont(roboto);
        btAlterar.setFont(roboto);
        lbIdTurma.setFont(roboto);
        tfIdTurma.setFont(roboto_lista);
        pnNorte.add(lbIdTurma);
        pnNorte.add(tfIdTurma);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        cbAluno.setEnabled(false);
        cbCurso.setEnabled(false);
        cbNivel.setEnabled(false);
        cbSala.setEnabled(false);
        cbProfessor.setEnabled(false);
        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));
        lbAlunoId.setHorizontalAlignment(SwingConstants.CENTER);
        lbCursoId.setHorizontalAlignment(SwingConstants.CENTER);
        lbNivelId.setHorizontalAlignment(SwingConstants.CENTER);
        lbSalaAulaId.setHorizontalAlignment(SwingConstants.CENTER);
        lbProfessorIdProfessor.setHorizontalAlignment(SwingConstants.CENTER);
        
        //CENTRALIZAR COMBOBOX
        DefaultListCellRenderer centralizar_CB = new DefaultListCellRenderer();
        centralizar_CB.setHorizontalAlignment(DefaultListCellRenderer.CENTER); // center-aligned items
        cbAluno.setRenderer(centralizar_CB);
        cbCurso.setRenderer(centralizar_CB);
        cbNivel.setRenderer(centralizar_CB);
        cbSala.setRenderer(centralizar_CB);
        cbProfessor.setRenderer(centralizar_CB);

        lbAlunoId.setFont(roboto);
        cbAluno.setFont(roboto);
        lbCursoId.setFont(roboto);
        cbCurso.setFont(roboto);
        lbNivelId.setFont(roboto);
        cbNivel.setFont(roboto);
        lbSalaAulaId.setFont(roboto);
        cbSala.setFont(roboto);
        lbProfessorIdProfessor.setFont(roboto);
        cbProfessor.setFont(roboto);

        pnCentro.add(lbAlunoId);
        pnCentro.add(cbAluno);
        pnCentro.add(lbCursoId);
        pnCentro.add(cbCurso);
        pnCentro.add(lbNivelId);
        pnCentro.add(cbNivel);
        pnCentro.add(lbSalaAulaId);
        pnCentro.add(cbSala);
        pnCentro.add(lbProfessorIdProfessor);
        pnCentro.add(cbProfessor);
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));
        
        DAOAluno daoAluno = new DAOAluno();
        String[] listaAluno = daoAluno.listInOrderNomeStringsArray();
        Arrays.sort(listaAluno);
        for (String s : listaAluno) {
            String[] aux = s.split("-");
            comboBoxModelAluno.addElement(aux[0]);
        }

        cbAluno.setSelectedIndex(0);

        DAOCurso daoCurso = new DAOCurso();
        String[] listaCurso = daoCurso.listInOrderNomeStringsArray();
        Arrays.sort(listaCurso);
        for (String s : listaCurso) {
            String[] aux = s.split("-");
            comboBoxModelCurso.addElement(aux[0]);
        }

        cbCurso.setSelectedIndex(0);
        
        DAONivel daoNivel = new DAONivel();
        String[] listaNivel = daoNivel.listInOrderNomeStringsArray();
        Arrays.sort(listaNivel);
        for (String s : listaNivel) {
            String[] aux = s.split("-");
            comboBoxModelNivel.addElement(aux[0]);
        }

        cbNivel.setSelectedIndex(0);

        DAOSalaAula daoSalaAula = new DAOSalaAula();
        String[] listaSalaAula = daoSalaAula.listInOrderNomeStringsArray();
        Arrays.sort(listaSalaAula);
        for (String s : listaSalaAula) {
            String[] aux = s.split("-");
            comboBoxModelSala.addElement(aux[0]);
        }

        cbSala.setSelectedIndex(0);
        
        DAOProfessor daoProfessor = new DAOProfessor();
        String[] listaProfessor = daoProfessor.listInOrderNomeStringsArray();
        Arrays.sort(listaProfessor);
        for (String s : listaProfessor) {
            String[] aux = s.split("-");
            comboBoxModelProfessor.addElement(aux[0]);
        }

        cbProfessor.setSelectedIndex(0);

// listener Buscar
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    turma = daoTurma.obter(Integer.valueOf(tfIdTurma.getText()));
                    if (turma != null) {//achou o turma na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        int i;
                        for (i = 0; i < listaAluno.length; i++) {
                            String aux[] = listaAluno[i].split(";");
                            String aux2[] = aux[0].split("-");

                            if (aux2[0].toString().equals(turma.getAlunoId().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaAluno.length) {
                            cbAluno.setSelectedIndex(i);
                        }

                        cbAluno.setEnabled(false);

                        for (i = 0; i < listaCurso.length; i++) {
                            String aux[] = listaCurso[i].split(";");
                            String aux2[] = aux[0].split("-");

                            if (aux2[0].toString().equals(turma.getCursoId().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaCurso.length) {
                            cbCurso.setSelectedIndex(i);
                        }

                        cbCurso.setEnabled(false);
                        
                        for (i = 0; i < listaNivel.length; i++) {
                            String aux[] = listaNivel[i].split(";");
                            String aux2[] = aux[0].split("-");

                            if (aux2[0].toString().equals(turma.getNivelId().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaNivel.length) {
                            cbNivel.setSelectedIndex(i);
                        }

                        cbNivel.setEnabled(false);
                        
                        for (i = 0; i < listaSalaAula.length; i++) {
                            String aux[] = listaSalaAula[i].split(";");
                            String aux2[] = aux[0].split("-");
                            System.out.println(aux2[0]);

                            if (aux2[0].toString().equals(turma.getSalaAulaId().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaSalaAula.length) {
                            cbSala.setSelectedIndex(i);
                        }

                        cbSala.setEnabled(false);
                        
                        for (i = 0; i < listaProfessor.length; i++) {
                            String aux[] = listaProfessor[i].split(";");
                            String aux2[] = aux[0].split("-");
                            System.out.println(aux2[0]);

                            if (aux2[0].toString().equals(turma.getProfessorIdProfessor().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaProfessor.length) {
                            cbProfessor.setSelectedIndex(i);
                        }

                        cbProfessor.setEnabled(false);
                        
                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        cbAluno.setEnabled(false);
                        cbAluno.setSelectedIndex(0);
                        cbCurso.setEnabled(false);
                        cbCurso.setSelectedIndex(0);
                        cbNivel.setEnabled(false);
                        cbNivel.setSelectedIndex(0);
                        cbSala.setEnabled(false);
                        cbSala.setSelectedIndex(0);
                        cbProfessor.setEnabled(false);
                        cbProfessor.setSelectedIndex(0);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfIdTurma.setEnabled(false);
                cbAluno.requestFocus();
                cbAluno.setEnabled(true);
                cbCurso.setEnabled(true);
                cbNivel.setEnabled(true);
                cbSala.setEnabled(true);
                cbProfessor.setEnabled(true);
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Short cb_BD;    //fazendo isso pq em no BD boolean é tiny_int que é = ao short
                if (acao.equals("adicionar")) {
                    turma = new Turma();
                }
                try {
                    turma.setIdTurma(Integer.valueOf(tfIdTurma.getText()));
                    turma.setAlunoId(daoAluno.obter((Integer.valueOf(cbAluno.getSelectedItem().toString().split("-")[0].trim()))));
                    turma.setCursoId(daoCurso.obter((Integer.valueOf(cbCurso.getSelectedItem().toString().split("-")[0].trim()))));
                    turma.setNivelId(daoNivel.obter((Integer.valueOf(cbNivel.getSelectedItem().toString().split("-")[0].trim()))));
                    turma.setSalaAulaId(daoSalaAula.obter((Integer.valueOf(cbSala.getSelectedItem().toString().split("-")[0].trim()))));
                    turma.setProfessorIdProfessor(daoProfessor.obter((Integer.valueOf(cbProfessor.getSelectedItem().toString().split("-")[0].trim()))));
                    if (acao.equals("adicionar")) {
                        daoTurma.inserir(turma);
                    } else {
                        daoTurma.atualizar(turma);
                    }
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    tfIdTurma.setEnabled(true);
                    tfIdTurma.setEditable(true);
                    tfIdTurma.setText("");
                    cbAluno.setEnabled(false);
                    cbAluno.requestFocus();
                    cbAluno.setSelectedIndex(0);
                    cbCurso.setEnabled(false);
                    cbCurso.requestFocus();
                    cbCurso.setSelectedIndex(0);
                    cbNivel.setEnabled(false);
                    cbNivel.requestFocus();
                    cbNivel.setSelectedIndex(0);
                    cbSala.setEnabled(false);
                    cbSala.requestFocus();
                    cbSala.setSelectedIndex(0);
                    cbProfessor.setEnabled(false);
                    cbProfessor.requestFocus();
                    cbProfessor.setSelectedIndex(0);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);

                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfIdTurma.setEditable(false);
                cbAluno.setEnabled(true);
                cbCurso.setEnabled(true);
                cbNivel.setEnabled(true);
                cbSala.setEnabled(true);
                cbProfessor.setEnabled(true);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                tfIdTurma.setEnabled(true);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                tfIdTurma.setEnabled(true);
                tfIdTurma.setEditable(true);
                tfIdTurma.requestFocus();
                tfIdTurma.setText("");
                cbAluno.setEnabled(false);
                cbAluno.setSelectedIndex(0);
                cbCurso.setEnabled(false);
                cbCurso.setSelectedIndex(0);
                cbNivel.setEnabled(false);
                cbNivel.setSelectedIndex(0);
                cbSala.setEnabled(false);
                cbSala.setSelectedIndex(0);
                cbProfessor.setEnabled(false);
                cbProfessor.setSelectedIndex(0);
                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoTurma.remover(turma);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Turma> listaTurma = daoTurma.list();
                String[] colunas = new String[]{"IdTurma", "AlunoId", "CursoId", "NivelId", "SalaAulaId", "ProfessorIdProfessor"};
                String[][] dados = new String[listaTurma.size()][colunas.length];
                String aux[];
                for (int i = 0; i < listaTurma.size(); i++) {
                    aux = listaTurma.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                cbAluno.setEnabled(false);
                cbCurso.setEnabled(false);
                cbNivel.setEnabled(false);
                cbSala.setEnabled(false);
                cbProfessor.setEnabled(false);
                //cor do background e da letra de cada coluna
                coluna1.setBackground(new Color(220, 220, 220));
                coluna1.setForeground(Color.BLUE);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(2).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(3).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(4).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(5).setCellRenderer(coluna1);
            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfIdTurma.setText("");
                tfIdTurma.requestFocus();
                tfIdTurma.setEnabled(true);
                tfIdTurma.setEditable(true);
                cbAluno.setEnabled(false);
                cbAluno.setSelectedIndex(0);
                cbCurso.setEnabled(false);
                cbCurso.setSelectedIndex(0);
                cbNivel.setEnabled(false);
                cbNivel.setSelectedIndex(0);
                cbSala.setEnabled(false);
                cbSala.setSelectedIndex(0);
                cbProfessor.setEnabled(false);
                cbProfessor.setSelectedIndex(0);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai da classe
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI
} //fim da classe
