package GUIs;

import DAOs.DAOAluno;
import DAOs.DAOCurso;
import Entidades.MatriculaAluno;
import DAOs.DAOMatriculaAluno;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.util.Arrays;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;

/**
 *
 * @author helo 01/04/2024 - 21:12:31
 */
public class MatriculaAlunoGUI extends JDialog {

    Container cp;
    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    JLabel lbIdMatriculaAluno = new JLabel("IdMatriculaAluno");
    JTextField tfIdMatriculaAluno = new JTextField(30);

    JLabel lbAlunoId = new JLabel("Aluno (ID)");
    DefaultComboBoxModel comboBoxModelAluno = new DefaultComboBoxModel();
    JComboBox cbAluno = new JComboBox(comboBoxModelAluno);

    JLabel lbCursoId = new JLabel("Curso (ID)");
    DefaultComboBoxModel comboBoxModelCurso = new DefaultComboBoxModel();
    JComboBox cbCurso = new JComboBox(comboBoxModelCurso);

    JLabel lbDataInicio = new JLabel("Data-Inicio");
    JTextField tfDataInicio = new JTextField(30);
    JLabel lbDataFim = new JLabel("Data-Fim");
    JTextField tfDataFim = new JTextField(30);

    JLabel lbSituacaoAluno = new JLabel("Situação");
    String situacao[] = {"Aprovado", "Reprovado", "Cursando"};
    JComboBox cbSituacao = new JComboBox(situacao);

    JLabel lbUltimaAtualizacao = new JLabel("UltimaAtualizacao");
    JTextField tfUltimaAtualizacao = new JTextField(30);
    JLabel lbVazio = new JLabel("");
    DAOMatriculaAluno daoMatriculaAluno = new DAOMatriculaAluno();
    MatriculaAluno matriculaAluno = new MatriculaAluno();
    String[] colunas = new String[]{"idMatriculaAluno", "alunoId", "cursoId", "dataInicio", "dataFim", "situacaoAluno", "ultimaAtualizacao"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    public MatriculaAlunoGUI() {
        Font roboto = null;
        try {
            roboto = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Roboto-Medium.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }
        roboto = roboto.deriveFont(Font.PLAIN, 18);
        Font roboto_lista = roboto.deriveFont(Font.PLAIN, 16);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - MatriculaAluno");

        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(20);
        tabela.setFont(roboto_lista);

        //cabeçalho
        tabela.getTableHeader().setBackground(new Color(135, 206, 250));
        tabela.getTableHeader().setForeground(new Color(0, 0, 0));
        tabela.getTableHeader().setFont(roboto_lista);
        //cor da linha da tabela
        tabela.setGridColor(new Color(0, 0, 0));
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(new Color(135, 206, 250));
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        btListar.setFont(roboto);
        btBuscar.setFont(roboto);
        btAdicionar.setFont(roboto);
        btSalvar.setFont(roboto);
        btCancelar.setFont(roboto);
        btExcluir.setFont(roboto);
        btAlterar.setFont(roboto);
        lbIdMatriculaAluno.setFont(roboto);
        tfIdMatriculaAluno.setFont(roboto_lista);
        pnNorte.add(lbIdMatriculaAluno);
        pnNorte.add(tfIdMatriculaAluno);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        cbAluno.setEnabled(false);
        cbCurso.setEnabled(false);
        tfDataInicio.setEditable(false);
        tfDataFim.setEditable(false);
        cbSituacao.setEnabled(false);
        tfUltimaAtualizacao.setEditable(false);
        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));
        lbAlunoId.setHorizontalAlignment(SwingConstants.CENTER);
        lbCursoId.setHorizontalAlignment(SwingConstants.CENTER);
        lbDataInicio.setHorizontalAlignment(SwingConstants.CENTER);
        lbDataFim.setHorizontalAlignment(SwingConstants.CENTER);
        lbSituacaoAluno.setHorizontalAlignment(SwingConstants.CENTER);
        lbUltimaAtualizacao.setHorizontalAlignment(SwingConstants.CENTER);

        //CENTRALIZAR COMBOBOX
        DefaultListCellRenderer centralizar_CB = new DefaultListCellRenderer();
        centralizar_CB.setHorizontalAlignment(DefaultListCellRenderer.CENTER); // center-aligned items
        cbAluno.setRenderer(centralizar_CB);
        cbCurso.setRenderer(centralizar_CB);
        cbSituacao.setRenderer(centralizar_CB);

        lbAlunoId.setFont(roboto);
        cbAluno.setFont(roboto);
        lbCursoId.setFont(roboto);
        cbCurso.setFont(roboto);
        lbDataInicio.setFont(roboto);
        tfDataInicio.setFont(roboto);
        lbDataFim.setFont(roboto);
        tfDataFim.setFont(roboto);
        lbSituacaoAluno.setFont(roboto);
        cbSituacao.setFont(roboto);
        lbUltimaAtualizacao.setFont(roboto);
        tfUltimaAtualizacao.setFont(roboto);

        pnCentro.add(lbAlunoId);
        pnCentro.add(cbAluno);
        pnCentro.add(lbCursoId);
        pnCentro.add(cbCurso);
        pnCentro.add(lbDataInicio);
        pnCentro.add(tfDataInicio);
        pnCentro.add(lbDataFim);
        pnCentro.add(tfDataFim);
        pnCentro.add(lbSituacaoAluno);
        pnCentro.add(cbSituacao);
        pnCentro.add(lbUltimaAtualizacao);
        pnCentro.add(tfUltimaAtualizacao);
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));

        DAOAluno daoAluno = new DAOAluno();
        String[] listaAluno = daoAluno.listInOrderNomeStringsArray();
        Arrays.sort(listaAluno);
        for (String s : listaAluno) {
            String[] aux = s.split("-");
            comboBoxModelAluno.addElement(aux[0]);
        }

        cbAluno.setSelectedIndex(0);

        DAOCurso daoCurso = new DAOCurso();
        String[] listaCurso = daoCurso.listInOrderNomeStringsArray();
        Arrays.sort(listaCurso);
        for (String s : listaCurso) {
            String[] aux = s.split("-");
            comboBoxModelCurso.addElement(aux[0] + "-" + aux[1]);
        }

        cbCurso.setSelectedIndex(0);

// listener Buscar
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    matriculaAluno = daoMatriculaAluno.obter(Integer.valueOf(tfIdMatriculaAluno.getText()));
                    if (matriculaAluno != null) {//achou o matriculaAluno na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        int i;
                        for (i = 0; i < listaAluno.length; i++) {
                            String aux[] = listaAluno[i].split(";");
                            String aux2[] = aux[0].split("-");

                            if (aux2[0].toString().equals(matriculaAluno.getAlunoId().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaAluno.length) {
                            cbAluno.setSelectedIndex(i);
                        }

                        cbAluno.setEnabled(false);

                        for (i = 0; i < listaCurso.length; i++) {
                            String aux[] = listaCurso[i].split(";");
                            String aux2[] = aux[0].split("-");

                            if (aux2[0].toString().equals(matriculaAluno.getCursoId().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaCurso.length) {
                            cbCurso.setSelectedIndex(i);
                        }

                        cbCurso.setEnabled(false);

                        tfDataInicio.setText(new SimpleDateFormat("dd/MM/yyyy").format(matriculaAluno.getDataInicio()));
                        tfDataFim.setText(new SimpleDateFormat("dd/MM/yyyy").format(matriculaAluno.getDataFim()));

                        for (i = 0; i < situacao.length; i++) {
                            String item = (String) cbSituacao.getItemAt(i);
                            if (item.equals(matriculaAluno.getSituacaoAluno())) {
                                break;
                            }
                        }
                        if (i < situacao.length) {
                            cbSituacao.setSelectedIndex(i);
                        }

                        cbSituacao.setEnabled(false);

                        tfUltimaAtualizacao.setText(String.valueOf(matriculaAluno.getUltimaAtualizacao()));
                        tfUltimaAtualizacao.setEditable(false);
                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        cbAluno.setEnabled(false);
                        cbAluno.setSelectedIndex(0);
                        cbCurso.setEnabled(false);
                        cbCurso.setSelectedIndex(0);
                        tfDataInicio.setText("");
                        tfDataInicio.setEditable(false);
                        tfDataFim.setText("");
                        tfDataFim.setEditable(false);
                        cbSituacao.setEnabled(false);
                        cbSituacao.setSelectedIndex(0);
                        tfUltimaAtualizacao.setText("");
                        tfUltimaAtualizacao.setEditable(false);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfIdMatriculaAluno.setEnabled(false);
                cbAluno.setEnabled(true);
                cbCurso.setEnabled(true);
                tfDataInicio.setEditable(true);
                tfDataFim.setEditable(true);
                cbSituacao.setEnabled(true);
                tfUltimaAtualizacao.setEditable(true);
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Short cb_BD;    //fazendo isso pq em no BD boolean é tiny_int que é = ao short
                if (acao.equals("adicionar")) {
                    matriculaAluno = new MatriculaAluno();
                }
                try {
                    matriculaAluno.setIdMatriculaAluno(Integer.valueOf(tfIdMatriculaAluno.getText()));
                    matriculaAluno.setAlunoId(daoAluno.obter((Integer.valueOf(cbAluno.getSelectedItem().toString().split("-")[0].trim()))));
                    matriculaAluno.setCursoId(daoCurso.obter((Integer.valueOf(cbCurso.getSelectedItem().toString().split("-")[0].trim()))));
                    sdf.setLenient(false);
                    Date data = sdf.parse(tfDataInicio.getText());
                    matriculaAluno.setDataInicio(data);
                    matriculaAluno.setDataInicio(cf.converteDeStringParaDate(tfDataInicio.getText()));
                    sdf.setLenient(false);
                    Date data2 = sdf.parse(tfDataFim.getText());
                    matriculaAluno.setDataFim(data2);
                    matriculaAluno.setDataFim(cf.converteDeStringParaDate(tfDataFim.getText()));
                    matriculaAluno.setSituacaoAluno(String.valueOf(cbSituacao.getSelectedItem()));
                    matriculaAluno.setUltimaAtualizacao(tfUltimaAtualizacao.getText());
                    if (acao.equals("adicionar")) {
                        daoMatriculaAluno.inserir(matriculaAluno);
                    } else {
                        daoMatriculaAluno.atualizar(matriculaAluno);
                    }
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    tfIdMatriculaAluno.setEnabled(true);
                    tfIdMatriculaAluno.setEditable(true);
                    tfIdMatriculaAluno.setText("");
                    cbAluno.setEnabled(false);
                    cbAluno.requestFocus();
                    cbAluno.setSelectedIndex(0);
                    cbCurso.setEnabled(false);
                    cbCurso.requestFocus();
                    cbCurso.setSelectedIndex(0);
                    tfDataInicio.setEnabled(true);
                    tfDataInicio.setEditable(false);
                    tfDataInicio.requestFocus();
                    tfDataInicio.setText("");
                    tfDataFim.setEnabled(true);
                    tfDataFim.setEditable(false);
                    tfDataFim.requestFocus();
                    tfDataFim.setText("");
                    cbSituacao.setEnabled(false);
                    cbSituacao.requestFocus();
                    cbSituacao.setSelectedIndex(0);
                    tfUltimaAtualizacao.setEnabled(true);
                    tfUltimaAtualizacao.setEditable(false);
                    tfUltimaAtualizacao.requestFocus();
                    tfUltimaAtualizacao.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);

                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfIdMatriculaAluno.setEditable(false);
                cbAluno.setEnabled(true);
                cbCurso.setEnabled(true);
                tfDataInicio.setEditable(true);
                tfDataFim.setEditable(true);
                cbSituacao.setEnabled(true);
                tfUltimaAtualizacao.setEditable(true);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                tfIdMatriculaAluno.setEnabled(true);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                tfIdMatriculaAluno.setEnabled(true);
                tfIdMatriculaAluno.setEditable(true);
                tfIdMatriculaAluno.requestFocus();
                tfIdMatriculaAluno.setText("");
                cbAluno.setEnabled(false);
                cbAluno.setSelectedIndex(0);
                cbCurso.setEnabled(false);
                cbCurso.setSelectedIndex(0);
                tfDataInicio.setText("");
                tfDataInicio.setEditable(false);
                tfDataFim.setText("");
                tfDataFim.setEditable(false);
                cbSituacao.setEnabled(false);
                cbSituacao.setSelectedIndex(0);
                tfUltimaAtualizacao.setText("");
                tfUltimaAtualizacao.setEditable(false);
                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoMatriculaAluno.remover(matriculaAluno);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<MatriculaAluno> listaMatriculaAluno = daoMatriculaAluno.list();
                String[] colunas = new String[]{"IdMatriculaAluno", "AlunoId", "CursoId", "DataInicio", "DataFim", "SituacaoAluno", "UltimaAtualizacao"};
                String[][] dados = new String[listaMatriculaAluno.size()][colunas.length];
                String aux[];
                for (int i = 0; i < listaMatriculaAluno.size(); i++) {
                    aux = listaMatriculaAluno.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                cbAluno.setEnabled(false);
                cbCurso.setEnabled(false);
                tfDataInicio.setEditable(false);
                tfDataFim.setEditable(false);
                cbSituacao.setEnabled(false);
                tfUltimaAtualizacao.setEditable(false);//cor do background e da letra de cada coluna
                coluna1.setBackground(new Color(220, 220, 220));
                coluna1.setForeground(Color.BLUE);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(2).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(3).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(4).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(5).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(6).setCellRenderer(coluna1);
            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfIdMatriculaAluno.setText("");
                tfIdMatriculaAluno.requestFocus();
                tfIdMatriculaAluno.setEnabled(true);
                tfIdMatriculaAluno.setEditable(true);
                cbAluno.setEnabled(false);
                cbAluno.setSelectedIndex(0);
                cbCurso.setEnabled(false);
                cbCurso.setSelectedIndex(0);
                tfDataInicio.setText("");
                tfDataInicio.setEditable(false);
                tfDataFim.setText("");
                tfDataFim.setEditable(false);
                cbSituacao.setEnabled(false);
                cbSituacao.setSelectedIndex(0);
                tfUltimaAtualizacao.setText("");
                tfUltimaAtualizacao.setEditable(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai da classe
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI
} //fim da classe
