/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public int lerStringA(String s1){
        int cont_a = 0;
        for (int i = 0; i < s1.length(); i++){
            if (s1.charAt(i) == 'a' || s1.charAt(i) == 'A'){
                cont_a = cont_a+1;

            }     
        }
        return cont_a;
    }
    public int lerStringE(String s1){
        int cont_e = 0;
        for (int i = 0; i < s1.length(); i++){
            if (s1.charAt(i) == 'e' || s1.charAt(i) == 'E'){
                cont_e = cont_e+1;

            }     
        }
        return cont_e;
    }
    public int lerStringI(String s1){
        int cont_i = 0;
        for (int i = 0; i < s1.length(); i++){
            if (s1.charAt(i) == 'i' || s1.charAt(i) == 'I'){
                cont_i = cont_i+1;

            }     
        }
        return cont_i;
    }
    public int lerStringO(String s1){
        int cont_o = 0;
        for (int i = 0; i < s1.length(); i++){
            if (s1.charAt(i) == 'o' || s1.charAt(i) == 'O'){
                cont_o = cont_o+1;

            }     
        }
        return cont_o;
    }
    public int lerStringU(String s1){
        int cont_u = 0;
        for (int i = 0; i < s1.length(); i++){
            if (s1.charAt(i) == 'u' || s1.charAt(i) == 'U'){
                cont_u = cont_u+1;

            }     
        }
        return cont_u;
    }
}