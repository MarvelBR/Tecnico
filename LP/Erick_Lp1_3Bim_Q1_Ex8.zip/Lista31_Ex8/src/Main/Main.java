/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        String s1 = entrada.lerString("Digite uma string");
        
        Processamento processamento = new Processamento();
        int cont_a = processamento.lerStringA(s1);
        int cont_e = processamento.lerStringE(s1);
        int cont_i = processamento.lerStringI(s1);
        int cont_o = processamento.lerStringO(s1);
        int cont_u = processamento.lerStringU(s1);
        
        Saida saida = new Saida();
        saida.imprimirString("A quantidade de A na string foram de:"+cont_a);
        saida.imprimirString("A quantidade de E na string foram de:"+cont_e);
        saida.imprimirString("A quantidade de I na string foram de:"+cont_i);
        saida.imprimirString("A quantidade de O na string foram de:"+cont_o);
        saida.imprimirString("A quantidade de U na string foram de:"+cont_u);
    }
    
}
