/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        Processamento processamento = new Processamento();
        Saida saida = new Saida();
        
        String s1 = entrada.lerString("Digite uma string");
        
        saida.imprimirString("A string sem todos os espaços em branco encontrados fica assim:");
        
        processamento.Verstring(s1);
        
    }
    
}
