/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public void Verstring(String s1){
        //remover espaços nas extremidades
        s1 = s1.trim();
        
        
        String aux= "";
        for (int i = 0; i < s1.length(); i++) {            
           if(s1.charAt(i)==' '){
               aux+= s1.charAt(i);  
               System.out.print(s1.charAt(i));
           }
            while (s1.charAt(i)==' ') {
                i++;
            }
            aux+= s1.charAt(i);            
        }
        System.out.println(aux);
        
    }
}
