package DAOs;

import Entidades.Tamanho;
import java.util.ArrayList;
import java.util.List;

public class DAOTamanho extends DAOGenerico<Tamanho> {

    private List<Tamanho> lista = new ArrayList<>();

    public DAOTamanho() {
        super(Tamanho.class);
    }

    public int autoTamanho() {
        Integer a = (Integer) em.createQuery("SELECT MAX (e.idtamanho) FROM Tamanho e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Tamanho> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Tamanho e WHERE e.idtamanho) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Tamanho> listById(int id) {
        return em.createQuery("SELECT e FROM Tamanho + e WHERE e.idtamanho= :id").setParameter("id", id).getResultList();
    }

    public List<Tamanho> listInOrderNome() {
        return em.createQuery("SELECT e FROM Tamanho e ORDER BY e.nome").getResultList();
    }

    public List<Tamanho> listInOrderId() {
        return em.createQuery("SELECT e FROM Tamanho e ORDER BY e.idtamanho").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Tamanho> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdtamanho() + "-" + lf.get(i).getNome());
        }
        return ls;
    }

    public String[] listInOrderNomeStringsArray() {
        List<Tamanho> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getIdtamanho() + "-" + lf.get(i).getNome());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOTamanho daoTamanho = new DAOTamanho();
        List<Tamanho> listaTamanho = daoTamanho.list();
        for (Tamanho tamanho : listaTamanho) {
            System.out.println(tamanho.getIdtamanho() + "=" + tamanho.getNome());
        }
    }
}
