package DAOs;

import java.util.List;
import Entidades.Cargo;
import java.util.ArrayList;

public class DAOCargo extends DAOGenerico<Cargo> {

    private List<Cargo> lista = new ArrayList<>();

    public DAOCargo() {
        super(Cargo.class);
    }

    public int autoIdCargo() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.id) FROM Cargo e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Cargo> listById(int id) {
        return em.createQuery("SELECT e FROM Cargo e WHERE e.id = :id").setParameter("id", id).getResultList();
    }

    public List<Cargo> listInOrderId() {
        return em.createQuery("SELECT e FROM Cargo e ORDER BY e.id").getResultList();
    }

    public List<Cargo> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Cargo e WHERE e.nome LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Cargo> listInOrderNome() {
        return em.createQuery("SELECT e FROM Cargo e ORDER BY e.nome").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Cargo> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdcargo()+ "-" + lf.get(i).getNome());
        }
        return ls;
    }

    public String[] listInOrderNomeStringsArray() {
        List<Cargo> lf = listInOrderId();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getIdcargo()+ "-" + lf.get(i).getNome());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOCargo daoCargo = new DAOCargo();
        List<Cargo> listaCargo = daoCargo.list();
        for (Cargo cargo : listaCargo) {
            System.out.println(cargo.getIdcargo() + "-" + cargo.getNome());
        }
    }
}
