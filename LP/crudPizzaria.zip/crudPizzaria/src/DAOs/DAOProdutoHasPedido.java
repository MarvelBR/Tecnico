package DAOs;

import java.util.ArrayList;
import java.util.List;
import Entidades.ProdutoHasPedido;
import Entidades.ProdutoHasPedidoPK;

public class DAOProdutoHasPedido extends DAOGenerico<ProdutoHasPedido> {

    private List<ProdutoHasPedido> lista = new ArrayList<>();

    public DAOProdutoHasPedido() {
        super(ProdutoHasPedido.class);
    }
    
    public ProdutoHasPedido obter(ProdutoHasPedidoPK produtoHasPedidoPk){
        return em.find(ProdutoHasPedido.class, produtoHasPedidoPk);
    }
    
    public int autoIdProdutoHasPedido() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.produtoHasPedidoPK) FROM ProdutoHasPedido e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<ProdutoHasPedido> listById(int id) {
        return em.createQuery("SELECT e FROM ProdutoHasPedido e WHERE e.produtoHasPedidoPK = :id").setParameter("produtoHasPedidoPK", id).getResultList();
    }

    public List<ProdutoHasPedido> listInOrderId() {
        return em.createQuery("SELECT e FROM ProdutoHasPedido e ORDER BY e.produtoHasPedidoPK").getResultList();
    }

    public List<ProdutoHasPedido> listByNome(String nome) {
        return em.createQuery("SELECT e FROM ProdutoHasPedido e WHERE e.quantidade LIKE :nome").setParameter("quantidade", "%" + nome + "%").getResultList();
    }

    public List<ProdutoHasPedido> listInOrderNome() {
        return em.createQuery("SELECT e FROM ProdutoHasPedido e ORDER BY e.quantidade").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<ProdutoHasPedido> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getProdutoHasPedidoPK() + "-" + lf.get(i).getQuantidade());
        }
        return ls;
    }

    public String[] listInOrderNomeStringsArray() {
        List<ProdutoHasPedido> lf = listInOrderId();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getProdutoHasPedidoPK() + "-" + lf.get(i).getQuantidade());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOProdutoHasPedido daoProdutoHasPedido = new DAOProdutoHasPedido();
        List<ProdutoHasPedido> listaProdutoHasPedido = daoProdutoHasPedido.list();
        for (ProdutoHasPedido produtoHasPedido : listaProdutoHasPedido) {
            System.out.println(produtoHasPedido.getProdutoHasPedidoPK() + "-" + produtoHasPedido.getQuantidade());
        }
    }
}
