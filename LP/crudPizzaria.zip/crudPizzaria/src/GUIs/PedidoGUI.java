package GUIs;

import Entidades.Pedido;
import DAOs.DAOPedido;
import DAOs.DAOPessoa;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Arrays;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import static javax.swing.SwingConstants.CENTER;
import static javax.swing.SwingConstants.TOP;

/**
 *
 * @author Erick 03/10/2023 - 22:04:44
 */
public class PedidoGUI extends JDialog {

    Container cp;
    JPanel pnNorte = new TestPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    DefaultTableCellRenderer coluna2 = new DefaultTableCellRenderer();
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    JLabel lbIdpedido = new JLabel("Idpedido");
    JTextField tfIdpedido = new JTextField(30);
    JLabel lbDataPedido = new JLabel("DataPedido");
    JTextField tfDataPedido = new JTextField(30);

    JLabel lbPessoaCpf = new JLabel("PessoaCpf");
    DefaultComboBoxModel comboBoxModelCpf = new DefaultComboBoxModel();
    JComboBox cbCpf = new JComboBox(comboBoxModelCpf);

    JLabel lbVazio = new JLabel("");
    DAOPedido daoPedido = new DAOPedido();
    Pedido pedido = new Pedido();
    String[] colunas = new String[]{"idpedido", "dataPedido", "pessoaCpf"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);


    public PedidoGUI() {

        Font Poppins = null;
        Font Poppins_lista = null;

        try {
            Poppins = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Poppins-Regular.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }

        Poppins = Poppins.deriveFont(Font.PLAIN, 20);
        Poppins_lista = Poppins.deriveFont(Font.PLAIN, 18);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Pedido");

        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(25);
        tabela.setFont(Poppins_lista);

        //cabeçalho
        tabela.getTableHeader().setFont(Poppins_lista);
        tabela.getTableHeader().setDefaultRenderer(coluna2);

//cor da linha da tabela
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(new Color(135, 206, 250));
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        btListar.setFont(Poppins);
        btBuscar.setFont(Poppins);
        btAdicionar.setFont(Poppins);
        btSalvar.setFont(Poppins);
        btCancelar.setFont(Poppins);
        btExcluir.setFont(Poppins);
        btAlterar.setFont(Poppins);
        lbIdpedido.setFont(Poppins);
        tfIdpedido.setFont(Poppins);
        pnNorte.add(lbIdpedido);
        pnNorte.add(tfIdpedido);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        tfDataPedido.setEditable(false);
        cbCpf.setEnabled(false);
        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));
        lbDataPedido.setHorizontalAlignment(SwingConstants.CENTER);
        lbPessoaCpf.setHorizontalAlignment(SwingConstants.CENTER);

        lbDataPedido.setFont(Poppins);
        tfDataPedido.setFont(Poppins);
        lbPessoaCpf.setFont(Poppins);
        cbCpf.setFont(Poppins);

        pnCentro.add(lbDataPedido);
        pnCentro.add(tfDataPedido);
        pnCentro.add(lbPessoaCpf);
        pnCentro.add(cbCpf);
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));

        DAOPessoa daoPessoa = new DAOPessoa();
        String[] listaPessoa = daoPessoa.listInOrderNomeStringsArray();
        Arrays.sort(listaPessoa);
        for (String s : listaPessoa) {
            String[] aux = s.split("-");
            comboBoxModelCpf.addElement(aux[0] + " - " + aux[1]);
        }

        cbCpf.setSelectedIndex(0);

// listener Buscar
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    pedido = daoPedido.obter(Integer.valueOf(tfIdpedido.getText()));
                    if (pedido != null) {//achou o pedido na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        tfDataPedido.setText(new SimpleDateFormat("dd/MM/yyyy").format(pedido.getDataPedido()));
                        int i;
                        for (i = 0; i < listaPessoa.length; i++) {
                            String aux[] = listaPessoa[i].split(";");
                            String aux2[] = aux[0].split("-");

                            System.out.println(aux[0]);
                            System.out.println(aux2[0]);

                            if (aux2[0].toString().equals(pedido.getPessoaCpf().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaPessoa.length) {
                            cbCpf.setSelectedIndex(i);
                        }

                        cbCpf.setEnabled(false);

                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        tfDataPedido.setText("");
                        tfDataPedido.setEditable(false);
                        cbCpf.setSelectedIndex(0);
                        cbCpf.setEnabled(false);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfIdpedido.setEnabled(false);
                tfDataPedido.requestFocus();
                tfDataPedido.setEditable(true);
                cbCpf.setEnabled(true);
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Short cb_BD;    //fazendo isso pq em no BD boolean é tiny_int que é = ao short
                if (acao.equals("adicionar")) {
                    pedido = new Pedido();
                }
                try {
                    pedido.setIdpedido(Integer.valueOf(tfIdpedido.getText()));
                    sdf.setLenient(false);
                    Date data = sdf.parse(tfDataPedido.getText());
                    pedido.setDataPedido(data);
                    pedido.setDataPedido(cf.converteDeStringParaDate(tfDataPedido.getText()));
                    pedido.setPessoaCpf(daoPessoa.obter((Integer.valueOf(cbCpf.getSelectedItem().toString().split("-")[0].trim()))));
                    if (acao.equals("adicionar")) {
                        daoPedido.inserir(pedido);
                    } else {
                        daoPedido.atualizar(pedido);
                    }
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    tfIdpedido.setEnabled(true);
                    tfIdpedido.setEditable(true);
                    tfIdpedido.setText("");
                    tfDataPedido.setEnabled(true);
                    tfDataPedido.setEditable(false);
                    tfDataPedido.requestFocus();
                    tfDataPedido.setText("");
                    cbCpf.setEnabled(false);
                    cbCpf.requestFocus();
                    cbCpf.setSelectedIndex(0);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!" + ex.getMessage(), "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                    
                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfIdpedido.setEditable(false);
                tfDataPedido.setEditable(true);
                cbCpf.setEnabled(true);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                tfIdpedido.setEnabled(true);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                tfIdpedido.setEnabled(true);
                tfIdpedido.setEditable(true);
                tfIdpedido.requestFocus();
                tfIdpedido.setText("");
                tfDataPedido.setText("");
                tfDataPedido.setEditable(false);
                cbCpf.setEnabled(false);
                cbCpf.setSelectedIndex(0);
                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoPedido.remover(pedido);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Pedido> listaPedido = daoPedido.list();
                String[] colunas = new String[]{"Idpedido", "DataPedido", "PessoaCpf"};
                String[][] dados = new String[listaPedido.size()][colunas.length];
                String aux[];
                for (int i = 0; i < listaPedido.size(); i++) {
                    aux = listaPedido.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                tfDataPedido.setEditable(false);
                cbCpf.setEnabled(false);
//cor do background e da letra de cada coluna
                //coluna1.setBackground(new Color(220, 220, 220));
                coluna1.setBackground(Color.WHITE);
                coluna1.setForeground(Color.BLUE);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
   
                coluna2.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(2).setCellRenderer(coluna1);
            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfIdpedido.setText("");
                tfIdpedido.requestFocus();
                tfIdpedido.setEnabled(true);
                tfIdpedido.setEditable(true);
                tfDataPedido.setText("");
                tfDataPedido.setEditable(false);
                cbCpf.setEnabled(false);
                cbCpf.setSelectedIndex(0);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai da classe
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI

    public class DLabel extends JLabel {

        public DLabel(String name) {
            this.setForeground(Color.BLACK);
            this.setText(name);
            this.setOpaque(true);
            this.setHorizontalAlignment(CENTER);
            this.setBorder(BorderFactory.createBevelBorder(TOP, Color.GRAY, Color.GRAY));
        }

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.GRAY;
            Color color2 = Color.GRAY;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }

    }//fim da classe

    public class TestPanel extends JPanel {

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.GRAY;
            Color color2 = Color.WHITE;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }
    }

} //fim da classe
