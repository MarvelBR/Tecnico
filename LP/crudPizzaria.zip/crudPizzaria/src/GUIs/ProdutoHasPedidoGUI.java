package GUIs;

import DAOs.DAOPedido;
import DAOs.DAOProduto;
import DAOs.DAOProdutoHasPedido;
import Entidades.Pedido;
import Entidades.Produto;
import Entidades.ProdutoHasPedido;
import Entidades.ProdutoHasPedidoPK;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.ImagemAjustada;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import pdf.converterPDFBLOB;
import pdf.geradorPDF;

/**
 *
 * @author mrmar 30/09/2023 - 18:23:08
 */
public class ProdutoHasPedidoGUI extends JDialog {

    Container cp;
    JPanel pnNorte = new TestPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    JButton btPDF = new JButton("Gerar PDF");
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private final JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private final JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    DefaultTableCellRenderer coluna2 = new DefaultTableCellRenderer();
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    JLabel lbProdutoIdproduto = new JLabel("Produto (ID)");
    JLabel lbPedidoIdpedido = new JLabel("Pedido (ID)");

    DefaultComboBoxModel comboboxModelProdutoIdProduto = new DefaultComboBoxModel();
    JComboBox cbProdutoIdProduto = new JComboBox(comboboxModelProdutoIdProduto);
    DefaultComboBoxModel comboboxModelPedidoIdPedido = new DefaultComboBoxModel();
    JComboBox cbPedidoIdPedido = new JComboBox(comboboxModelPedidoIdPedido);

    JLabel lbQuantidade = new JLabel("Quantidade");
    JTextField tfQuantidade = new JTextField(30);
    //MUDEI

    ProdutoHasPedidoPK produtoHasPedidoPK = new ProdutoHasPedidoPK();
    ProdutoHasPedido pedidoFinal = new ProdutoHasPedido();

    String[] colunas = new String[]{"produtoIdproduto", "pedidoIdpedido"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    public ProdutoHasPedidoGUI() {
        
        Font Poppins = null;
        Font Poppins_lista = null;

        try {
            Poppins = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Poppins-Regular.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }

        Poppins = Poppins.deriveFont(Font.PLAIN, 16);
        Poppins_lista = Poppins.deriveFont(Font.PLAIN, 18);
        
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - ProdutoHasPedidoPK");
        
        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(25);
        tabela.setFont(Poppins_lista);

        //cabeçalho
        tabela.getTableHeader().setFont(Poppins_lista);
        tabela.getTableHeader().setDefaultRenderer(coluna2);

        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(Color.LIGHT_GRAY);
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));

        //MUDEI
        
        btListar.setFont(Poppins);
        btBuscar.setFont(Poppins);
        btAdicionar.setFont(Poppins);
        btSalvar.setFont(Poppins);
        btCancelar.setFont(Poppins);
        btExcluir.setFont(Poppins);
        btAlterar.setFont(Poppins);
        lbProdutoIdproduto.setFont(Poppins);
        cbProdutoIdProduto.setFont(Poppins);
        lbPedidoIdpedido.setFont(Poppins);
        cbPedidoIdPedido.setFont(Poppins);
        btPDF.setFont(Poppins);
        
        pnNorte.add(lbProdutoIdproduto);
        pnNorte.add(cbProdutoIdProduto);
        pnNorte.add(lbPedidoIdpedido);
        pnNorte.add(cbPedidoIdPedido);
        pnNorte.add(btPDF);

        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);
        
        lbQuantidade.setFont(Poppins);
        lbQuantidade.setHorizontalAlignment(SwingConstants.CENTER);
        tfQuantidade.setFont(Poppins);

        pnCentro.add(lbQuantidade);
        pnCentro.add(tfQuantidade);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        btPDF.setVisible(false);
        tfQuantidade.setEnabled(false);
        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));

        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));

        DAOProdutoHasPedido daoProdutoHasPedido = new DAOProdutoHasPedido();
        DAOPedido daoPedido = new DAOPedido();
        DAOProduto daoProduto = new DAOProduto();

        String[] listaPedido = daoPedido.listInOrderNomeStringsArray();
        String[] listaProduto = daoPedido.listInOrderNomeStringsArray();

        String[] listaProdutoHasPedido = daoProdutoHasPedido.listInOrderNomeStringsArray();
        Arrays.sort(listaProdutoHasPedido);

        for (String item : listaPedido) {
            String[] aux = item.split("-");
            int numeroPedido = Integer.valueOf(aux[0].split(";")[0]);

            Pedido cpfPessoa = daoPedido.obter(numeroPedido);
            String nomePessoa = cpfPessoa.getPessoaCpf().toString().split(";")[1];

            comboboxModelPedidoIdPedido.addElement(numeroPedido + " - Nome: " + nomePessoa);
        }
        for (String item : listaProduto) {
            String[] aux = item.split("-");
            int numeroProduto = Integer.valueOf(aux[0].split(";")[0]);

            Produto produto = daoProduto.obter(numeroProduto);
            String nomePessoa = produto.getNome().split(";")[0];

            comboboxModelProdutoIdProduto.addElement(numeroProduto + "- Nome: " + nomePessoa);
        }

        cbPedidoIdPedido.setSelectedIndex(0);
// listener Buscar
        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    ProdutoHasPedidoPK chavesPrimarias = new ProdutoHasPedidoPK();

                    chavesPrimarias.setPedidoIdpedido(Integer.valueOf(cbPedidoIdPedido.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                    chavesPrimarias.setProdutoIdproduto(Integer.valueOf(cbProdutoIdProduto.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                    ProdutoHasPedido pedidoFinal = daoProdutoHasPedido.obter(chavesPrimarias);
                    if (pedidoFinal != null) {//achou o produtoHasPedidoPK na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        btPDF.setVisible(false);
                        tfQuantidade.setText(String.valueOf(pedidoFinal.getQuantidade()));
                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        btPDF.setVisible(false);

                        tfQuantidade.setText("");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro no tipo de dados", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                    System.out.println(ex);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfQuantidade.setEnabled(true);

                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btPDF.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (acao.equals("adicionar")) {
                    ProdutoHasPedido pedidoFinal = new ProdutoHasPedido();
                }
                try {
                    produtoHasPedidoPK.setPedidoIdpedido(Integer.valueOf(cbPedidoIdPedido.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                    produtoHasPedidoPK.setProdutoIdproduto(Integer.valueOf(cbProdutoIdProduto.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));

                    pedidoFinal.setProdutoHasPedidoPK(produtoHasPedidoPK);
                    pedidoFinal.setQuantidade(Integer.valueOf(tfQuantidade.getText()));

                    if (acao.equals("adicionar")) {
                        daoProdutoHasPedido.inserir(pedidoFinal);
                    } else {
                        daoProdutoHasPedido.atualizar(pedidoFinal);
                    }
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    btPDF.setVisible(false);
                    tfQuantidade.setEnabled(false);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro nas informações! >:(", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                btExcluir.setVisible(false);
                tfQuantidade.setEnabled(true);
                btPDF.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            ImagemAjustada imagemAjustada = new ImagemAjustada();

            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                btAlterar.setVisible(false);
                btPDF.setVisible(false);
                ProdutoHasPedidoPK chavesPrimarias = new ProdutoHasPedidoPK();

                chavesPrimarias.setPedidoIdpedido(Integer.valueOf(cbPedidoIdPedido.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                chavesPrimarias.setProdutoIdproduto(Integer.valueOf(cbProdutoIdProduto.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                ProdutoHasPedido pedidoFinal = daoProdutoHasPedido.obter(chavesPrimarias);
                
                if (response == JOptionPane.YES_OPTION) {
                    daoProdutoHasPedido.remover(pedidoFinal);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<ProdutoHasPedido> listaPedidoFinal = daoProdutoHasPedido.list();
                ArrayList<Double> precoUnitario = new ArrayList<>();
                ArrayList<Integer> quantidade = new ArrayList<>();

                String[] colunas = new String[]{"Produto (ID)", "Pedido (ID)", "Quantidade"};
                String[][] dados = new String[listaPedidoFinal.size()][colunas.length];
                String aux[];
                for (int i = 0; i < listaPedidoFinal.size(); i++) {
                    aux = listaPedidoFinal.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        if (j == 0) {
                            Produto produtoLista = daoProduto.obter(Integer.valueOf(aux[j]));
                            precoUnitario.add(produtoLista.getPrecoUnitario());
                            dados[i][j] = "(" + aux[j] + ") " + produtoLista.getNome() + ": R$" + produtoLista.getPrecoUnitario();
                        } else if (j == 2) {
                            quantidade.add(Integer.valueOf(aux[j]));
                            dados[i][j] = aux[j];
                        } else {
                            dados[i][j] = aux[j];
                        }
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);
                
                coluna1.setBackground(Color.WHITE);
                coluna1.setForeground(Color.BLUE);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
   
                coluna2.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(2).setCellRenderer(coluna1);
                
                double soma = 0;
                for (int i = 0; i < quantidade.size(); i++) {
                    soma += quantidade.get(i) * precoUnitario.get(i);
                }

                model.insertRow(listaPedidoFinal.size(), new Object[]{" ", "Total", String.valueOf(soma)});
                model.insertRow(listaPedidoFinal.size(), new Object[]{""});

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                btPDF.setVisible(true);

            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfQuantidade.setEnabled(false);
                tfQuantidade.setText("");

                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btPDF.setVisible(false);
            }
        });

        btPDF.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                geradorPDF geradorPDF = new geradorPDF();
                int response = JOptionPane.showConfirmDialog(cp, "Gostaria de salvar no banco?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    converterPDFBLOB converterPDFBLOB = new converterPDFBLOB();
                }
            }
        });
// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI
    
    public class TestPanel extends JPanel {

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.WHITE;
            Color color2 = Color.GRAY;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }
    }
    
} //fim da classe
