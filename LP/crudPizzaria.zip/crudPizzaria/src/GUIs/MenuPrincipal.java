package GUIs;

import Entidades.ProdutoHasPedido;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;
import pdf.converterBLOB;
import pdf.converterPDFBLOB;
import pdf.geradorPDF;

/**
 *
 * @author mrmar
 */
public class MenuPrincipal extends JFrame {

    private final Container cp;
    private final JButton btCargo = new JButton("Cargo");
    private final JButton btProdutoHasPedidoPK = new JButton("Pedidos");
    private final JButton btPessoa = new JButton("Pessoa");
    private final JButton btPedido = new JButton("Pedido");
    private final JButton btTamanho = new JButton("Tamanho");
    private final JButton btCategoria = new JButton("Categoria");
    private final JButton btProduto = new JButton("Produto");
    JLabel lbVazio = new JLabel("");
    JPanel top = new TestPanel();
//    JPanel top = new JPanel();

    JLabel lbTitulo = new JLabel("Menu: \n", SwingConstants.CENTER);

    public MenuPrincipal() {
        Font Poppins = null;
        Font Poppins_lista = null;

        try {
            Poppins = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Poppins-Regular.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }

        Poppins = Poppins.deriveFont(Font.PLAIN, 20);
        
        cp = getContentPane();

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Menu");
        top.setLayout(new BoxLayout(top, BoxLayout.X_AXIS));
        top.add(Box.createHorizontalGlue());
        lbTitulo.setHorizontalAlignment(JLabel.CENTER);
        cp.add(top);
        top.add(lbTitulo);
        top.add(btCargo);

        btCargo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CargoGUI cargoGUI = new CargoGUI();
            }
        });
        top.add(btProdutoHasPedidoPK);
        btProdutoHasPedidoPK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProdutoHasPedidoGUI produtoHasPedidoGUI = new ProdutoHasPedidoGUI();
            }
        });

        top.add(btPessoa);
        btPessoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PessoaGUI pessoaGUI = new PessoaGUI();
            }
        });

        top.add(btPedido);
        btPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PedidoGUI pedidoGUI = new PedidoGUI();
            }
        });

        top.add(btTamanho);
        btTamanho.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TamanhoGUI tamanhoGUI = new TamanhoGUI();
            }
        });

        top.add(btCategoria);
        btCategoria.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CategoriaGUI categoriaGUI = new CategoriaGUI();
            }
        });

        top.add(btProduto);
        btProduto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                ProdutoGUI produtoGUI = new ProdutoGUI();
                try {
                    converterBLOB converterBLOB1 = new converterBLOB();
                } catch (SQLException ex) {
                    Logger.getLogger(MenuPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });

        top.add(Box.createHorizontalGlue());
        lbTitulo.setFont(Poppins);

        setSize(700, 200);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public class TestPanel extends JPanel {

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.WHITE;
            Color color2 = Color.GRAY;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }
    }

}
