package GUIs;

import DAOs.DAOCategoria;
import Entidades.Produto;
import DAOs.DAOProduto;
import DAOs.DAOTamanho;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Arrays;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

/**
 *
 * @author Erick 04/10/2023 - 14:26:07
 */
public class ProdutoGUI extends JDialog {

    Container cp;
    JPanel pnNorte = new TestPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    DefaultTableCellRenderer coluna2 = new DefaultTableCellRenderer();
    
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    JLabel lbIdproduto = new JLabel("Idproduto");
    JTextField tfIdproduto = new JTextField(30);
    JLabel lbNome = new JLabel("Nome");
    JTextField tfNome = new JTextField(30);
    JLabel lbPrecoUnitario = new JLabel("PrecoUnitario");
    JTextField tfPrecoUnitario = new JTextField(30);

    JLabel lbCategoriaIdcategoria = new JLabel("CategoriaIdcategoria");
    DefaultComboBoxModel comboBoxModelCategoria = new DefaultComboBoxModel();
    JComboBox cbCategoria = new JComboBox(comboBoxModelCategoria);

    JLabel lbTamanhoIdtamanho = new JLabel("TamanhoIdtamanho");
    DefaultComboBoxModel comboBoxModelTamanho = new DefaultComboBoxModel();
    JComboBox cbTamanho = new JComboBox(comboBoxModelTamanho);

    JLabel lbVazio = new JLabel("");
    DAOProduto daoProduto = new DAOProduto();
    Produto produto = new Produto();
    String[] colunas = new String[]{"idproduto", "nome", "precoUnitario", "categoriaIdcategoria", "tamanhoIdtamanho"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    public ProdutoGUI() {
        
        Font Poppins = null;
        Font Poppins_lista = null;

        try {
            Poppins = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Poppins-Regular.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }

        Poppins = Poppins.deriveFont(Font.PLAIN, 20);
        Poppins_lista = Poppins.deriveFont(Font.PLAIN, 18);
        
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Produto");

        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(25);
        tabela.setFont(Poppins_lista);

        //cabeçalho
        tabela.getTableHeader().setFont(Poppins_lista);
        tabela.getTableHeader().setDefaultRenderer(coluna2);
        //cor da linha da tabela
        tabela.setGridColor(new Color(0, 0, 0));
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(new Color(135, 206, 250));
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        btListar.setFont(Poppins);
        btBuscar.setFont(Poppins);
        btAdicionar.setFont(Poppins);
        btSalvar.setFont(Poppins);
        btCancelar.setFont(Poppins);
        btExcluir.setFont(Poppins);
        btAlterar.setFont(Poppins);
        lbIdproduto.setFont(Poppins);
        tfIdproduto.setFont(Poppins);
        pnNorte.add(lbIdproduto);
        pnNorte.add(tfIdproduto);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        tfNome.setEditable(false);
        tfPrecoUnitario.setEditable(false);
        cbCategoria.setEnabled(false);
        cbTamanho.setEnabled(false);
        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));
        lbNome.setHorizontalAlignment(SwingConstants.CENTER);
        lbPrecoUnitario.setHorizontalAlignment(SwingConstants.CENTER);
        lbCategoriaIdcategoria.setHorizontalAlignment(SwingConstants.CENTER);
        lbTamanhoIdtamanho.setHorizontalAlignment(SwingConstants.CENTER);

        lbNome.setFont(Poppins);
        tfNome.setFont(Poppins);
        lbPrecoUnitario.setFont(Poppins);
        tfPrecoUnitario.setFont(Poppins);
        lbCategoriaIdcategoria.setFont(Poppins);
        cbCategoria.setFont(Poppins);
        lbTamanhoIdtamanho.setFont(Poppins);
        cbTamanho.setFont(Poppins);
        pnCentro.add(lbNome);
        pnCentro.add(tfNome);
        pnCentro.add(lbPrecoUnitario);
        pnCentro.add(tfPrecoUnitario);
        pnCentro.add(lbCategoriaIdcategoria);
        pnCentro.add(cbCategoria);
        pnCentro.add(lbTamanhoIdtamanho);
        pnCentro.add(cbTamanho);
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));

        DAOCategoria daoCategoria = new DAOCategoria();
        String[] listaCategoria = daoCategoria.listInOrderNomeStringsArray();
        Arrays.sort(listaCategoria);
        for (String s : listaCategoria) {
            String[] aux = s.split("-");
            comboBoxModelCategoria.addElement(aux[0]);
        }

        DAOTamanho daoTamanho = new DAOTamanho();
        String[] listaTamanho = daoTamanho.listInOrderNomeStringsArray();
        Arrays.sort(listaTamanho);
        for (String s : listaTamanho) {
            String[] aux = s.split("-");
            comboBoxModelTamanho.addElement(aux[0]);
        }

        cbCategoria.setSelectedIndex(0);
        cbTamanho.setSelectedIndex(0);

// listener Buscar
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    produto = daoProduto.obter(Integer.valueOf(tfIdproduto.getText()));
                    if (produto != null) {//achou o produto na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        tfNome.setText(String.valueOf(produto.getNome()));
                        tfNome.setEditable(false);
                        tfPrecoUnitario.setText(String.valueOf(produto.getPrecoUnitario()));
                        tfPrecoUnitario.setEditable(false);
                        int i;

                        for (i = 0; i < listaCategoria.length; i++) {
                            String aux[] = listaCategoria[i].split(";");
                            String aux2[] = aux[0].split("-");

                            if (aux2[0].toString().equals(produto.getCategoriaIdcategoria().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaCategoria.length) {
                            cbCategoria.setSelectedIndex(i);
                        }

                        cbCategoria.setEnabled(false);

                        for (i = 0; i < listaTamanho.length; i++) {
                            String aux[] = listaTamanho[i].split(";");
                            String aux2[] = aux[0].split("-");

                            if (aux2[0].toString().equals(produto.getTamanhoIdtamanho().toString().split(";")[0])) {
                                break;
                            }
                        }
                        if (i < listaTamanho.length) {
                            cbTamanho.setSelectedIndex(i);
                        }

                        cbTamanho.setEnabled(false);

                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        tfNome.setText("");
                        tfNome.setEditable(false);
                        tfPrecoUnitario.setText("");
                        tfPrecoUnitario.setEditable(false);
                        cbTamanho.setSelectedIndex(0);
                        cbTamanho.setEnabled(false);
                        cbCategoria.setSelectedIndex(0);
                        cbCategoria.setEnabled(false);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfIdproduto.setEnabled(false);
                tfNome.requestFocus();
                tfNome.setEditable(true);
                tfPrecoUnitario.setEditable(true);
                cbCategoria.setEnabled(true);
                cbCategoria.setEnabled(true);
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Short cb_BD;    //fazendo isso pq em no BD boolean é tiny_int que é = ao short
                if (acao.equals("adicionar")) {
                    produto = new Produto();
                }
                try {
                    produto.setIdproduto(Integer.valueOf(tfIdproduto.getText()));
                    produto.setNome(tfNome.getText());
                    produto.setPrecoUnitario(Double.valueOf(tfPrecoUnitario.getText()));
                    produto.setCategoriaIdcategoria(daoCategoria.obter((Integer.valueOf(cbCategoria.getSelectedItem().toString().split("-")[0].trim()))));
                    produto.setTamanhoIdtamanho(daoTamanho.obter((Integer.valueOf(cbTamanho.getSelectedItem().toString().split("-")[0].trim()))));
                    if (acao.equals("adicionar")) {
                        daoProduto.inserir(produto);
                    } else {
                        daoProduto.atualizar(produto);
                    }
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    tfIdproduto.setEnabled(true);
                    tfIdproduto.setEditable(true);
                    tfIdproduto.setText("");
                    tfNome.setEnabled(true);
                    tfNome.setEditable(false);
                    tfNome.requestFocus();
                    tfNome.setText("");
                    tfPrecoUnitario.setEnabled(true);
                    tfPrecoUnitario.setEditable(false);
                    tfPrecoUnitario.requestFocus();
                    tfPrecoUnitario.setText("");
                    cbCategoria.setEnabled(false);
                    cbCategoria.requestFocus();
                    cbCategoria.setSelectedIndex(0);
                    cbTamanho.setEnabled(false);
                    cbTamanho.requestFocus();
                    cbTamanho.setSelectedIndex(0);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);

                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfIdproduto.setEditable(false);
                tfNome.setEditable(true);
                tfPrecoUnitario.setEditable(true);
                cbCategoria.setEnabled(false);
                cbTamanho.setEnabled(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                tfIdproduto.setEnabled(true);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                tfIdproduto.setEnabled(true);
                tfIdproduto.setEditable(true);
                tfIdproduto.requestFocus();
                tfIdproduto.setText("");
                tfNome.setText("");
                tfNome.setEditable(false);
                tfPrecoUnitario.setText("");
                tfPrecoUnitario.setEditable(false);
                cbCategoria.setEnabled(false);
                cbTamanho.setEnabled(false);
                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoProduto.remover(produto);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Produto> listaProduto = daoProduto.list();
                String[] colunas = new String[]{"Idproduto", "Nome", "PrecoUnitario", "CategoriaIdcategoria", "TamanhoIdtamanho"};
                String[][] dados = new String[listaProduto.size()][colunas.length];
                String aux[];
                for (int i = 0; i < listaProduto.size(); i++) {
                    aux = listaProduto.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                tfNome.setEditable(false);
                tfPrecoUnitario.setEditable(false);
                cbCategoria.setEnabled(false);
                cbTamanho.setEnabled(false);
//cor do background e da letra de cada coluna


                coluna2.setHorizontalAlignment(SwingConstants.CENTER);
                coluna1.setBackground(Color.WHITE);
                coluna1.setForeground(Color.BLUE);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(2).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(3).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(4).setCellRenderer(coluna1);
            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfIdproduto.setText("");
                tfIdproduto.requestFocus();
                tfIdproduto.setEnabled(true);
                tfIdproduto.setEditable(true);
                tfNome.setText("");
                tfNome.setEditable(false);
                tfPrecoUnitario.setText("");
                tfPrecoUnitario.setEditable(false);
                cbCategoria.setEnabled(false);
                cbTamanho.setEnabled(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai da classe
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI
    
    
    public class TestPanel extends JPanel {

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            Color color1 = Color.GRAY;
            Color color2 = Color.WHITE;
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
            getUI().paint(g, this);
        }
    }
} //fim da classe
