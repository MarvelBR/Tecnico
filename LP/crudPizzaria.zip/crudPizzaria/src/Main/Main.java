package Main;

import GUIs.MenuPrincipal;
import javax.swing.UIManager;

/**
 *
 * @author mrmar
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            MenuPrincipal guiDoGerador = new MenuPrincipal();
        } catch (Exception Ex) {
            MenuPrincipal guiDoGerador = new MenuPrincipal();
        }
    }

}
