/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author mrmar
 */
@Entity
@Table(name = "tamanho")
@NamedQueries({
    @NamedQuery(name = "Tamanho.findAll", query = "SELECT t FROM Tamanho t"),
    @NamedQuery(name = "Tamanho.findByIdtamanho", query = "SELECT t FROM Tamanho t WHERE t.idtamanho = :idtamanho"),
    @NamedQuery(name = "Tamanho.findByNome", query = "SELECT t FROM Tamanho t WHERE t.nome = :nome")})
public class Tamanho implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idtamanho")
    private Integer idtamanho;
    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tamanhoIdtamanho")
    private List<Produto> produtoList;

    public Tamanho() {
    }

    public Tamanho(Integer idtamanho) {
        this.idtamanho = idtamanho;
    }

    public Tamanho(Integer idtamanho, String nome) {
        this.idtamanho = idtamanho;
        this.nome = nome;
    }

    public Integer getIdtamanho() {
        return idtamanho;
    }

    public void setIdtamanho(Integer idtamanho) {
        this.idtamanho = idtamanho;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Produto> getProdutoList() {
        return produtoList;
    }

    public void setProdutoList(List<Produto> produtoList) {
        this.produtoList = produtoList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtamanho != null ? idtamanho.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tamanho)) {
            return false;
        }
        Tamanho other = (Tamanho) object;
        if ((this.idtamanho == null && other.idtamanho != null) || (this.idtamanho != null && !this.idtamanho.equals(other.idtamanho))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.Tamanho[ idtamanho=" + idtamanho + " ]";
    }

}
