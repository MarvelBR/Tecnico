/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author mrmar
 */
@Entity
@Table(name = "produto_has_pedido")
@NamedQueries({
    @NamedQuery(name = "ProdutoHasPedido.findAll", query = "SELECT p FROM ProdutoHasPedido p"),
    @NamedQuery(name = "ProdutoHasPedido.findByProdutoIdproduto", query = "SELECT p FROM ProdutoHasPedido p WHERE p.produtoHasPedidoPK.produtoIdproduto = :produtoIdproduto"),
    @NamedQuery(name = "ProdutoHasPedido.findByPedidoIdpedido", query = "SELECT p FROM ProdutoHasPedido p WHERE p.produtoHasPedidoPK.pedidoIdpedido = :pedidoIdpedido"),
    @NamedQuery(name = "ProdutoHasPedido.findByQuantidade", query = "SELECT p FROM ProdutoHasPedido p WHERE p.quantidade = :quantidade")})
public class ProdutoHasPedido implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ProdutoHasPedidoPK produtoHasPedidoPK;
    @Basic(optional = false)
    @Column(name = "quantidade")
    private int quantidade;
    @JoinColumn(name = "pedido_idpedido", referencedColumnName = "idpedido", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Pedido pedido;
    @JoinColumn(name = "produto_idproduto", referencedColumnName = "idproduto", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Produto produto;

    public ProdutoHasPedido() {
    }

    public ProdutoHasPedido(ProdutoHasPedidoPK produtoHasPedidoPK) {
        this.produtoHasPedidoPK = produtoHasPedidoPK;
    }

    public ProdutoHasPedido(ProdutoHasPedidoPK produtoHasPedidoPK, int quantidade) {
        this.produtoHasPedidoPK = produtoHasPedidoPK;
        this.quantidade = quantidade;
    }

    public ProdutoHasPedido(int produtoIdproduto, int pedidoIdpedido) {
        this.produtoHasPedidoPK = new ProdutoHasPedidoPK(produtoIdproduto, pedidoIdpedido);
    }

    public ProdutoHasPedidoPK getProdutoHasPedidoPK() {
        return produtoHasPedidoPK;
    }

    public void setProdutoHasPedidoPK(ProdutoHasPedidoPK produtoHasPedidoPK) {
        this.produtoHasPedidoPK = produtoHasPedidoPK;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (produtoHasPedidoPK != null ? produtoHasPedidoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProdutoHasPedido)) {
            return false;
        }
        ProdutoHasPedido other = (ProdutoHasPedido) object;
        if ((this.produtoHasPedidoPK == null && other.produtoHasPedidoPK != null) || (this.produtoHasPedidoPK != null && !this.produtoHasPedidoPK.equals(other.produtoHasPedidoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return produtoHasPedidoPK + ";" + quantidade;
    }

}
