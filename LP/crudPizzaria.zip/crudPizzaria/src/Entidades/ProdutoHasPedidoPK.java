/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author mrmar
 */
@Embeddable
public class ProdutoHasPedidoPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "produto_idproduto")
    private int produtoIdproduto;
    @Basic(optional = false)
    @Column(name = "pedido_idpedido")
    private int pedidoIdpedido;

    public ProdutoHasPedidoPK() {
    }

    public ProdutoHasPedidoPK(int produtoIdproduto, int pedidoIdpedido) {
        this.produtoIdproduto = produtoIdproduto;
        this.pedidoIdpedido = pedidoIdpedido;
    }

    public int getProdutoIdproduto() {
        return produtoIdproduto;
    }

    public void setProdutoIdproduto(int produtoIdproduto) {
        this.produtoIdproduto = produtoIdproduto;
    }

    public int getPedidoIdpedido() {
        return pedidoIdpedido;
    }

    public void setPedidoIdpedido(int pedidoIdpedido) {
        this.pedidoIdpedido = pedidoIdpedido;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) produtoIdproduto;
        hash += (int) pedidoIdpedido;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProdutoHasPedidoPK)) {
            return false;
        }
        ProdutoHasPedidoPK other = (ProdutoHasPedidoPK) object;
        if (this.produtoIdproduto != other.produtoIdproduto) {
            return false;
        }
        if (this.pedidoIdpedido != other.pedidoIdpedido) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return  produtoIdproduto + ";" + pedidoIdpedido;
    }

}
