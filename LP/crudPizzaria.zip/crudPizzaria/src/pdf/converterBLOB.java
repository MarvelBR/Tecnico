/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdf;

import java.sql.SQLException;
import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author mrmar
 */
public class converterBLOB {

public converterBLOB() throws SQLException{
        String jdbcUrl = "jdbc:mysql://localhost:3306/pizzaria";
        String username = "root";
        String password = "root";

        try (Connection conexaoBD = DriverManager.getConnection(jdbcUrl, username, password)) {
            String queryUsada = "SELECT pedidoPDF FROM pdfs WHERE nome = \'Pedidos\'";

            try (PreparedStatement preparedStatement = conexaoBD.prepareStatement(queryUsada)) {
                ResultSet resposta = preparedStatement.executeQuery();

                if (resposta.next()) {
                    Blob blob = resposta.getBlob("pedidoPDF");
                    byte[] pdfBytes = blob.getBytes(1, (int) blob.length());

                    try (FileOutputStream saida = new FileOutputStream("C:\\Users\\mrmar\\OneDrive\\Documentos\\NetBeansProjects\\crudPizzaria\\src\\pdf\\BLOB.pdf")) {
                        saida.write(pdfBytes);
                        System.out.println("BLOB convertido!");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
}
