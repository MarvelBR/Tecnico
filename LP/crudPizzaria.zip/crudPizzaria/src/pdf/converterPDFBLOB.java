/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdf;

import java.sql.Connection;
import java.io.File;
import java.io.FileInputStream;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author mrmar
 */
public class converterPDFBLOB {

    public converterPDFBLOB() {
        String url = "jdbc:mysql://localhost:3306/pizzaria";
        String usuario = "root";
        String senha = "root";

        try (Connection connection = DriverManager.getConnection(url, usuario, senha)) {
            String caminhoArquivoPDF = "C:\\Users\\mrmar\\OneDrive\\Documentos\\NetBeansProjects\\crudPizzaria\\src\\pdf\\Pedidos.pdf";

            File arquivoPDF = new File(caminhoArquivoPDF);
            byte[] pdfBytes = new byte[(int) arquivoPDF.length()];

            try (FileInputStream fileInputStream = new FileInputStream(arquivoPDF)) {
                fileInputStream.read(pdfBytes);
            }

            String sql = "INSERT INTO pdfs (nome,pedidoPDF) VALUES (\'Pedidos\', ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setBytes(1, pdfBytes);
                preparedStatement.executeUpdate();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
