/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdf;

import DAOs.DAOProduto;
import DAOs.DAOProdutoHasPedido;
import Entidades.Produto;
import Entidades.ProdutoHasPedido;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.sql.Connection;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author mrmar
 */
public class geradorPDF {

    public geradorPDF() {
        Document document = new Document();

        //padrao
        DAOProdutoHasPedido daoProdutoHasPedido = new DAOProdutoHasPedido();
        List<ProdutoHasPedido> listaPedidoFinal = daoProdutoHasPedido.list();
        String[] colunas = new String[]{"Produto (ID)", "Pedido (ID)", "Quantidade"};
        String[][] dados = new String[listaPedidoFinal.size()][colunas.length];

        //soma
        ArrayList<Double> precoUnitario = new ArrayList<>();
        ArrayList<Integer> quantidade = new ArrayList<>();
        DAOProduto daoProduto = new DAOProduto();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-YYYY");
        Date date = new Date();

        String data = sdf.format(date);
        try {
            PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\mrmar\\OneDrive\\Documentos\\NetBeansProjects\\crudPizzaria\\src\\pdf\\Pedidos.pdf"));
            document.open();

            document.setPageSize(PageSize.A4);

            Font f = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD);
            Paragraph p1 = new Paragraph("Pedidos", f);

            p1.setAlignment(Element.ALIGN_CENTER);
            p1.setSpacingAfter(20);
            document.add(new Paragraph(p1));
            document.add(new Paragraph("  "));

            PdfPTable table = new PdfPTable(new float[]{0.3f, 0.3f, 0.3f}); // colunas com larguras diferentes em %

            table.setWidthPercentage(100.0f);
            table.setHorizontalAlignment(Element.ALIGN_CENTER);

            PdfPCell divisaoTotal = new PdfPCell();
            PdfPCell vazio = new PdfPCell();

            vazio.setColspan(3);
            vazio.setBackgroundColor(BaseColor.LIGHT_GRAY);
            Paragraph nada = new Paragraph(" ");
            vazio.addElement(nada);

            divisaoTotal.setColspan(2);
            Paragraph total = new Paragraph("Valor total");
            total.setAlignment(Element.ALIGN_CENTER);
            divisaoTotal.addElement(total);

            table.addCell(vazio);
            table.addCell("Produto");
            table.addCell("Pedido");
            table.addCell("Quantidade");

            String aux[];
            for (int i = 0; i < listaPedidoFinal.size(); i++) {
                aux = listaPedidoFinal.get(i).toString().split(";");
                for (int j = 0; j < colunas.length; j++) {
                    if (j == 0) {
                        Produto produtoLista = daoProduto.obter(Integer.valueOf(aux[j]));
                        precoUnitario.add(produtoLista.getPrecoUnitario());
                        dados[i][j] = "(" + aux[j] + ") " + produtoLista.getNome() + ": R$" + produtoLista.getPrecoUnitario();
                        table.addCell(dados[i][j]);
                    } else if (j == 2) {
                        quantidade.add(Integer.valueOf(aux[j]));
                        dados[i][j] = aux[j];
                        table.addCell(dados[i][j]);
                    } else {
                        dados[i][j] = aux[j];
                        table.addCell(dados[i][j]);
                    }
                }
            }
            table.addCell(vazio);
            table.addCell(divisaoTotal);

            double soma = 0;
            for (int i = 0; i < quantidade.size(); i++) {
                soma += quantidade.get(i) * precoUnitario.get(i);
            }

            table.addCell(String.valueOf(soma));
            document.add(table);

        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
        }
        document.close();

    }
}

//
