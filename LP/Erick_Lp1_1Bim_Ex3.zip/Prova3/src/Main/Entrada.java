/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {
    Scanner teclado = new Scanner(System.in);
    
    public double lerNumeroDouble(String mensagem){
       double x = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            x = teclado.nextDouble();
            while (x<0) {
                System.out.print("Erro, digite um valor positivo:");
                x = teclado.nextDouble();
            }
            break;
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
       return x;
    }
     public int lerNumeroInt(String mensagem){
       int z = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            z = teclado.nextInt();
            while (z<=0) {
                System.out.print("Erro, digite um valor maior que 0:");
                z = teclado.nextInt();
            }
            break;
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
       return z;
    }
     public int lerNumeroFalta(String mensagem, int aula){
       int w = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            w = teclado.nextInt();
            while (w<0) {
                System.out.print("Erro, digite um valor positivo:");
                w = teclado.nextInt();
            }
            while (w>aula) {
                System.out.print("Erro, número de falta maior que o de aulas totais, digite novamente:");
                w = teclado.nextInt();
            }
            break;
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
       return w;
    }
     public char lerChar(String mensagem){
         char s = 0;
         while(true){
         try {
             System.out.print(mensagem);
             s = teclado.next().charAt(0);
             while(s!='m' && s!='M' && s!='f' && s!='F'){
                 System.out.print("Erro, digite novamente o sexo:");
                 s = teclado.next().charAt(0);
             }
             break;
         } catch (Exception e) {
             System.out.println("Erro, digite novamente uma letra");
             teclado = new Scanner(System.in);
         }
         }
         return s;
        }
    }   
