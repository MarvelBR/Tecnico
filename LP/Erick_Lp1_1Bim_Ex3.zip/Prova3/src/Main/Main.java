/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        double a = entrada.lerNumeroDouble("Digite a nota da primeira prova:");
        double b = entrada.lerNumeroDouble("Digite a nota da segunda prova:");
        double c = entrada.lerNumeroDouble("Digite a nota da terceira prova:");
        double d = entrada.lerNumeroDouble("Digite a nota da quarta prova:");
        int aula = entrada.lerNumeroInt("Digite o número de aulas dadas no ano:");
        int falta = entrada.lerNumeroFalta("Digite o número de faltas no ano:", aula);
        char sexo = entrada.lerChar("Digite o seu sexo, M(m) para masculina e F(f) para feminino:");
        
        Processamento processamento = new Processamento();
        double media = processamento.somarNota(a, b, c, d);
        double maior_nota = processamento.somarMaiorNota(a, b, c, d, sexo);
        double presente = processamento.somarFalta(aula, falta);
        double aprovado = processamento.somarAprovado(media, presente, sexo);
        
        Saida saida = new Saida();
        saida.imprimirSexo("", sexo);
        saida.imprimirMedia("Uma media de", media);
        saida.imprimirPresente("E esteve presente em", presente);  
    } 
}
