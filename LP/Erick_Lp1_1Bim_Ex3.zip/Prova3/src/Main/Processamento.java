/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public double somarNota (double a, double b, double c, double d) {
        double soma = a+b+c+d;
        double media = soma/4;
        return media;    
    }
        public double somarMaiorNota(double a, double b, double c, double d, char sexo){
        
        if(a>b && a>c && a>d && sexo=='m' || a>b && a>c && a>d && sexo=='M'){
            System.out.println("A primeira nota foi a maior nota que o aluno tirou");
        }
        if(b>a && b>c && b>d && sexo=='m' || b>a && b>c && b>d && sexo=='M'){
            System.out.println("A segunda nota foi a maior nota que o aluno tirou");
        }
        if(c>a && c>b && c>d && sexo=='m' || c>a && c>b && c>d && sexo=='M'){
            System.out.println("A terceira nota foi a maior nota que o aluno tirou");
        }
        if(d>a && d>b && d>c && sexo=='m' || d>a && d>b && d>c && sexo=='M'){
            System.out.println("A quarta nota foi a maior nota que o aluno tirou");
        }
        if(a==b && a>c && a>d && sexo=='m' || a==b && a>c && a>d && sexo=='M'){
            System.out.println("A primeira e segunda nota foram as maiores que o aluno tirou");
        }
        if(a==c && a>b && a>d && sexo=='m' || a==c && a>b && a>d && sexo=='M'){
            System.out.println("A primeira e terceira nota foram as maiores que o aluno tirou");
        }
        if(a==d && a>b && a>c && sexo=='m' || a==d && a>b && a>c && sexo=='M'){
            System.out.println("A primeira e quarta nota foram as maiores que o aluno tirou");
        }
        if(b==c && b>a && b>d && sexo=='m' || b==c && b>a && b>d && sexo=='M'){
            System.out.println("A segunda e terceira nota foram as maiores que o aluno tirou");
        }
        if(b==d && b>a && b>c && sexo=='m' || b==d && b>a && b>c && sexo=='M'){
            System.out.println("A segunda e quarta nota foram as maiores que o aluno tirou");
        }
        if(d==c && d>a && d>b && sexo=='m' || d==c && d>a && d>b && sexo=='M'){
            System.out.println("A terceira e quarta nota foram as maiores que o aluno tirou");
        }
        if(a==b && a==c && a>d && sexo=='m' || a==b && a==c && a>d && sexo=='M'){
            System.out.println("A primeira, segunda e terceira nota foram as maiores que o aluno tirou");
        }
        if(a==b && a==d && a>c && sexo=='m' || a==d && a==d && a>c && sexo=='M'){
            System.out.println("A primeira, segunda e quarta nota foram as maiores que o aluno tirou");
        }
        if(a==d && a==c && a>b && sexo=='m' || a==d && a==c && a>b && sexo=='M'){
            System.out.println("A primeira, terceira e quarta nota foram as maiores que o aluno tirou");
        }
        if(b==d && b==c && b>a && sexo=='m' || b==d && b==c && b>a && sexo=='M'){
            System.out.println("A segunda, terceira e quarta nota foram as maiores que o aluno tirou");
        }
        if(a==b && a==c && a==d && b==c && b==d && c==d && sexo=='m' || a==b && a==c && a==d && b==c && b==d && c==d && sexo=='M'){
            System.out.println("Todas as 4 notas do aluno foram iguais");
        }
        
        
        if(a>b && a>c && a>d && sexo=='f' || a>b && a>c && a>d && sexo=='F'){
            System.out.println("A primeira nota foi a maior nota que a aluna tirou");
        }
        if(b>a && b>c && b>d && sexo=='f' || b>a && b>c && b>d && sexo=='F'){
            System.out.println("A segunda nota foi a maior nota que a aluna tirou");
        }
        if(c>a && c>b && c>d && sexo=='f' || c>a && c>b && c>d && sexo=='F'){
            System.out.println("A terceira nota foi a maior nota que a aluna tirou");
        }
        if(d>a && d>b && d>c && sexo=='f' || d>a && d>b && d>c && sexo=='F'){
            System.out.println("A quarta nota foi a maior nota que a aluna tirou");
        }
        if(a==b && a>c && a>d && sexo=='f' || a==b && a>c && a>d && sexo=='F'){
            System.out.println("A primeira e segunda nota foram as maiores que a aluna tirou");
        }
        if(a==c && a>b && a>d && sexo=='f' || a==c && a>b && a>d && sexo=='F'){
            System.out.println("A primeira e terceira nota foram as maiores que a aluna tirou");
        }
        if(a==d && a>b && a>c && sexo=='f' || a==d && a>b && a>c && sexo=='F'){
            System.out.println("A primeira e quarta nota foram as maiores que a aluna tirou");
        }
        if(b==c && b>a && b>d && sexo=='f' || b==c && b>a && b>d && sexo=='F'){
            System.out.println("A segunda e terceira nota foram as maiores que a aluna tirou");
        }
        if(b==d && b>a && b>c && sexo=='f' || b==d && b>a && b>c && sexo=='F'){
            System.out.println("A segunda e quarta nota foram as maiores que a aluna tirou");
        }
        if(d==c && d>a && d>b && sexo=='f' || d==c && d>a && d>b && sexo=='F'){
            System.out.println("A terceira e quarta nota foram as maiores que a aluna tirou");
        }
        if(a==b && a==c && a>d && sexo=='f' || a==b && a==c && a>d && sexo=='F'){
            System.out.println("A primeira, segunda e terceira nota foram as maiores que a aluna tirou");
        }
        if(a==b && a==d && a>c && sexo=='f' || a==b && a==d && a>c && sexo=='F'){
            System.out.println("A primeira, segunda e quarta nota foram as maiores que a aluna tirou");
        }
        if(a==d && a==c && a>b && sexo=='f' || a==d && a==c && a>b && sexo=='F'){
            System.out.println("A primeira, terceira e quarta nota foram as maiores que a aluna tirou");
        }
        if(b==d && b==c && b>a && sexo=='f' || b==d && b==c && b>a && sexo=='F'){
            System.out.println("A segunda, terceira e quarta nota foram as maiores que a aluna tirou");
        }
        if (a==b && a==c && a==d && b==c && b==d && c==d && sexo=='f' || a==b && a==c && a==d && b==c && b==d && c==d && sexo=='F'){
            System.out.println("Todas as 4 notas da aluna foram iguais");
        }
        return 0;
    }
    
    public double somarFalta (int aula, int falta){
        double nao_presente = (falta*100)/aula;
        double presente = 100-nao_presente;
        return presente;
    }
    
    public double somarAprovado (double media, double presente, char sexo) { 
        
        if (media>=6 && presente>=75 && sexo=='f' || media>=6 && presente>=75 && sexo=='F'){
            System.out.println("A aluna está aprovada");
        }
        if (media<6 && sexo=='f' || media<6 && sexo=='F'){
            System.out.println("A aluna está reprovada por nota");
        }
        if (presente<75 && sexo=='f' || presente<75 && sexo=='F'){
            System.out.println("A aluna está reprovada por falta");
        }
        if (media>=6 && presente>=75 && sexo=='m' || media>=6 && presente>=75 && sexo=='M'){
            System.out.println("O aluno está aprovado");
        }
        if (media<6 && sexo=='m' || media<6 && sexo=='M'){
            System.out.println("O aluno está reprovado por nota");
        }
        if (presente<75 && sexo=='m' || presente<75 && sexo=='M'){
            System.out.println("O aluno está reprovado por falta");
        }
        return 0;
    }
}

