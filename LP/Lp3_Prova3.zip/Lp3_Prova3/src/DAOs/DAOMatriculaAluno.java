package DAOs;

import Entidades.MatriculaAluno;
import java.util.ArrayList;
import java.util.List;

public class DAOMatriculaAluno extends DAOGenerico<MatriculaAluno> {

    private List<MatriculaAluno> lista = new ArrayList<>();

    public DAOMatriculaAluno() {
        super(MatriculaAluno.class);
    }

    public int autoMatriculaAluno() {
        Integer a = (Integer) em.createQuery("SELECT MAX (e.idMatriculaAluno) FROM MatriculaAluno e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<MatriculaAluno> listByNome(String nome) {
        return em.createQuery("SELECT e FROM MatriculaAluno e WHERE e.idMatriculaAluno) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<MatriculaAluno> listById(int id) {
        return em.createQuery("SELECT e FROM MatriculaAluno e WHERE e.idMatriculaAluno= :id").setParameter("id", id).getResultList();
    }

    public List<MatriculaAluno> listInOrderNome() {
        return em.createQuery("SELECT e FROM MatriculaAluno e ORDER BY e.alunoId").getResultList();
    }

    public List<MatriculaAluno> listInOrderId() {
        return em.createQuery("SELECT e FROM MatriculaAluno e ORDER BY e.idMatriculaAluno").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<MatriculaAluno> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdMatriculaAluno() + "-" + lf.get(i).getAlunoId());
        }
        return ls;
    }

    public String[] listInOrderNomeStringsArray() {
        List<MatriculaAluno> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getIdMatriculaAluno() + "-" + lf.get(i).getAlunoId());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOMatriculaAluno daoMatriculaAluno = new DAOMatriculaAluno();
        List<MatriculaAluno> listaMatriculaAluno = daoMatriculaAluno.list();
        for (MatriculaAluno matriculaAluno : listaMatriculaAluno) {
            System.out.println(matriculaAluno.getIdMatriculaAluno() + "=" + matriculaAluno.getAlunoId());
        }
    }
}
