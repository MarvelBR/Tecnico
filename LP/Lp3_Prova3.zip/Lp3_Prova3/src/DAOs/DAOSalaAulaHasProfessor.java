package DAOs;

import Entidades.SalaAulaHasProfessor;
import Entidades.SalaAulaHasProfessorPK;
import java.util.ArrayList;
import java.util.List;

public class DAOSalaAulaHasProfessor extends DAOGenerico<SalaAulaHasProfessor> {

    private List<SalaAulaHasProfessor> lista = new ArrayList<>();

    public DAOSalaAulaHasProfessor() {
        super(SalaAulaHasProfessor.class);
    }
    
    public SalaAulaHasProfessor obter(SalaAulaHasProfessorPK salaAulaHasProfessorPk){
        return em.find(SalaAulaHasProfessor.class, salaAulaHasProfessorPk);
    }

    public int autoSalaAulaHasProfessor() {
        Integer a = (Integer) em.createQuery("SELECT MAX (e.salaAulaIdSalaAulaPK) FROM SalaAulaHasProfessor e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<SalaAulaHasProfessor> listByNome(String nome) {
        return em.createQuery("SELECT e FROM SalaAulaHasProfessor e WHERE e.horarios LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<SalaAulaHasProfessor> listById(int id) {
        return em.createQuery("SELECT e FROM SalaAulaHasProfessor e WHERE e.salaAulaIdSalaAulaPK= :id").setParameter("id", id).getResultList();
    }

    public List<SalaAulaHasProfessor> listInOrderNome() {
        return em.createQuery("SELECT e FROM SalaAulaHasProfessor e ORDER BY e.horarios").getResultList();
    }

    public List<SalaAulaHasProfessor> listInOrderId() {
        return em.createQuery("SELECT e FROM SalaAulaHasProfessor e ORDER BY e.salaAulaIdSalaAulaPK").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<SalaAulaHasProfessor> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getSalaAulaHasProfessorPK() + "-" + lf.get(i).getHorarios());
        }
        return ls;
    }

    public String[] listInOrderNomeStringsArray() {
        List<SalaAulaHasProfessor> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getSalaAulaHasProfessorPK() + "-" + lf.get(i).getHorarios());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOSalaAulaHasProfessor daoSalaAulaHasProfessor = new DAOSalaAulaHasProfessor();
//        List<SalaAulaHasProfessor> listaSalaAulaHasProfessor = daoSalaAulaHasProfessor.list();
//        for (SalaAulaHasProfessor salaAulaHasProfessor : listaSalaAulaHasProfessor) {
//            System.out.println(salaAulaHasProfessor.getSalaAulaHasProfessorPK() + "=" + salaAulaHasProfessor.getHorarios());
//        }
    }
}
