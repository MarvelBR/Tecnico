package DAOs;

import Entidades.SalaAula;
import java.util.ArrayList;
import java.util.List;
public class DAOSalaAula extends DAOGenerico<SalaAula> {
private List<SalaAula> lista = new ArrayList<>();
public DAOSalaAula(){
super(SalaAula.class);
}
public int autoSalaAula() {
Integer a = (Integer) em.createQuery( "SELECT MAX (e.idSalaAula) FROM SalaAula e ").getSingleResult();
if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }
public List<SalaAula> listByNome (String nome) {
return em.createQuery("SELECT e FROM SalaAula e WHERE e.idSalaAula) LIKE :nome" ).setParameter("nome", "%" + nome + "%").getResultList();
}
public List<SalaAula> listById(int id) {
return em.createQuery("SELECT e FROM SalaAula e WHERE e.idSalaAula= :id").setParameter("id", id).getResultList();
}
public List<SalaAula> listInOrderNome() {
return em.createQuery("SELECT e FROM SalaAula e ORDER BY e.nomeSala").getResultList();
}
public List<SalaAula> listInOrderId() {
return em.createQuery("SELECT e FROM SalaAula e ORDER BY e.idSalaAula").getResultList();
}
public List<String> listInOrderNomeStrings(String qualOrdem) {
List<SalaAula> lf;
if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdSalaAula()+ "-" + lf.get(i).getNomeSala());
        }
        return ls;
    }
public String[] listInOrderNomeStringsArray(){
        List<SalaAula> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i] = (lf.get(i).getIdSalaAula() + "-" + lf.get(i).getNomeSala());
        }
        return ls;
    }public static void main(String[] args) {
DAOSalaAula daoSalaAula = new DAOSalaAula();
List<SalaAula> listaSalaAula= daoSalaAula.list();
for (SalaAula salaAula: listaSalaAula) {
System.out.println(salaAula.getIdSalaAula() + "=" + salaAula.getNomeSala());
}
    }
}
