package GUIs;

import DAOs.DAOProfessor;
import DAOs.DAOSalaAula;
import Entidades.SalaAulaHasProfessor;
import DAOs.DAOSalaAulaHasProfessor;
import Entidades.SalaAulaHasProfessorPK;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import tools.CaixaDeFerramentas;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.util.Arrays;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;

/**
 *
 * @author helo 02/04/2024 - 20:43:16
 */
public class SalaAulaHasProfessorGUI extends JDialog {

    Container cp;
    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");
    String acao = "";
    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    DefaultTableCellRenderer coluna1 = new DefaultTableCellRenderer();
    private CardLayout cardLayout;

//////////////////// - mutável - /////////////////////////
    JLabel lbSalaAulaIdSalaAula = new JLabel("Sala de Aula (ID)");
    DefaultComboBoxModel comboboxModelSalaId = new DefaultComboBoxModel();
    JComboBox cbSalaId = new JComboBox(comboboxModelSalaId);

    JLabel lbProfessorIdProfessor = new JLabel("ProfessorI (ID)");
    DefaultComboBoxModel comboboxModelProfessorId = new DefaultComboBoxModel();
    JComboBox cbProfessorId = new JComboBox(comboboxModelProfessorId);

    JLabel lbHorarios = new JLabel("Horarios");
    JTextField tfHorarios = new JTextField(40);

    SalaAulaHasProfessorPK salaAulaHasProfessorPK = new SalaAulaHasProfessorPK();
    SalaAulaHasProfessor salaFinal = new SalaAulaHasProfessor();

    JLabel lbVazio = new JLabel("");

    //Talvez mudar
    String[] colunas = new String[]{"salaAulaIdSalaAula", "professorIdProfessor", "horarios"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    public SalaAulaHasProfessorGUI() {
        Font roboto = null;
        try {
            roboto = Font.createFont(Font.TRUETYPE_FONT, getClass().getClassLoader().getResourceAsStream("Fontes/Roboto-Medium.ttf"));
        } catch (Exception e) {
            System.out.println("");
        }
        roboto = roboto.deriveFont(Font.PLAIN, 18);
        Font roboto_lista = roboto.deriveFont(Font.PLAIN, 16);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        CaixaDeFerramentas cf = new CaixaDeFerramentas();
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - SalaAulaHasProfessor");

        tabela.setEnabled(false);
        //tamanho da tabela
        tabela.setRowHeight(20);
        tabela.setFont(roboto_lista);

        //cabeçalho
        tabela.getTableHeader().setBackground(new Color(135, 206, 250));
        tabela.getTableHeader().setForeground(new Color(0, 0, 0));
        tabela.getTableHeader().setFont(roboto_lista);
        //cor da linha da tabela
        tabela.setGridColor(new Color(0, 0, 0));
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(new Color(135, 206, 250));
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.black));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        btListar.setFont(roboto);
        btBuscar.setFont(roboto);
        btAdicionar.setFont(roboto);
        btSalvar.setFont(roboto);
        btCancelar.setFont(roboto);
        btExcluir.setFont(roboto);
        btAlterar.setFont(roboto);
        lbSalaAulaIdSalaAula.setFont(roboto);
        cbSalaId.setFont(roboto);
        lbProfessorIdProfessor.setFont(roboto);
        cbProfessorId.setFont(roboto);
        pnNorte.add(lbSalaAulaIdSalaAula);
        pnNorte.add(cbSalaId);
        pnNorte.add(lbProfessorIdProfessor);
        pnNorte.add(cbProfessorId);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        tfHorarios.setEditable(false);
        pnCentro.setLayout(new GridLayout(colunas.length - 1, 2));
        lbProfessorIdProfessor.setHorizontalAlignment(SwingConstants.CENTER);
        lbHorarios.setHorizontalAlignment(SwingConstants.CENTER);

        DefaultListCellRenderer centralizar_CB = new DefaultListCellRenderer();
        centralizar_CB.setHorizontalAlignment(DefaultListCellRenderer.CENTER); // center-aligned items
        cbProfessorId.setRenderer(centralizar_CB);
        cbSalaId.setRenderer(centralizar_CB);

        lbHorarios.setFont(roboto);
        tfHorarios.setFont(roboto);

        pnCentro.add(lbHorarios);
        pnCentro.add(tfHorarios);
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnSul.add(pnAvisos, "avisos");
        pnSul.add(pnListagem, "listagem");
        tabela.setEnabled(false);

        pnAvisos.add(new JLabel("Avisos"));

        DAOSalaAulaHasProfessor daoSalaAulaHasProfessor = new DAOSalaAulaHasProfessor();
        DAOSalaAula daoSalaAula = new DAOSalaAula();
        DAOProfessor daoProfessor = new DAOProfessor();

        String[] listaSala = daoSalaAula.listInOrderNomeStringsArray();
        String[] listaProfessor = daoProfessor.listInOrderNomeStringsArray();

        String[] listaSalaAulaHasProfessor = daoSalaAulaHasProfessor.listInOrderNomeStringsArray();
        Arrays.sort(listaSalaAulaHasProfessor);

        for (String s : listaSala) {
            String[] aux = s.split("-");
            comboboxModelSalaId.addElement(aux[0]);
        }

        cbSalaId.setSelectedIndex(0);

        for (String s : listaProfessor) {
            String[] aux = s.split("-");
            comboboxModelProfessorId.addElement(aux[0]);
        }

        cbProfessorId.setSelectedIndex(0);

// listener Buscar
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pnSul, "avisos");
                try {
                    SalaAulaHasProfessorPK chavesPrimarias = new SalaAulaHasProfessorPK();

                    chavesPrimarias.setSalaAulaIdSalaAula(Integer.valueOf(cbSalaId.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                    chavesPrimarias.setProfessorIdProfessor(Integer.valueOf(cbProfessorId.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                    SalaAulaHasProfessor salaFinal = daoSalaAulaHasProfessor.obter(chavesPrimarias);
                    if (salaFinal != null) {//achou o salaAulaHasProfessor na lista
                        //mostrar
                        btAdicionar.setVisible(false);
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        tfHorarios.setText(String.valueOf(salaFinal.getHorarios()));
                        tfHorarios.setEditable(false);
                    } else {//não achou na lista
                        //mostrar botão incluir
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        tfHorarios.setText("");
                        tfHorarios.setEditable(false);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

// listener Adicionar
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cbProfessorId.setEnabled(false);
                cbSalaId.setEnabled(false);
                tfHorarios.requestFocus();
                tfHorarios.setEditable(true);
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "adicionar";
            }
        });

// listener Salvar
        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Short cb_BD;    //fazendo isso pq em no BD boolean é tiny_int que é = ao short
                if (acao.equals("adicionar")) {
                    SalaAulaHasProfessor salaFinal = new SalaAulaHasProfessor();
                }
                try {
                    salaAulaHasProfessorPK.setSalaAulaIdSalaAula(Integer.valueOf(cbSalaId.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                    salaAulaHasProfessorPK.setProfessorIdProfessor(Integer.valueOf(cbProfessorId.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                    
                    salaFinal.setSalaAulaHasProfessorPK(salaAulaHasProfessorPK);
                    salaFinal.setHorarios(String.valueOf(tfHorarios.getText()));
                    
                    if (acao.equals("adicionar")) {
                        daoSalaAulaHasProfessor.inserir(salaFinal);
                    } else {
                        daoSalaAulaHasProfessor.atualizar(salaFinal);
                    }
                    cbProfessorId.setEnabled(true);
                    cbSalaId.setEnabled(true);
                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btListar.setVisible(true);
                    tfHorarios.setEnabled(true);
                    tfHorarios.setEditable(false);
                    tfHorarios.requestFocus();
                    tfHorarios.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(cp, "Erro, Digite Novamente!", "Erro ao buscar", JOptionPane.PLAIN_MESSAGE);

                }
            }
        });

// listener Alterar
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cbProfessorId.setEnabled(false);
                cbSalaId.setEnabled(false);
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfHorarios.setEditable(true);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });

// listener Excluir
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                
                cbProfessorId.setEnabled(true);
                cbSalaId.setEnabled(true);
                btExcluir.setVisible(false);
                tfHorarios.setText("");
                tfHorarios.setEditable(false);
                btAlterar.setVisible(false);
                
                
                SalaAulaHasProfessorPK chavesPrimarias = new SalaAulaHasProfessorPK();

                chavesPrimarias.setSalaAulaIdSalaAula(Integer.valueOf(cbSalaId.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                chavesPrimarias.setProfessorIdProfessor(Integer.valueOf(cbProfessorId.getSelectedItem().toString().split(";")[0].split("-")[0].trim()));
                SalaAulaHasProfessor salaFinal = daoSalaAulaHasProfessor.obter(chavesPrimarias);
                
                if (response == JOptionPane.YES_OPTION) {
                    daoSalaAulaHasProfessor.remover(salaFinal);
                }
            }
        });

// listener Listar
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<SalaAulaHasProfessor> listaSalaAulaHasProfessor = daoSalaAulaHasProfessor.list();
                String[] colunas = new String[]{"SalaAulaIdSalaAula", "ProfessorIdProfessor", "Horarios"};
                String[][] dados = new String[listaSalaAulaHasProfessor.size()][colunas.length];
                String aux[];
                for (int i = 0; i < listaSalaAulaHasProfessor.size(); i++) {
                    aux = listaSalaAulaHasProfessor.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);
                
                cbProfessorId.setEnabled(true);
                cbSalaId.setEnabled(true);
                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
                tfHorarios.setEditable(false);//cor do background e da letra de cada coluna
                coluna1.setBackground(new Color(220, 220, 220));
                coluna1.setForeground(Color.BLUE);
                coluna1.setHorizontalAlignment(SwingConstants.CENTER);
                tabela.getColumnModel().getColumn(0).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(1).setCellRenderer(coluna1);
                tabela.getColumnModel().getColumn(2).setCellRenderer(coluna1);
            }
        });

// listener Cancelar
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cbProfessorId.setEnabled(true);
                cbSalaId.setEnabled(true);
                btCancelar.setVisible(false);
                tfHorarios.setText("");
                tfHorarios.setEditable(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

// listener ao fechar o programa
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai da classe
                dispose();
            }
        });

        setModal(true);
        pack();
        setLocationRelativeTo(null);//centraliza na tela
        setVisible(true);
    }//fim do contrutor de GUI
} //fim da classe
