/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUIs;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/**
 *
 * @author helo
 */
public class Menu extends JFrame{
    Container cp;
    JLabel lbNaoRelacionada = new JLabel("Tabelas Não");
    JLabel lbNaoRelacionada2 = new JLabel(" Relacionadas");
    JButton btCurso = new JButton("Curso");
    JButton btNivel = new JButton("Nível");
    JButton btPessoa = new JButton("Pessoa");
    JButton btSala = new JButton("Sala de Aula");
    JLabel lbUmPraVarios = new JLabel("1");
    JLabel lbUmPraVarios2 = new JLabel(":N");
    JButton btAluno = new JButton("Aluno");
    JButton btProfessor = new JButton("Professor");
    JButton btMatricula = new JButton("Matrícula");
    JButton btTurma = new JButton("Turma");
    JLabel lbVariosPraVarios = new JLabel("N");
    JLabel lbVariosPraVarios2 = new JLabel(":M");
    JButton btSalaProfessor = new JButton("Sala_Aula_Has_Professor");
    
    public Menu() {
        cp= getContentPane();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Cadastro");
        
        btCurso.setBackground(new Color(135, 206, 250));
        btNivel.setBackground(new Color(255, 140, 0));
        btPessoa.setBackground(new Color(255, 203, 219));
        btSala.setBackground(new Color(200, 162, 200));
        btAluno.setBackground(new Color(144, 238, 144));
        btProfessor.setBackground(new Color(255, 100, 100));
        btMatricula.setBackground(new Color(255, 255, 0));
        btTurma.setBackground(new Color(252, 15, 192));
        btSalaProfessor.setBackground(new Color(0, 139, 139));
        
        lbNaoRelacionada.setHorizontalAlignment(SwingConstants.RIGHT);
        lbNaoRelacionada2.setHorizontalAlignment(SwingConstants.LEFT);
        
        lbUmPraVarios.setHorizontalAlignment(SwingConstants.RIGHT);
        lbUmPraVarios2.setHorizontalAlignment(SwingConstants.LEFT);
        
        lbVariosPraVarios.setHorizontalAlignment(SwingConstants.RIGHT);
        lbVariosPraVarios2.setHorizontalAlignment(SwingConstants.LEFT);
        
        cp.setBackground(Color.white);
        
        cp.setLayout(new GridLayout(8,2));
        
        cp.add(lbNaoRelacionada);
        cp.add(lbNaoRelacionada2);
        cp.add(btCurso);
        cp.add(btNivel);
        cp.add(btPessoa);
        cp.add(btSala);
        cp.add(lbUmPraVarios);
        cp.add(lbUmPraVarios2);
        cp.add(btAluno);
        cp.add(btProfessor);
        cp.add(btMatricula);
        cp.add(btTurma);
        cp.add(lbVariosPraVarios);
        cp.add(lbVariosPraVarios2);
        cp.add(btSalaProfessor);
        
        
        
        
        btCurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CursoGUI cursoGUI = new CursoGUI();
            }
        });
        
        btNivel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                NivelGUI nivelGUI = new NivelGUI();
            }
        });
        
        btPessoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PessoaGUI pessoaGUI = new PessoaGUI();
            }
        });
        
        btSala.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SalaAulaGUI salaAulaGUI = new SalaAulaGUI();
            }
        });
        
        btAluno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AlunoGUI alunoGUI = new AlunoGUI();
            }
        });
        
        btProfessor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProfessorGUI professorGUI = new ProfessorGUI();
            }
        });
        
        btMatricula.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MatriculaAlunoGUI matriculaAlunoGUI = new MatriculaAlunoGUI();
            }
        });
        
        btTurma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TurmaGUI turmaGUI = new TurmaGUI();
            }
        });
        
        btSalaProfessor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SalaAulaHasProfessorGUI salaAulaHasProfessorGUI = new SalaAulaHasProfessorGUI();
            }
        });
           
        setSize(400,300);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

