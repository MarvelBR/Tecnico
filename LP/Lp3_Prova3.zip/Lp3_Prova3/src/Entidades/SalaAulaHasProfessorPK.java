/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author helo
 */
@Embeddable
public class SalaAulaHasProfessorPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "sala_aula_id_sala_aula")
    private int salaAulaIdSalaAula;
    @Basic(optional = false)
    @Column(name = "professor_id_professor")
    private int professorIdProfessor;

    public SalaAulaHasProfessorPK() {
    }

    public SalaAulaHasProfessorPK(int salaAulaIdSalaAula, int professorIdProfessor) {
        this.salaAulaIdSalaAula = salaAulaIdSalaAula;
        this.professorIdProfessor = professorIdProfessor;
    }

    public int getSalaAulaIdSalaAula() {
        return salaAulaIdSalaAula;
    }

    public void setSalaAulaIdSalaAula(int salaAulaIdSalaAula) {
        this.salaAulaIdSalaAula = salaAulaIdSalaAula;
    }

    public int getProfessorIdProfessor() {
        return professorIdProfessor;
    }

    public void setProfessorIdProfessor(int professorIdProfessor) {
        this.professorIdProfessor = professorIdProfessor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) salaAulaIdSalaAula;
        hash += (int) professorIdProfessor;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SalaAulaHasProfessorPK)) {
            return false;
        }
        SalaAulaHasProfessorPK other = (SalaAulaHasProfessorPK) object;
        if (this.salaAulaIdSalaAula != other.salaAulaIdSalaAula) {
            return false;
        }
        if (this.professorIdProfessor != other.professorIdProfessor) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return salaAulaIdSalaAula + ";" + professorIdProfessor;
    }
    
}
