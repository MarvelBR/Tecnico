/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author helo
 */
@Entity
@Table(name = "sala_aula")
@NamedQueries({
    @NamedQuery(name = "SalaAula.findAll", query = "SELECT s FROM SalaAula s")})
public class SalaAula implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "salaAula")
    private List<SalaAulaHasProfessor> salaAulaHasProfessorList;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "salaAulaId")
    private List<Turma> turmaList;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_sala_aula")
    private Integer idSalaAula;
    @Basic(optional = false)
    @Column(name = "nome_sala")
    private String nomeSala;

    public SalaAula() {
    }

    public SalaAula(Integer idSalaAula) {
        this.idSalaAula = idSalaAula;
    }

    public SalaAula(Integer idSalaAula, String nomeSala) {
        this.idSalaAula = idSalaAula;
        this.nomeSala = nomeSala;
    }

    public Integer getIdSalaAula() {
        return idSalaAula;
    }

    public void setIdSalaAula(Integer idSalaAula) {
        this.idSalaAula = idSalaAula;
    }

    public String getNomeSala() {
        return nomeSala;
    }

    public void setNomeSala(String nomeSala) {
        this.nomeSala = nomeSala;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idSalaAula != null ? idSalaAula.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SalaAula)) {
            return false;
        }
        SalaAula other = (SalaAula) object;
        if ((this.idSalaAula == null && other.idSalaAula != null) || (this.idSalaAula != null && !this.idSalaAula.equals(other.idSalaAula))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return idSalaAula + ";" + nomeSala;
    }

    public List<Turma> getTurmaList() {
        return turmaList;
    }

    public void setTurmaList(List<Turma> turmaList) {
        this.turmaList = turmaList;
    }

    public List<SalaAulaHasProfessor> getSalaAulaHasProfessorList() {
        return salaAulaHasProfessorList;
    }

    public void setSalaAulaHasProfessorList(List<SalaAulaHasProfessor> salaAulaHasProfessorList) {
        this.salaAulaHasProfessorList = salaAulaHasProfessorList;
    }
    
}
