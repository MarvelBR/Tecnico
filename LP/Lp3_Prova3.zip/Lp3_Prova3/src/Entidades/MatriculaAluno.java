/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author helo
 */
@Entity
@Table(name = "matricula_aluno")
@NamedQueries({
    @NamedQuery(name = "MatriculaAluno.findAll", query = "SELECT m FROM MatriculaAluno m")})
public class MatriculaAluno implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_matricula_aluno")
    private Integer idMatriculaAluno;
    @Basic(optional = false)
    @Column(name = "data_inicio")
    @Temporal(TemporalType.DATE)
    private Date dataInicio;
    @Basic(optional = false)
    @Column(name = "data_fim")
    @Temporal(TemporalType.DATE)
    private Date dataFim;
    @Basic(optional = false)
    @Column(name = "situacao_aluno")
    private String situacaoAluno;
    @Basic(optional = false)
    @Column(name = "ultima_atualizacao")
    private String ultimaAtualizacao;
    @JoinColumn(name = "aluno_id", referencedColumnName = "id_aluno")
    @ManyToOne(optional = false)
    private Aluno alunoId;
    @JoinColumn(name = "curso_id", referencedColumnName = "id_curso")
    @ManyToOne(optional = false)
    private Curso cursoId;

    public MatriculaAluno() {
    }

    public MatriculaAluno(Integer idMatriculaAluno) {
        this.idMatriculaAluno = idMatriculaAluno;
    }

    public MatriculaAluno(Integer idMatriculaAluno, Date dataInicio, Date dataFim, String situacaoAluno, String ultimaAtualizacao) {
        this.idMatriculaAluno = idMatriculaAluno;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.situacaoAluno = situacaoAluno;
        this.ultimaAtualizacao = ultimaAtualizacao;
    }

    public Integer getIdMatriculaAluno() {
        return idMatriculaAluno;
    }

    public void setIdMatriculaAluno(Integer idMatriculaAluno) {
        this.idMatriculaAluno = idMatriculaAluno;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }

    public Date getDataFim() {
        return dataFim;
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }

    public String getSituacaoAluno() {
        return situacaoAluno;
    }

    public void setSituacaoAluno(String situacaoAluno) {
        this.situacaoAluno = situacaoAluno;
    }

    public String getUltimaAtualizacao() {
        return ultimaAtualizacao;
    }

    public void setUltimaAtualizacao(String ultimaAtualizacao) {
        this.ultimaAtualizacao = ultimaAtualizacao;
    }

    public Aluno getAlunoId() {
        return alunoId;
    }

    public void setAlunoId(Aluno alunoId) {
        this.alunoId = alunoId;
    }

    public Curso getCursoId() {
        return cursoId;
    }

    public void setCursoId(Curso cursoId) {
        this.cursoId = cursoId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idMatriculaAluno != null ? idMatriculaAluno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MatriculaAluno)) {
            return false;
        }
        MatriculaAluno other = (MatriculaAluno) object;
        if ((this.idMatriculaAluno == null && other.idMatriculaAluno != null) || (this.idMatriculaAluno != null && !this.idMatriculaAluno.equals(other.idMatriculaAluno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return idMatriculaAluno + ";" + alunoId.getIdAluno() + "-" + alunoId.getPessoaId().getNome() + ";" + cursoId.getIdCurso() + "-" + cursoId.getLingua() + ";" + sdf.format(dataInicio) + ";" + sdf.format(dataFim) + ";" + situacaoAluno + ";" + ultimaAtualizacao;
    }
    
}
