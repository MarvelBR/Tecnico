/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author helo
 */
@Entity
@Table(name = "turma")
@NamedQueries({
    @NamedQuery(name = "Turma.findAll", query = "SELECT t FROM Turma t")})
public class Turma implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_turma")
    private Integer idTurma;
    @JoinColumn(name = "aluno_id", referencedColumnName = "id_aluno")
    @ManyToOne(optional = false)
    private Aluno alunoId;
    @JoinColumn(name = "curso_id", referencedColumnName = "id_curso")
    @ManyToOne(optional = false)
    private Curso cursoId;
    @JoinColumn(name = "nivel_id", referencedColumnName = "id_nivel")
    @ManyToOne(optional = false)
    private Nivel nivelId;
    @JoinColumn(name = "professor_id_professor", referencedColumnName = "id_professor")
    @ManyToOne(optional = false)
    private Professor professorIdProfessor;
    @JoinColumn(name = "sala_aula_id", referencedColumnName = "id_sala_aula")
    @ManyToOne(optional = false)
    private SalaAula salaAulaId;

    public Turma() {
    }

    public Turma(Integer idTurma) {
        this.idTurma = idTurma;
    }

    public Integer getIdTurma() {
        return idTurma;
    }

    public void setIdTurma(Integer idTurma) {
        this.idTurma = idTurma;
    }

    public Aluno getAlunoId() {
        return alunoId;
    }

    public void setAlunoId(Aluno alunoId) {
        this.alunoId = alunoId;
    }

    public Curso getCursoId() {
        return cursoId;
    }

    public void setCursoId(Curso cursoId) {
        this.cursoId = cursoId;
    }

    public Nivel getNivelId() {
        return nivelId;
    }

    public void setNivelId(Nivel nivelId) {
        this.nivelId = nivelId;
    }

    public Professor getProfessorIdProfessor() {
        return professorIdProfessor;
    }

    public void setProfessorIdProfessor(Professor professorIdProfessor) {
        this.professorIdProfessor = professorIdProfessor;
    }

    public SalaAula getSalaAulaId() {
        return salaAulaId;
    }

    public void setSalaAulaId(SalaAula salaAulaId) {
        this.salaAulaId = salaAulaId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTurma != null ? idTurma.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Turma)) {
            return false;
        }
        Turma other = (Turma) object;
        if ((this.idTurma == null && other.idTurma != null) || (this.idTurma != null && !this.idTurma.equals(other.idTurma))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return idTurma + ";" + alunoId.getIdAluno() + "-" + alunoId.getPessoaId().getNome() + ";" + cursoId.getIdCurso() + "-" + cursoId.getLingua() + ";"
                + nivelId.getIdNivel() + "-" + nivelId.getNomeNivel() + ";" + salaAulaId.getIdSalaAula() + "-" + salaAulaId.getNomeSala() + ";"
                + professorIdProfessor.getIdProfessor() + "-" + professorIdProfessor.getPessoaIdPessoa().getNome();
    }
    
}
