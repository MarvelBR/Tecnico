/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author helo
 */
@Entity
@Table(name = "sala_aula_has_professor")
@NamedQueries({
    @NamedQuery(name = "SalaAulaHasProfessor.findAll", query = "SELECT s FROM SalaAulaHasProfessor s")})
public class SalaAulaHasProfessor implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected SalaAulaHasProfessorPK salaAulaHasProfessorPK;
    @Basic(optional = false)
    @Column(name = "horarios")
    private String horarios;
    @JoinColumn(name = "professor_id_professor", referencedColumnName = "id_professor", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Professor professor;
    @JoinColumn(name = "sala_aula_id_sala_aula", referencedColumnName = "id_sala_aula", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private SalaAula salaAula;

    public SalaAulaHasProfessor() {
    }

    public SalaAulaHasProfessor(SalaAulaHasProfessorPK salaAulaHasProfessorPK) {
        this.salaAulaHasProfessorPK = salaAulaHasProfessorPK;
    }

    public SalaAulaHasProfessor(SalaAulaHasProfessorPK salaAulaHasProfessorPK, String horarios) {
        this.salaAulaHasProfessorPK = salaAulaHasProfessorPK;
        this.horarios = horarios;
    }

    public SalaAulaHasProfessor(int salaAulaIdSalaAula, int professorIdProfessor) {
        this.salaAulaHasProfessorPK = new SalaAulaHasProfessorPK(salaAulaIdSalaAula, professorIdProfessor);
    }

    public SalaAulaHasProfessorPK getSalaAulaHasProfessorPK() {
        return salaAulaHasProfessorPK;
    }

    public void setSalaAulaHasProfessorPK(SalaAulaHasProfessorPK salaAulaHasProfessorPK) {
        this.salaAulaHasProfessorPK = salaAulaHasProfessorPK;
    }

    public String getHorarios() {
        return horarios;
    }

    public void setHorarios(String horarios) {
        this.horarios = horarios;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public SalaAula getSalaAula() {
        return salaAula;
    }

    public void setSalaAula(SalaAula salaAula) {
        this.salaAula = salaAula;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (salaAulaHasProfessorPK != null ? salaAulaHasProfessorPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SalaAulaHasProfessor)) {
            return false;
        }
        SalaAulaHasProfessor other = (SalaAulaHasProfessor) object;
        if ((this.salaAulaHasProfessorPK == null && other.salaAulaHasProfessorPK != null) || (this.salaAulaHasProfessorPK != null && !this.salaAulaHasProfessorPK.equals(other.salaAulaHasProfessorPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return salaAulaHasProfessorPK + ";" + horarios;
    }
    
}
