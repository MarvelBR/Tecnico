package Controle;

import java.util.ArrayList;
import java.util.List;
import tools.ManipulaArquivo;
import tools.StringTools;

/**
 *
 * @author Erick
 */
public class GerarClasseDeEntidade {

    public GerarClasseDeEntidade(String nomeDaClasse, List<String> atributo, String caminho) {
        StringTools st = new StringTools();
        List<String> cg = new ArrayList();//código gerado
        cg.add("package Entidades;");
        cg.add("/**\n"
                + " *\n"
                + " * @author Erick\n"
                + " */");
        cg.add("import java.util.Date;\n"
                + "import tools.CaixaDeFerramentas;");
        cg.add("public class " + nomeDaClasse + " {\n");
        String[] aux;
        for (int i = 0; i < atributo.size(); i++) {
            aux = atributo.get(i).split(";");
            aux[0] = aux[0].toLowerCase();

            if (aux[0].equals("date") || aux[0].equals("string")) {
                cg.add("private " + st.plMaiusc(aux[0]) + " " + aux[1] + ";");
            } else {
                cg.add("private  " + aux[0] + " " + aux[1] + ";");
            }
        }

        cg.add("public " + nomeDaClasse + "() {\n"
                + "    }");

        String s = "";

        for (int i = 0; i < atributo.size(); i++) {
            aux = atributo.get(i).split(";");
            aux[0] = aux[0].toLowerCase();

            if (aux[0].equals("date") || aux[0].equals("string")) {
                s = s + st.plMaiusc(aux[0]) + " " + aux[1] + ",";
            } else {
                s = s + aux[0] + " " + aux[1] + ",";
            }
        }
        s = s.substring(0, s.length() - 1);
        cg.add("public " + nomeDaClasse + "(" + s + ") {\n");
        for (int i = 0; i < atributo.size(); i++) {
            aux = atributo.get(i).split(";");
            cg.add("this." + aux[1] + "=" + aux[1] + ";\n");
        }
        cg.add("}");

        cg.add("\n\n //gets e sets\n");

        for (int i = 0; i < atributo.size(); i++) {
            aux = atributo.get(i).split(";");
            aux[0] = aux[0].toLowerCase();

            if (aux[0].equals("date") || aux[0].equals("string")) {
                cg.add("public " + st.plMaiusc(aux[0]) + " get" + st.plMaiusc(aux[1]) + "() {\n"
                        + "        return " + aux[1] + ";\n"
                        + "    }\n\n");
            } else {
                if (aux[0].equals("boolean")) {
                    cg.add("public " + aux[0] + " is" + st.plMaiusc(aux[1]) + "() {\n"
                            + "        return " + aux[1] + ";\n"
                            + "    }\n\n");
                } else {
                    cg.add("public " + aux[0] + " get" + st.plMaiusc(aux[1]) + "() {\n"
                            + "        return " + aux[1] + ";\n"
                            + "    }\n\n");
                }
            }
        }

        for (int i = 0; i < atributo.size(); i++) {
            aux = atributo.get(i).split(";");
            aux[0] = aux[0].toLowerCase();
            if (aux[0].equals("date") || aux[0].equals("string")) {
                cg.add("public void" + " set" + st.plMaiusc(aux[1])
                        + "(" + st.plMaiusc(aux[0]) + " " + aux[1] + ") {\n"
                        + "this." + aux[1] + "=" + aux[1] + ";\n"
                        + "    }\n\n");
            } else {
                cg.add("public void" + " set" + st.plMaiusc(aux[1])
                        + "(" + aux[0] + " " + aux[1] + ") {\n"
                        + "this." + aux[1] + "=" + aux[1] + ";\n"
                        + "    }\n\n");

            }
        }

        cg.add(" @Override\n"
                + "    public String toString() {\n"
                + "CaixaDeFerramentas cf = new CaixaDeFerramentas();"
                + "\n return ");

        s = "";
        for (int i = 0; i < atributo.size(); i++) {
            aux = atributo.get(i).split(";");
            aux[0] = aux[0].toLowerCase();

            if (aux[0].equals("date")) {
                s = s + "cf.converteDeDateParaString(" + aux[1] + ") + \";\"+";
            } else {
                if (aux[0].equals("boolean")) {
                    s = s + "(" + aux[1] + "?\"Sim\":\"Não\") +\";\"+";
                } else {
                    s = s + " " + aux[1] + "+ \";\"+";
                }
            }
        }

        s = s.substring(0, s.length() - 6);

        cg.add(s + ";");
        cg.add("\n}");

        cg.add("}//fim da classe\n\n");

//        for (String linha : cg) {
//            System.out.println(linha);
//        }
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        manipulaArquivo.salvarArquivo(caminho + "/src/Entidades/" + nomeDaClasse + ".java", cg);

    }

}
