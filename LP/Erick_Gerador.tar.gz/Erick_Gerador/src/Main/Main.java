package Main;

import GUI.GUIDoGerador;

/**
 *
 * @author radames
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUIDoGerador guiDoGerador = new GUIDoGerador();
    }

}
