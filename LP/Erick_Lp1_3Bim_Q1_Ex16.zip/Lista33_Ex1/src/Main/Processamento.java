/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public int[] vetorComNumerosPares(int[] vetor){
        int [] vetorPares = new int[vetor.length];
        int j = 0;
        
        for (int i = 0; i < vetor.length; i++){
            if (vetor[i]%2 == 0){
                vetorPares[j] = vetor[i];
                j++;
            }
        }
        int [] v1 = new int[j];
        for (int i = 0; i < j; i++) {
            v1[i] = vetorPares[i];
        }
        return v1;
    }
    
    public int[] vetorComNumerosImpares(int[] vetor){
        int [] vetorImpares = new int[vetor.length];
        int j = 0;
        
        for (int i = 0; i < vetor.length; i++){
            if (vetor[i]%2 != 0){
                vetorImpares[j] = vetor[i];
                j++;
            }
        }
        int [] v2 = new int[j];
        for (int i = 0; i < j; i++) {
            v2[i] = vetorImpares[i];
        }
        return v2;
    }
}
