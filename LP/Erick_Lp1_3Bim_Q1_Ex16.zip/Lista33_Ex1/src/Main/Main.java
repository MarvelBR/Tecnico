/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        Processamento processamento = new Processamento();
        Saida saida = new Saida();        
        int max = 10;
        int[] vetor = entrada.lerVetorDeNumerosInteiros("valor", max);        
        int pares[] = processamento.vetorComNumerosPares(vetor);
        int impares[] = processamento.vetorComNumerosImpares(vetor);        
        saida.imprimirVetorDeInteiros("Todos os valores lidos:", vetor);
        saida.imprimirVetorDeInteiros("Somente os pares:", pares);
        saida.imprimirVetorDeInteiros("Somente os ímpares:", impares);
    }
    
}
