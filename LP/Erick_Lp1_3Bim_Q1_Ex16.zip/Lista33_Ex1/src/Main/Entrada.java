/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {

    Scanner teclado = new Scanner(System.in);

    public int[] lerVetorDeNumerosInteiros(String mensagem, int max) {
        int[] v = new int[max];
        for (int i = 0; i < v.length; i++) {
            while (true) {
                try {
                    System.out.print(mensagem + "[" + i + "] = ");
                    v[i] = teclado.nextInt();
                    break;
                } catch (Exception e) {
                    System.out.println("Erro, digite novamente");
                    teclado = new Scanner(System.in);
                }
            }
        }
        return v;
    }
}
