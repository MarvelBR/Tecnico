/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Date;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        Processamento processamento = new Processamento();
        Saida saida = new Saida();
        
        
        String nome = entrada.lerString("Digite seu nome");
        saida.imprimirValores("Oii "+nome+" que bom que você veio. Mas então amigo queria pedir sugestões de nomes para meu filho.");
        String nome1 = entrada.lerString("Se for menino?");
        String nome2 = entrada.lerString("E se for menina?");
        saida.imprimirValores(nome1 +" e "+ nome2 + " que nomes lindos, obrigado pela sugestão.");
        saida.imprimirValores("                                                                             ");
        
        Date data_de_nascimento = entrada.lerData("Falando no meu filho, chuta quando ele vai nascer: ");
        processamento.verData(data_de_nascimento);
        saida.imprimirValores("                                                                             ");
        
        saida.imprimirValores("Acho que por agora é isso, pegue uma mesa pra se sentar, a e você deve ver alguns conhecidos aqui.");
        saida.imprimirValores("Cada mesa já está ocupada por 3 pessoas, escolha uma e você vai ver quem está lá.");
        saida.imprimirValores("                                                                             ");
        
        int[] mesa = entrada.lerVetorDeNumerosInteiros("Digite a mesa (sendo elas da 1 a 3) para ver quem está sentado nela:");
        processamento.verMesa(mesa);
        
        int escolher_mesa = entrada.lerNumeroInt("Digite a mesa em que você vai se sentar:");
        saida.imprimirValores("Você acaba escolhendo a mesa "+ escolher_mesa +" e se senta na cadeira 4.");
        processamento.verLista(nome, escolher_mesa);
        
    }
    
}
