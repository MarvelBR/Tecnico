/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {
    Scanner teclado = new Scanner(System.in);
    
    public String lerString(String mensagem) {
        String s = "";

        while (true) {
            System.out.print(mensagem + ": ");
            s = teclado.nextLine();
            s = s.trim();//retira espaços em branco
            
            if (!s.equals("")) {
                break;
            } else {
                System.out.println("Digite uma string não vazia");
            }
        }
        return s;
    }
    
    public Date lerData(String mensagem){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        while(true){
            try{    
                System.out.print(mensagem);
                String sData = teclado.nextLine();
                Date d = sdf.parse(sData);
                return d;
            }catch(ParseException ex){
                System.out.println("Erro, digite uma data válida");
            }
        }   
    }
    
    public int[] lerVetorDeNumerosInteiros(String mensagem) {
        int[] v = new int[3];
        for (int i = 0; i < v.length; i++) {
            while (true) {
                try {
                    System.out.print(mensagem);
                    v[i] = teclado.nextInt();
                    while (v[i] != 1 && v[i] != 2 && v[i] != 3) {
                    System.out.print("Erro, digite uma mesa existente:");
                    v[i] = teclado.nextInt();
                }
                    break;
                } catch (Exception e) {
                    System.out.println("Erro, digite novamente");
                    teclado = new Scanner(System.in);
                }
            }
        }
        return v;
    }
    
    public int lerNumeroInt(String mensagem) {
        int z = 0;
        while (true) {
            try {
                System.out.print(mensagem);
                z = teclado.nextInt();
                while (z != 1 && z != 2 && z != 3) {
                    System.out.print("Erro, digite ma mesa existente:");
                    z = teclado.nextInt();
                }
                break;
            } catch (Exception e) {
                System.out.println("Erro, digite novamente");
                teclado = new Scanner(System.in);
            }
        }
        return z;
    }
}
