/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import tools.ConverteDatas;

/**
 *
 * @author erick
 */
class Processamento {
    ArrayList<Object> lugar_para_sentar = new ArrayList<Object>();
    
    public void verData(Date data_de_nascimento){
        ConverteDatas converteDatas = new ConverteDatas();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");  
        
        String data_certa = "07/06/2022";
        Date data_certa2 = converteDatas.converteDeStringParaDate(data_certa);
        
        String data_digitada = converteDatas.converteDeDateParaString(data_de_nascimento);
              
        if (data_digitada.equals(data_certa)){
            System.out.println("Caramba você têm uma boa memória!");
            
        }
        if (!data_digitada.equals(data_certa)){
            System.out.println("Hmm é não foi dessa vez, meu filho vai nascer no dia " + sdf.format(data_certa2)+".");
        }
    }
    
    public void verMesa(int[] mesa){
        ArrayList<String> mesa1 = new ArrayList();
        ArrayList<String> mesa2 = new ArrayList();
        ArrayList<String> mesa3 = new ArrayList();
        
        mesa1.add("Isabelly Patricio; sentada na cadeira 1");
        mesa1.add("Erick Molina; sentado na cadeira 2");
        mesa1.add("Thiago Santos; sentado na cadeira 3");
        
        mesa2.add("Gabriel Reitz; sentado na cadeira 1");
        mesa2.add("Victor Srutkoske; sentado na cadeira 2");
        mesa2.add("André Felipe; sentado na cadeira 3");
        
        mesa3.add("Eber Louback; sentado na cadeira 1");
        mesa3.add("Pedro Fuchs; sentado na cadeira 2");
        mesa3.add("Hellen Vitória; sentada na cadeira 3");
        
        for (int i = 0; i < mesa.length; i++){
            if(mesa[i] == 1){
                System.out.println("Chegando na mesa 1 você encontra:");
                System.out.println(mesa1);
                System.out.println("                                                   ");
            }
            
            if(mesa[i] == 2){
                System.out.println("Chegando na mesa 2 você encontra:");
                System.out.println(mesa2);
                System.out.println("                                                   ");
            }
            
            if(mesa[i] == 3){
                System.out.println("Chegando na mesa 3 você encontra:");
                System.out.println(mesa3);
                System.out.println("                                                   ");
            }
        }    
    }
    public void verLista(String nome, int escolher_mesa){
        lugar_para_sentar.add("Nome: "+ nome + "; ");
        lugar_para_sentar.add("Mesa: " + escolher_mesa + "; " + "Cadeira: 4");
        
        System.out.print("[");
        for (int i=0; i<lugar_para_sentar.size(); i++) {
            System.out.print(lugar_para_sentar.get(i));
        }
        System.out.println("]");
    }
}
