/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author erick
 */
class Processamento {
    public void verData(Date data){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyy");
        int ano = Integer.parseInt(sdf.format(data));
        int ano2 = Integer.parseInt(sdf2.format(data));
        
        if(ano%400 == 0 || ano2%400 == 0){
            System.out.print(" é um ano bissexto");
        }
        
        if(ano%4 == 0 && ano%100 != 0 || ano2%4 == 0 && ano2%100 != 0){
            System.out.print(" é um ano bissexto");
        }        
        else{
            System.out.print(" não é um ano bissexto");
        }
    }
}
