/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public void verNome(String nome) {
        nome = nome.replace("DOS", "");
        nome = nome.replace("DO", "");
        nome = nome.replace("DA", "");
        nome = nome.replace("DAS", "");
        nome = nome.replace("DE", "");
        nome = nome.replace("E", "");

        for (int i = 0; i < nome.length(); i++) {
            if (nome.charAt(i) == ' ') {
                System.out.print(nome.charAt(i + 1));
            }
        }
    }
}
