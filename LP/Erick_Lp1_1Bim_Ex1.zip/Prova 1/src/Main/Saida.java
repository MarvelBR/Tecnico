/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.DecimalFormat;

/**
 *
 * @author erick
 */
class Saida {
    public void imprimirLimites(String mensagem, double y){
        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        System.out.println(mensagem + ":" + decimalFormat.format(y) + " reais");
    }
}
