/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.DecimalFormat;

/**
 *
 * @author erick
 */
class Processamento {
    public double somarSalario(double a, double b){
        double limite_12 = a*12*0.3;
        double restante_12 = (a*12) - b;
        double mes_12 = a - (b/12);
        double restante_24 = (a*24) - b;
        double mes_24 = a - (b/24);
        
        if (b == 0){
            System.out.println("Obrigado e até a próxima");       
        }
        if (b>0 && b<=limite_12) {  
            DecimalFormat decimalFormat = new DecimalFormat("#0.00");
            System.out.println("O valor das parcelas no limite 12 será de:" + decimalFormat.format(b/12) + " reais");
            System.out.println("O salário restante mensalmente será de:" + decimalFormat.format(mes_12) + " reais");
            System.out.println("O salário restante após os 12 meses será de:" + decimalFormat.format(restante_12) + " reais");
            
        }
        if (b>limite_12 && b<=limite_12*2) {
            DecimalFormat decimalFormat = new DecimalFormat("#0.00");
            System.out.println("O valor das parcelas no limite 24 será de:" + decimalFormat.format(b/24) + " reais");
            System.out.println("O salário restante mensalmente será de:" + decimalFormat.format(mes_24) + " reais");
            System.out.println("O salário restante após os 24 meses será de:" + decimalFormat.format(restante_24) + " reais");
            
        }
        return limite_12;
     }
}
