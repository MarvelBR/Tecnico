/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author erick
 */
class Processamento {
    public void verData(Date data){
        SimpleDateFormat sdf = new SimpleDateFormat("MM");
        
        if(sdf.format(data).equals("01")){
            System.out.println("O mês de janeiro têm no máximo 31 dias");
        }
        
        if(sdf.format(data).equals("02")){
            System.out.println("O mês de fevereiro têm no máximo 29 dias");
        }
        
        if(sdf.format(data).equals("03")){
            System.out.println("O mês de março têm no máximo 30 dias");
        }
        
        if(sdf.format(data).equals("04")){
            System.out.println("O mês de abril têm no máximo 31 dias");
        }
        
        if(sdf.format(data).equals("05")){
            System.out.println("O mês de maio têm no máximo 30 dias");
        }
        
        if(sdf.format(data).equals("06")){
            System.out.println("O mês de junho têm no máximo 31 dias");
        }
        
        if(sdf.format(data).equals("07")){
            System.out.println("O mês de julho têm no máximo 30 dias");
        }
        
        if(sdf.format(data).equals("08")){
            System.out.println("O mês de agosto têm no máximo 31 dias");
        }
        
        if(sdf.format(data).equals("09")){
            System.out.println("O mês de setembro têm no máximo 30 dias");
        }
        
        if(sdf.format(data).equals("10")){
            System.out.println("O mês de outubro têm no máximo 31 dias");
        }
        
        if(sdf.format(data).equals("11")){
            System.out.println("O mês de novembro têm no máximo 30 dias");
        }
        
        if(sdf.format(data).equals("12")){
            System.out.println("O mês de dezembro têm no máximo 31 dias");
        }
    }
}
