/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {
    Scanner teclado = new Scanner(System.in);
    public Date lerData(String mensagem){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        while(true){
            try{    
                System.out.print(mensagem);
                String sData = teclado.nextLine();
                Date d = sdf.parse(sData);
                return d;
            }catch(ParseException ex){
                System.out.println("Erro, digite uma data válida");
            }
        }   
    }
}
