/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {
    Scanner teclado = new Scanner(System.in);
    
    public int lerNumeroInteiro(String mensagem) {
        int z = 0;
        while (true) {
            try {
                System.out.print(mensagem);
                z = teclado.nextInt();
                while (z != 1 && z != 2 && z != 3) {
                    System.out.print("Erro, digite um valor de 1 a 3:");
                    z = teclado.nextInt();
                }
                break;
            } catch (Exception e) {
                System.out.println("Erro, digite novamente");
                teclado = new Scanner(System.in);
            }
        }
        return z;
    }
    public Pessoa adicionarPessoa(){
        Pessoa pessoa = new Pessoa();
        
        String cpf = "";
        String nome = "";
        double altura = 0;
        double peso = 0;
        
        while (true){
            System.out.print("Digite o CPF: ");
            cpf = teclado.nextLine();
            cpf = cpf.trim();
            
            if (!cpf.equals("")){
                break;
            } else {
                System.out.println("CPF incorreto");
            }
        }
        
        while (true){
            System.out.print("Digite o nome: ");
            nome = teclado.nextLine();
            nome = nome.trim();
            
            if (!nome.equals("")){
                break;
            } else {
                System.out.println("Nome inválido");
            }
        }
        
        while (true) {
            try {
                System.out.print("Digite a altura: ");
                altura = teclado.nextDouble();
                while (altura < 0) {
                    System.out.print("Erro, digite um valor positivo:");
                    altura = teclado.nextDouble();
                }
                break;
            } catch (Exception e) {
                System.out.println("Erro, digite novamente");
                teclado = new Scanner(System.in);
            }
        }
        
        while (true) {
            try {
                System.out.print("Digite o peso: ");
                peso = teclado.nextDouble();
                while (peso < 0) {
                    System.out.print("Erro, digite um valor positivo:");
                    peso = teclado.nextDouble();
                }
                break;
            } catch (Exception e) {
                System.out.println("Erro, digite novamente");
                teclado = new Scanner(System.in);
            }
        }
        
        pessoa.setCpf(cpf);
        pessoa.setNome(nome);
        pessoa.setAltura(altura);
        pessoa.setPeso(peso);
        
        return pessoa;
    }
    
    public void pausaEnter(){
        System.out.println(" "); 
    }
}
