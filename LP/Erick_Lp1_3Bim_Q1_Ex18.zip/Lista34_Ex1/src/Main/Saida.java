/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;


/**
 *
 * @author erick
 */
class Saida {
    public void listarPessoas(Pessoa vetorPessoa[], int contPessoa){       
        for (int i = 0; i < contPessoa; i++){
            System.out.println(vetorPessoa[i]);
        }
    }
}
