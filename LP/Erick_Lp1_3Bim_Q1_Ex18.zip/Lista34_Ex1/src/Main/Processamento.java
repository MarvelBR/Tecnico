/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.DecimalFormat;

/**
 *
 * @author erick
 */
class Processamento {
    public Pessoa[] calcularImcParaTodasAsPessoas(Pessoa vetorPessoa[], int contPessoa) {
        Pessoa pessoa = new Pessoa();
        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        double imc;
        String situacaoImc = pessoa.getSituacaoImc();
        
        
        for (int i = 0; i < contPessoa; i++){
            imc = vetorPessoa[i].getPeso() / (vetorPessoa[i].getAltura() * vetorPessoa[i].getAltura());
            decimalFormat.format(imc);
            System.out.println("O imc formatado fica assim:"+decimalFormat.format(imc));
            vetorPessoa[i].setImc(imc);
            
            if(imc < 18.5){
                situacaoImc = "Abaixo do Peso";
                vetorPessoa[i].setSituacaoImc(situacaoImc);
            }
            
            if(imc >= 18.5 && imc < 24.9){
                situacaoImc = "Peso normal";
                vetorPessoa[i].setSituacaoImc(situacaoImc);
            }
            
            if(imc >= 25 && imc < 29.9){
                situacaoImc = "Sobrepeso";
                vetorPessoa[i].setSituacaoImc(situacaoImc);
            }
            
            if(imc >= 30 && imc < 34.9){ 
                situacaoImc = "Obesidade grau I";
                vetorPessoa[i].setSituacaoImc(situacaoImc);
            }
            
            if(imc >= 35 && imc < 39.9){ 
                situacaoImc = "Obesidade grau II";
                vetorPessoa[i].setSituacaoImc(situacaoImc);
            }
            
            if(imc >= 40){ 
                situacaoImc = "Obesidade grau III";
                vetorPessoa[i].setSituacaoImc(situacaoImc);
            } 
        }
        return vetorPessoa;
    }
}
