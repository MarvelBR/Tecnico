/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {
    Scanner teclado = new Scanner(System.in);
    
    public double lerNotas(String mensagem){
       double x = 0;
       while (true) {
        try {
            System.out.print(mensagem);
            x = teclado.nextDouble();
            while (x<0 || x>10) {
                System.out.print("Erro, digite um valor entre 0 e 10:");
                x = teclado.nextDouble();
            }
            break;
        } catch (Exception e) {
            System.out.println("Erro, digite novamente");
            teclado = new Scanner(System.in);
        }
       }
       return x;
    }
    
}
