/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import static java.lang.Math.sqrt;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        Processamento processamento = new Processamento();
        Saida saida = new Saida();
        
        for(int i = 1; i<5; i++) {
            double notas = entrada.lerNotas("Digite a nota do "+(i)+"º bimestre:");
            
            processamento.somarNota(notas);
            
        }
        
        saida.imprimirResultados("A maior nota do aluno foi", processamento.getMaior());
        saida.imprimirResultados("A menor nota do aluno foi", processamento.getMenor());
        saida.imprimirResultados("A média anual do aluno foi igual a", processamento.getMedia());
        processamento.getAprovação();
        
    }
    
}
