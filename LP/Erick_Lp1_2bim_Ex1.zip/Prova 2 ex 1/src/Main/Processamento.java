/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    double soma = 0;
    double maior = 0;
    double menor = 11;
    int cont = 0;

    public void somarNota(double notas) {
        soma = soma+notas;
        cont++;
        
        if (maior<notas) {
            maior = notas;
        }
        if (menor>notas) {
            menor = notas;
        }
    }
    
    public double getMedia (){
        return soma/cont;
    }
    
    public double getMaior (){
        return maior;
    }
    
    public double getMenor (){
        return menor;
    }
    
    public double getAprovação(){
        if (soma/cont >= 9 && soma/cont <= 10) {
            System.out.println("O aluno foi nota A");
        }
        
        if (soma/cont >= 7.5 && soma/cont <= 8.9) {
            System.out.println("O aluno foi nota B");
        }
        
        if (soma/cont >= 6 && soma/cont <= 7.4) {
            System.out.println("O aluno foi nota C");
        }
        
        if (soma/cont >= 4 && soma/cont <= 5.9) {
            System.out.println("O aluno foi nota D");
        }
        
        if (soma/cont == 0 || soma/cont <= 3.9) {
            System.out.println("O aluno foi nota E");
        }
        
        if(soma/cont >=6 && soma/cont <=10){
            System.out.println("O aluno está aprovado");
        }
        
        if(soma/cont == 0 || soma/cont <=5.9){
            System.out.println("O aluno está reprovado");
        }
        
        return 0;
    }
  }

