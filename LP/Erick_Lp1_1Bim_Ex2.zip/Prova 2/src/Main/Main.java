/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        double a = entrada.lerNumeroDouble("Digite a nota da primeira questão para o professor 1 :");
        double b = entrada.lerNumeroDouble("Digite a nota da segunda questão para o professor 1 :");
        double c = entrada.lerNumeroDouble("Digite a nota da terceira questão para o professor 1 :");
        double d = entrada.lerNumeroDouble("Digite a nota da quarta questão para o professor 1 :");
        double e = entrada.lerNumeroDouble("Digite a nota da primeira questão para o professor 2 :");
        double f = entrada.lerNumeroDouble("Digite a nota da segunda questão para o professor 2 :");
        double g = entrada.lerNumeroDouble("Digite a nota da terceira questão para o professor 2 :");
        double h = entrada.lerNumeroDouble("Digite a nota da quarta questão para o professor 2 :");
        double i = entrada.lerNumeroDouble("Digite a nota da primeira questão para o professor 3 :");
        double j = entrada.lerNumeroDouble("Digite a nota da segunda questão para o professor 3 :");
        double k = entrada.lerNumeroDouble("Digite a nota da terceira questão para o professor 3 :");
        double l = entrada.lerNumeroDouble("Digite a nota da quarta questão para o professor 3 :");
        
        Processamento processamento = new Processamento();
        double media1 = processamento.somarQuatroNumeros1(a, b, c, d);
        double media2 = processamento.somarQuatroNumeros2(e, f, g, h);
        double media3 = processamento.somarQuatroNumeros3(i, j, k, l);
        double media_final = processamento.somarTresMedias(media1, media2, media3);
   
        Saida saida = new Saida();
        saida.imprimirMedia("A média das 4 notas dadas pelo professor 1 é igual a", media1);
        saida.imprimirMedia("A média das 4 notas dadas pelo professor 2 é igual a", media2);
        saida.imprimirMedia("A média das 4 notas dadas pelo professor 3 é igual a", media3);
        
    }
    
}
