/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author erick
 */
class Processamento {
        public double somarQuatroNumeros1(double a, double b, double c, double d){

        double media1 = a+b+c+d;
        return media1;
    }
    public double somarQuatroNumeros2(double e, double f, double g, double h){

        double media2 = e+f+g+h;
        return media2;
    }
    public double somarQuatroNumeros3(double i, double j, double k, double l){

        double media3 = i+j+k+l;
        return media3;
    }
    public double somarTresMedias(double media1, double media2, double media3){
        double media_final = (media1+media2+media3)/3;
        
        if (media_final >= 6){
            DecimalFormat decimalFormat = new DecimalFormat("#0.00");
            System.out.println("O aluno foi aprovado");
            System.out.println("A média final dele foi de:" + decimalFormat.format(media_final));
        }
        else {
            DecimalFormat decimalFormat = new DecimalFormat("#0.00");
            System.out.println("O aluno foi reprovado");
            System.out.println("A média final dele foi de:" + decimalFormat.format(media_final));
        }
        return media_final;
    }
}

