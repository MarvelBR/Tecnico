/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public int verEspacos(String s1){
        String [] s2 = s1.split(" ");
        int contador = -1;
        for (int i = 0; i < s2.length; i++){
            contador = contador+1;
        }
        return contador;
    }
}
