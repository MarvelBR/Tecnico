package tools;

//@author Radames J Halmeman  - rjhalmeman@gmail.com
import java.awt.Color;

public class MinhasCoresEnum {

    public final static Color branco = new Color(255, 255, 255);
    public final static Color brancoA = new Color(255, 255, 200);
    public final static Color verdinho = new Color(0, 255, 50);
    public final static Color verdeOliva = new Color(150, 150, 50);
    public final static Color vermelho = new Color(255, 0, 0);
;
}
