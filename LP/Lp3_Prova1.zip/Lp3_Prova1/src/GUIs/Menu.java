/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUIs;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *
 * @author helo
 */
public class Menu extends JFrame{
    Container cp;
    JButton btCurso = new JButton("Curso");
    JButton btNivel = new JButton("Nível");
    JButton btPessoa = new JButton("Pessoa");
    JButton btSala = new JButton("Sala de Aula");
    
    public Menu() {
        cp= getContentPane();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Cadastro");
        
        btCurso.setBackground(new Color(135, 206, 250));
        btNivel.setBackground(new Color(255, 140, 0));
        btPessoa.setBackground(new Color(255, 203, 219));
        btSala.setBackground(new Color(200, 162, 200));
        
        cp.setLayout(new GridLayout(2,2));
        
        cp.add(btCurso);
        cp.add(btNivel);
        cp.add(btPessoa);
        cp.add(btSala);
        
        
        btCurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CursoGUI cursoGUI = new CursoGUI();
            }
        });
        
        btNivel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                NivelGUI nivelGUI = new NivelGUI();
            }
        });
        
        btPessoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PessoaGUI pessoaGUI = new PessoaGUI();
            }
        });
        
        btSala.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SalaAulaGUI salaAulaGUI = new SalaAulaGUI();
            }
        });
        
           
        setSize(350,200);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

