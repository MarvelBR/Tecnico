package Main;
import GUIs.Menu;
/**
 *
 * @author helo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menu menu = new Menu();
    }

}