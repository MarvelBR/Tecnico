
import java.util.Date;
import tools.ConverteDatas;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {   
        Entrada entrada = new Entrada();
        Processamento processamento = new Processamento();
        Saida saida = new Saida();
        ConverteDatas converteDatas = new ConverteDatas();
        
        
        Date data1 = entrada.lerData("Escreva uma data:"); 
        
        saida.imprimirData("A data digitada utilizando dia (com 2 dígitos), mês (com 2 dígitos) e ano com 4 dígitos fica assim:");           
        processamento.verData1(data1);
        
        saida.imprimirData("A data digitada utilizando nome do dia da semana, mês(número) e ano com 4 dígitos fica assim:");
        processamento.verData2(data1);
        
        saida.imprimirData("A data digitada utilizando no formato AAAA-MM-DD fica assim:");
        processamento.verData3(data1);
        
    }
    
}
