
import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author erick
 */
class Processamento {
    public void verData1(Date data1){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println(sdf.format(data1));
    }
    public void verData2(Date data1){
        SimpleDateFormat sdf = new SimpleDateFormat("E, dd/MMM/yyyy");
        System.out.println(sdf.format(data1));
    }
    public void verData3(Date data1){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        System.out.println(sdf.format(data1));
    }
}
