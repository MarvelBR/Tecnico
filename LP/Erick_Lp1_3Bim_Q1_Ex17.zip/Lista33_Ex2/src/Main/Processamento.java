/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {
    public int[] somaDosValoresDeCadaLinhaDaMatriz(int [][] matriz){
        int[] somalinha = new int[2];
        
        for (int i = 0; i < matriz.length; i++) {
            int soma1 = 0;
           
            for (int j = 0; j < matriz[0].length; j++) { 
                soma1 = soma1 + matriz[i][j];
                somalinha[i] = soma1;
            }
        }
        return somalinha;
    }
    public int[] somaDosValoresDeCadaColunaDaMatriz(int [][] matriz){
        int[] somacoluna = new int[3];
       
        for (int j = 0; j < matriz[0].length; j++) {
            int soma2 = 0;
           
            for (int i = 0; i < matriz.length; i++) {
                soma2 = soma2 + matriz[i][j];
                somacoluna[j] = soma2;
            }

        }
        return somacoluna;
    }
}
