/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;

/**
 *
 * @author erick
 */
class Entrada {
    Scanner teclado = new Scanner(System.in);

    public int[][] lerMatrizDeNumerosInteiros(String mensagem, String mensagem2, int maxLinhas, int maxColunas) {
        int[][] m = new int[maxLinhas][maxColunas];
        for (int i = 0; i < maxLinhas; i++) {
            for (int j = 0; j < maxColunas; j++) {
                while (true) {
                    try {
                        System.out.print(mensagem + "[" + i + "]" + "[" + j + "] = ");
                        m[i][j] = teclado.nextInt();
                        break;
                    } catch (Exception e) {
                        System.out.println("Erro, digite novamente");
                        teclado = new Scanner(System.in);
                    }
                }
            }
        }
        return m;
    }
}
