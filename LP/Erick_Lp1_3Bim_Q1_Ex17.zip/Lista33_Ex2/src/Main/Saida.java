/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.text.DecimalFormat;

/**
 *
 * @author erick
 */
class Saida {
    public void imprimirMatriz(String mensagem, int[][] matriz) {
        
        DecimalFormat decimalFormat = new DecimalFormat("0");
        System.out.println(mensagem);
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(decimalFormat.format(matriz[i][j]) + " ");
            }
            System.out.println("");
        }
    }
    public void imprimirVetorDeInteiros(String mensagem, int[] vetor){
        System.out.println(mensagem);
        for (int i = 0; i < vetor.length; i++){
            System.out.println(vetor[i]+" ");
        }
    }
    public void separador(String mensagem){
        for (int i = 0; i < 50; i++){
            System.out.print(mensagem);
        }
        System.out.println(" ");
    }
}
