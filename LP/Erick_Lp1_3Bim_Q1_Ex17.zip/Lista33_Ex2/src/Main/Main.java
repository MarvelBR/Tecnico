/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Entrada entrada = new Entrada();
        Processamento processamento = new Processamento();
        Saida saida = new Saida();

        int maxLinhas = 2;
        int maxColunas = 3;
        saida.separador("-");
        int[][] matriz = entrada.lerMatrizDeNumerosInteiros("Digite os valores para a matriz", "valor", maxLinhas, maxColunas);
        saida.separador("=");

        int somaDasLinhas[] = processamento.somaDosValoresDeCadaLinhaDaMatriz(matriz);
        int somaDasColunas[] = processamento.somaDosValoresDeCadaColunaDaMatriz(matriz);

        saida.imprimirMatriz("Matriz armazenada na memória do computador:", matriz);
        saida.separador("*");
        saida.imprimirVetorDeInteiros("Soma das linhas da matriz:", somaDasLinhas);
        saida.separador("-x");
        saida.imprimirVetorDeInteiros("Soma das colunas da matriz:", somaDasColunas);
    }
}

