/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author erick
 */
class Processamento {

    public void lerData(String data) {
        data = data.replace("/", "");
        data = data.replace("de", "");
        data = data.replace("-", "");
        data = data.replace(" ", "");

        if (data.charAt(2) == '0' && data.charAt(3) == '1') {
            System.out.println("Janeiro");
        }
        if (data.charAt(2) == '0' && data.charAt(3) == '2') {
            System.out.println("Fevereiro");
        }
        if (data.charAt(2) == '0' && data.charAt(3) == '3') {
            System.out.println("Março");
        }
        if (data.charAt(2) == '0' && data.charAt(3) == '4') {
            System.out.println("Abril");
        }
        if (data.charAt(2) == '0' && data.charAt(3) == '5') {
            System.out.println("Maio");
        }
        if (data.charAt(2) == '0' && data.charAt(3) == '6') {
            System.out.println("Junho");
        }
        if (data.charAt(2) == '0' && data.charAt(3) == '7') {
            System.out.println("Julho");
        }
        if (data.charAt(2) == '0' && data.charAt(3) == '8') {
            System.out.println("Agosto");
        }
        if (data.charAt(2) == '0' && data.charAt(3) == '9') {
            System.out.println("Setembro");
        }
        if (data.charAt(2) == '1' && data.charAt(3) == '0') {
            System.out.println("Outubro");
        }
        if (data.charAt(2) == '1' && data.charAt(3) == '1') {
            System.out.println("Novembro");
        }
        if (data.charAt(2) == '1' && data.charAt(3) == '2') {
            System.out.println("Dezembro");
        }
    }
}
