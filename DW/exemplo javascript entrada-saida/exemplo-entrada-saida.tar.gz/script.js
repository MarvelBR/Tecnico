
function mostraMensagem(){

    let nome = document.getElementById("nome").value

    let saida = document.getElementById("saida")
    
    saida.innerHTML = "Olá, " + nome

}