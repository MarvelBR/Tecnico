

let nome = "Rafael"

let x  = 5
let y = x * 3


// ENTRADA DE DADOS
// nome = prompt("Digite seu nome")
console.log(nome)
console.log(y)

// DESVIO CONDICIONAL
if (y % 2 == 0){
    console.log("PAR")
}else{
    console.log("ÍMPAR")
}

// REPETIÇÕES
for(let i = 0; i<10; i++){
    console.log(i)
}

// LISTA - VETOR
let lista = [10,20,30]
console.log(lista)
console.log(lista[1])
lista.push(40)
console.log(lista)


